# speaker-command-center

Generates a self-contained HTML "command center" for the speaker — a second-monitor view with the
narrative talk track, audience-engagement questions, a possible exercise, things to watch for, and
the spoken transition line, per slide. Not for the audience; keep it on your own screen only.

## Quick start

```bash
python3 scripts/build_command_center.py examples/sample-input.json out/command-center.html --skill-root .
```

Then open `out/command-center.html` and navigate with the arrow keys / Space / buttons.

## Files

- `SKILL.md` — full authoring rules (how to write beats, questions, transitions) and workflow.
- `schemas/session-schema.json` — input JSON shape.
- `templates/` — the reusable engine (HTML skeleton, theme CSS, navigation JS).
- `scripts/build_command_center.py` — assembles the final HTML.
- `checklists/quality-checklist.md` — review before delivering to the speaker.
- `examples/` — the approved sample (2 slides) as input JSON + built HTML, smoke-tested with
  Playwright (navigation, counter, button disabled-states, transition text all verified).
