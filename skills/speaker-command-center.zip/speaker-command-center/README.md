# speaker-command-center

Generates a self-contained HTML "command center" for the speaker — a second-monitor view with the
narrative talk track, audience-engagement questions, a possible exercise, things to watch for, and
the spoken transition line, per slide. Not for the audience; keep it on your own screen only.

**Zero-scroll is a hard acceptance test, not a suggestion.** No element in this skill's output may
require scrolling, clip text, or shrink below a readability floor — see "Regla de cero scroll" in
`SKILL.md` and `tests/validate_no_scroll.py`.

## Quick start

```bash
# Build
python3 scripts/build_command_center.py examples/sample-input.json out/command-center.html --skill-root .

# Validate (the acceptance test — must pass before delivering to a user)
python3 tests/validate_no_scroll.py out/command-center.html

# Full test suite
python3 -m pytest tests/ -v
```

Then open `out/command-center.html` and navigate with the arrow keys / Space / number+Enter / buttons.

## Files

- `SKILL.md` — full authoring rules, editorial budget, the zero-scroll contract, and workflow.
- `schemas/session-schema.json` — input JSON shape, with the editorial-budget fields documented.
- `templates/` — the reusable engine:
  - `command-center-template.html` — HTML skeleton (cards render dynamically via JS).
  - `theme.css` — zero-scroll layout (dvh, `minmax(0,1fr)` grids, no overflow/ellipsis/line-clamp,
    single `--scale` fluid-typography variable with a hard readability floor).
  - `navigation.js` — keyboard/click/jump-to-slide navigation, dynamic card rendering (empty optional
    cards are omitted, not filled with placeholder text), and `fitToViewport()`, the runtime auto-fit
    routine that shrinks `--scale` until real measured content fits with no scroll and no clipping.
- `scripts/build_command_center.py` — validates the input JSON, warns on editorial-budget overruns,
  optionally checks 1:1 sync against an audience-deck JSON, then assembles the final HTML.
- `tests/validate_no_scroll.py` — the acceptance test: opens the built HTML in real Chromium, walks
  every slide at 1280×720 / 1366×768 / 1440×900 / 1920×1080, and checks every critical selector for
  overflow, forbidden CSS (`overflow:auto/scroll`), text clipping, off-canvas content, font-size below
  floor, and covered/missing nav controls. Reports slide, viewport, selector, and overflow pixels.
- `tests/` — pytest suite: navigation, jump-to-slide, content integrity (no filler text, no stage-
  direction transitions), and the zero-scroll acceptance test wrapped for CI (`pytest tests/`).
- `checklists/quality-checklist.md` — manual review pass before delivering to the speaker.
- `examples/` — a normal-density sample (3 slides) and a high-density stress-test sample (near the
  editorial budget ceiling), both built and verified against all 4 required viewports.

## Requirements

- Python 3.9+
- `playwright` — `pip install playwright --break-system-packages && playwright install chromium`
- `pytest` (optional, for `tests/`) — `pip install pytest --break-system-packages`

If Playwright/Chromium is unavailable in the environment, `tests/validate_no_scroll.py` cannot run —
do not claim the zero-scroll contract was verified in that case; state the limitation explicitly.
