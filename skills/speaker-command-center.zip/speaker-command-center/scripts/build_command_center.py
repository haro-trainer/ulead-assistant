#!/usr/bin/env python3
"""
build_command_center.py — validates a session JSON input against schemas/session-schema.json
(manual checks, no external dependency), warns on editorial-budget overruns, optionally checks 1:1
sync against an audience deck JSON, then assembles the final HTML from templates/.

Usage:
    python3 build_command_center.py <session.json> <output.html> [--skill-root PATH]
                                     [--audience-deck <presentation.json>]

Exit code is non-zero if validation finds a hard error (missing required fields, etc.). Soft
editorial-budget warnings are printed but do not block the build — the real arbiter of "does it fit"
is tests/validate_no_scroll.py, run separately against the built HTML in a real browser.
"""
import argparse
import json
import sys
from pathlib import Path

DEFAULT_THEME = {
    "accent_questions": "#ffb020",
    "accent_exercise": "#2fd1a8",
    "accent_watch": "#ff6b6b",
    "accent_transition": "#8b7bff",
}

MAX_BEATS_SOFT = 4
MAX_QUESTIONS_SOFT = 2
MAX_QUESTIONS_HARD = 3


def validate(data):
    """Hard structural checks. Returns list of error strings (empty = valid)."""
    errors = []
    if "session_title" not in data or not str(data["session_title"]).strip():
        errors.append("Missing required field: session_title")
    slides = data.get("slides")
    if not slides or not isinstance(slides, list):
        errors.append("Missing or empty required field: slides (must be a non-empty array)")
        return errors

    for idx, s in enumerate(slides, start=1):
        label = f"slide {idx} ({s.get('on_screen', '?')})"
        if not s.get("on_screen", "").strip():
            errors.append(f"{label}: missing required field 'on_screen'")
        script = s.get("script")
        if not script or not isinstance(script, list):
            errors.append(f"{label}: missing or empty required field 'script'")
        else:
            for b_idx, beat in enumerate(script, start=1):
                if not beat.get("beat", "").strip() or not beat.get("text", "").strip():
                    errors.append(f"{label}: script beat {b_idx} missing 'beat' or 'text'")
        is_last = idx == len(slides)
        if not is_last and not s.get("transition", "").strip():
            errors.append(f"{label}: missing required field 'transition' (only the last slide may omit it)")
        questions = s.get("questions")
        if questions is not None and len(questions) > MAX_QUESTIONS_HARD:
            errors.append(f"{label}: {len(questions)} questions exceeds the hard limit of {MAX_QUESTIONS_HARD}")

    audience_count = data.get("audience_slide_count")
    if audience_count is not None and audience_count != len(slides):
        errors.append(
            f"audience_slide_count ({audience_count}) does not match len(slides) ({len(slides)}) — "
            "the Command Center must stay 1:1 with the audience deck."
        )
    return errors


def warn_editorial_budget(data):
    """Soft warnings — printed, never block the build. Real fit is confirmed by rendering."""
    warnings = []
    for idx, s in enumerate(data.get("slides", []), start=1):
        label = f"slide {idx} ({s.get('on_screen', '?')})"
        n_beats = len(s.get("script", []))
        if n_beats > MAX_BEATS_SOFT:
            warnings.append(f"{label}: {n_beats} script beats (soft budget is {MAX_BEATS_SOFT}) — consider trimming.")
        n_q = len(s.get("questions", []) or [])
        if n_q > MAX_QUESTIONS_SOFT:
            warnings.append(
                f"{label}: {n_q} questions (soft budget is {MAX_QUESTIONS_SOFT}) — only exceed this if a "
                "real render confirms it still fits without scrolling."
            )
        for field in ("exercise", "watch_for"):
            val = s.get(field)
            if isinstance(val, str) and val.strip().lower() in {"none", "ninguno", "n/a", "-", "\u2014"}:
                warnings.append(
                    f"{label}: field '{field}' looks like filler text (\"{val}\") — omit the field "
                    "entirely instead so the card is hidden and its space redistributed."
                )
    return warnings


def sync_check(data, audience_deck_path):
    """Optional check against an audience-deck presentation-input JSON (from
    premium-pedagogical-presentation-builder or similar): same slide count, and a rough order check."""
    audience = json.loads(Path(audience_deck_path).read_text(encoding="utf-8"))
    audience_slides = audience.get("slides", [])
    cc_slides = data.get("slides", [])

    messages = []
    if len(audience_slides) != len(cc_slides):
        messages.append(
            f"MISMATCH: audience deck has {len(audience_slides)} slides, "
            f"command center has {len(cc_slides)} — must be 1:1."
        )
    else:
        messages.append(f"OK: both have {len(cc_slides)} slides.")

    print("\n--- Audience deck <-> Command Center order (manual sanity check) ---")
    for idx in range(max(len(audience_slides), len(cc_slides))):
        a_title = audience_slides[idx].get("title", "?") if idx < len(audience_slides) else "(missing)"
        c_title = cc_slides[idx].get("on_screen", "?") if idx < len(cc_slides) else "(missing)"
        print(f"  {idx + 1:>2}. audience: {a_title!r:<45} command center: {c_title!r}")
    return messages


def build(session_json_path, output_path, skill_root, audience_deck_path=None):
    skill_root = Path(skill_root)
    data = json.loads(Path(session_json_path).read_text(encoding="utf-8"))

    errors = validate(data)
    if errors:
        print("VALIDATION FAILED:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        sys.exit(1)

    for w in warn_editorial_budget(data):
        print(f"WARNING: {w}")

    if audience_deck_path:
        for m in sync_check(data, audience_deck_path):
            print(m)

    theme = {**DEFAULT_THEME, **data.get("theme", {})}
    theme_css = (skill_root / "templates" / "theme.css").read_text(encoding="utf-8")
    for key, css_var in [
        ("accent_questions", "{{ACCENT_QUESTIONS}}"),
        ("accent_exercise", "{{ACCENT_EXERCISE}}"),
        ("accent_watch", "{{ACCENT_WATCH}}"),
        ("accent_transition", "{{ACCENT_TRANSITION}}"),
    ]:
        theme_css = theme_css.replace(css_var, theme[key])

    navigation_js = (skill_root / "templates" / "navigation.js").read_text(encoding="utf-8")
    template = (skill_root / "templates" / "command-center-template.html").read_text(encoding="utf-8")

    output = (
        template
        .replace("{{LANG}}", data.get("language", "en"))
        .replace("{{SESSION_TITLE}}", data.get("session_title", "Session"))
        .replace("{{THEME_CSS}}", theme_css)
        .replace("{{SLIDE_COUNT}}", str(len(data["slides"])))
        .replace("{{SLIDES_JSON}}", json.dumps(data["slides"], ensure_ascii=False))
        .replace("{{NAVIGATION_JS}}", navigation_js)
    )

    Path(output_path).write_text(output, encoding="utf-8")
    print(f"\nCommand center built: {output_path} ({len(data['slides'])} slides)")
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("session_json")
    parser.add_argument("output_html")
    parser.add_argument("--skill-root", default=str(Path(__file__).resolve().parent.parent))
    parser.add_argument("--audience-deck", default=None, help="Optional presentation-input JSON to check 1:1 sync against.")
    args = parser.parse_args()
    build(args.session_json, args.output_html, args.skill_root, args.audience_deck)
