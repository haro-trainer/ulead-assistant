#!/usr/bin/env python3
"""
build_command_center.py — assembles the speaker command-center HTML from a session JSON input
(matching schemas/session-schema.json) plus the templates in templates/.

Usage:
    python3 build_command_center.py <session.json> <output.html> [--skill-root PATH]
"""
import argparse
import json
from pathlib import Path

DEFAULT_THEME = {
    "accent_questions": "#ffb020",
    "accent_exercise": "#2fd1a8",
    "accent_watch": "#ff6b6b",
    "accent_transition": "#8b7bff",
}


def build(session_json_path, output_path, skill_root):
    skill_root = Path(skill_root)
    data = json.loads(Path(session_json_path).read_text(encoding="utf-8"))

    if not data.get("slides"):
        raise ValueError("session input has no slides")

    theme = {**DEFAULT_THEME, **data.get("theme", {})}

    theme_css = (skill_root / "templates" / "theme.css").read_text(encoding="utf-8")
    for key, css_var in [
        ("accent_questions", "{{ACCENT_QUESTIONS}}"),
        ("accent_exercise", "{{ACCENT_EXERCISE}}"),
        ("accent_watch", "{{ACCENT_WATCH}}"),
        ("accent_transition", "{{ACCENT_TRANSITION}}"),
    ]:
        theme_css = theme_css.replace(css_var, theme[key])

    navigation_js = (skill_root / "templates" / "navigation.js").read_text(encoding="utf-8")
    template = (skill_root / "templates" / "command-center-template.html").read_text(encoding="utf-8")

    output = (
        template
        .replace("{{LANG}}", data.get("language", "en"))
        .replace("{{SESSION_TITLE}}", data.get("session_title", "Session"))
        .replace("{{THEME_CSS}}", theme_css)
        .replace("{{SLIDE_COUNT}}", str(len(data["slides"])))
        .replace("{{SLIDES_JSON}}", json.dumps(data["slides"], ensure_ascii=False))
        .replace("{{NAVIGATION_JS}}", navigation_js)
    )

    Path(output_path).write_text(output, encoding="utf-8")
    print(f"Command center built: {output_path} ({len(data['slides'])} slides)")
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("session_json")
    parser.add_argument("output_html")
    parser.add_argument("--skill-root", default=str(Path(__file__).resolve().parent.parent))
    args = parser.parse_args()
    build(args.session_json, args.output_html, args.skill_root)
