"""Pytest wrapper around validate_no_scroll.py — the acceptance test for the zero-scroll contract.
Runs both the normal-density and the high-density stress example across all 4 required viewports.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from validate_no_scroll import validate  # noqa: E402

EXAMPLES_DIR = Path(__file__).parent.parent / "examples"


def test_normal_example_zero_scroll_all_viewports():
    report = validate(str(EXAMPLES_DIR / "sample-command-center.html"))
    assert report["failures"] == [], _format(report)


def test_high_density_example_zero_scroll_all_viewports():
    report = validate(str(EXAMPLES_DIR / "sample-command-center-high-density.html"))
    assert report["failures"] == [], _format(report)


def _format(report):
    lines = [f"{len(report['failures'])} failure(s):"]
    for f in report["failures"]:
        lines.append(f"  [{f['type']}] slide {f['slide']} \"{f['title']}\" @ {f['viewport']} "
                     f"- {f['selector']}: {f['details']}")
    return "\n".join(lines)
