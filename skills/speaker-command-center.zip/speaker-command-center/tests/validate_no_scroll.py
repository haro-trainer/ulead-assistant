#!/usr/bin/env python3
"""
validate_no_scroll.py — the acceptance test for the "zero scroll, zero clipping" contract.

For a built Command Center HTML file, this opens it in a real Chromium browser, walks every slide
via window.commandCenterNav, and at each of the required viewports checks every critical selector for:

  1. Vertical/horizontal overflow (scrollHeight/scrollWidth > clientHeight/clientWidth + 1px tolerance).
  2. Computed overflow / overflow-x / overflow-y == 'auto' or 'scroll' (should never happen by design).
  3. Text clipping via text-overflow:ellipsis or -webkit-line-clamp on the title/transition elements.
  4. Font size below the readability floor (15px for primary narrative text, 12px for everything else).
  5. Any visible element extending outside the viewport (off-canvas).
  6. Nav buttons present, on-screen, and not covered by another element (elementFromPoint check).
  7. window.commandCenterNav reporting a fit-viewport failure (data-fit-failed on <html>) — meaning
     even the minimum readable scale wasn't enough to avoid overflow for that slide.

Usage:
    python3 validate_no_scroll.py <deck.html> [--viewports 1280x720,1366x768,1440x900,1920x1080]

Exit code 0 = every slide passes at every viewport. Non-zero = at least one failure (see printed report).
"""
import argparse
import http.server
import json
import socketserver
import sys
import threading
from pathlib import Path

from playwright.sync_api import sync_playwright

DEFAULT_VIEWPORTS = ["1280x720", "1366x768", "1440x900", "1920x1080"]

CRITICAL_SELECTORS = [
    "html", "body", ".cc", "header", ".body", ".talk-track", ".script", ".side",
    ".card", ".card ul", ".card p", "footer", ".transition", ".transition .text", ".nav",
]

# selector -> minimum font-size floor in px (per the "no informational text below 12px, no primary
# narrative text below 15px" requirement).
FONT_FLOORS = {
    ".script p": 15,
    ".talk-track .script p": 15,
    ".card p": 12,
    ".card ul": 12,
    ".card ul li": 12,
    ".transition .text": 12,
    ".now-on-screen .title": 12,
    ".kbd-hint": 12,
    ".slide-meta": 12,
    ".card .label": 12,
    ".beat": 12,
}


def serve_directory(directory, port=0):
    handler = lambda *a, **kw: http.server.SimpleHTTPRequestHandler(*a, directory=str(directory), **kw)
    httpd = socketserver.TCPServer(("127.0.0.1", port), handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, httpd.server_address[1]


CHECK_JS = """
() => {
    const results = [];
    const selectors = %s;
    for (const sel of selectors) {
        document.querySelectorAll(sel).forEach((node) => {
            const style = getComputedStyle(node);
            const rect = node.getBoundingClientRect();
            results.push({
                selector: sel,
                tag: node.tagName,
                scrollHeight: node.scrollHeight,
                clientHeight: node.clientHeight,
                scrollWidth: node.scrollWidth,
                clientWidth: node.clientWidth,
                overflow: style.overflow,
                overflowX: style.overflowX,
                overflowY: style.overflowY,
                textOverflow: style.textOverflow,
                lineClamp: style.webkitLineClamp || style.lineClamp || 'none',
                whiteSpace: style.whiteSpace,
                fontSize: parseFloat(style.fontSize),
                left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom,
                width: rect.width, height: rect.height,
                text: (node.textContent || '').trim().slice(0, 40),
            });
        });
    }
    return {
        results,
        docScrollH: document.documentElement.scrollHeight,
        docClientH: document.documentElement.clientHeight,
        docScrollW: document.documentElement.scrollWidth,
        docClientW: document.documentElement.clientWidth,
        fitFailed: document.documentElement.dataset.fitFailed === 'true',
    };
}
""" % json.dumps(CRITICAL_SELECTORS)


def check_slide(page, slide_index, slide_title, viewport_label, vw, vh):
    failures = []
    data = page.evaluate(CHECK_JS)

    if data["fitFailed"]:
        failures.append({
            "slide": slide_index, "title": slide_title, "viewport": viewport_label,
            "selector": "(auto-fit)", "type": "FIT_FAILED_AT_FLOOR",
            "details": "Content still overflows even at the minimum readable --scale floor.",
        })

    if data["docScrollH"] > data["docClientH"] + 1:
        failures.append({
            "slide": slide_index, "title": slide_title, "viewport": viewport_label,
            "selector": "html", "type": "DOCUMENT_OVERFLOW_Y",
            "details": f"scrollHeight {data['docScrollH']} > clientHeight {data['docClientH']} "
                       f"(+{data['docScrollH'] - data['docClientH']}px)",
        })
    if data["docScrollW"] > data["docClientW"] + 1:
        failures.append({
            "slide": slide_index, "title": slide_title, "viewport": viewport_label,
            "selector": "html", "type": "DOCUMENT_OVERFLOW_X",
            "details": f"scrollWidth {data['docScrollW']} > clientWidth {data['docClientW']}",
        })

    for r in data["results"]:
        sel = r["selector"]
        loc = f"{r['tag']} \"{r['text']}\""

        if r["scrollHeight"] > r["clientHeight"] + 1:
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": sel, "type": "OVERFLOW_Y",
                "details": f"{loc}: scrollHeight {r['scrollHeight']} > clientHeight {r['clientHeight']} "
                           f"(+{r['scrollHeight'] - r['clientHeight']}px)",
            })
        if r["scrollWidth"] > r["clientWidth"] + 1:
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": sel, "type": "OVERFLOW_X",
                "details": f"{loc}: scrollWidth {r['scrollWidth']} > clientWidth {r['clientWidth']} "
                           f"(+{r['scrollWidth'] - r['clientWidth']}px)",
            })
        for prop in ("overflow", "overflowX", "overflowY"):
            if r[prop] in ("auto", "scroll"):
                failures.append({
                    "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                    "selector": sel, "type": "FORBIDDEN_OVERFLOW_CSS",
                    "details": f"{loc}: computed {prop}='{r[prop]}' (must never be auto/scroll in this skill)",
                })
        if sel in (".now-on-screen .title", ".transition .text") and r["textOverflow"] == "ellipsis":
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": sel, "type": "TEXT_CLIPPED_ELLIPSIS",
                "details": f"{loc}: text-overflow is 'ellipsis' — titles/transitions must wrap, not truncate.",
            })
        if sel in (".now-on-screen .title", ".transition .text") and r["lineClamp"] not in ("none", ""):
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": sel, "type": "TEXT_CLIPPED_LINE_CLAMP",
                "details": f"{loc}: line-clamp is '{r['lineClamp']}' — must not clip visible text.",
            })
        if r["width"] > 0 and r["height"] > 0:
            if r["left"] < -1 or r["top"] < -1 or r["right"] > vw + 1 or r["bottom"] > vh + 1:
                failures.append({
                    "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                    "selector": sel, "type": "OFF_CANVAS",
                    "details": f"{loc}: box ({r['left']:.0f},{r['top']:.0f})-({r['right']:.0f},{r['bottom']:.0f}) "
                               f"outside {vw}x{vh} viewport.",
                })
        floor = FONT_FLOORS.get(sel)
        if floor and r["fontSize"] and r["fontSize"] < floor - 0.5 and r["text"]:
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": sel, "type": "FONT_BELOW_FLOOR",
                "details": f"{loc}: font-size {r['fontSize']:.1f}px below the {floor}px floor.",
            })

    # Required controls: present, on-screen, not covered.
    for btn_sel in ("#prevBtn", "#nextBtn"):
        box = page.eval_on_selector(btn_sel, "el => { const r = el.getBoundingClientRect(); "
                                              "return {x:r.left+r.width/2, y:r.top+r.height/2, "
                                              "w:r.width, h:r.height}; }")
        if box["w"] == 0 or box["h"] == 0:
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": btn_sel, "type": "CONTROL_NOT_VISIBLE", "details": "Zero size.",
            })
            continue
        covered = page.evaluate(
            f"(() => {{ const el = document.querySelector('{btn_sel}'); "
            f"const top = document.elementFromPoint({box['x']}, {box['y']}); "
            f"return !(top === el || el.contains(top)); }})()"
        )
        if covered:
            failures.append({
                "slide": slide_index, "title": slide_title, "viewport": viewport_label,
                "selector": btn_sel, "type": "CONTROL_COVERED",
                "details": "Another element intercepts pointer events at the button's center.",
            })

    return failures


def validate(deck_html_path, viewports=None):
    viewports = viewports or DEFAULT_VIEWPORTS
    deck_path = Path(deck_html_path).resolve()
    httpd, port = serve_directory(deck_path.parent)
    url = f"http://127.0.0.1:{port}/{deck_path.name}"

    all_failures = []
    slides_total = 0

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            for vp in viewports:
                w, h = (int(x) for x in vp.split("x"))
                page = browser.new_page(viewport={"width": w, "height": h})
                page.goto(url)
                page.wait_for_selector(".cc")
                page.wait_for_timeout(80)
                slides_total = page.evaluate("window.commandCenterNav.getTotal()")

                for idx in range(slides_total):
                    page.evaluate(f"window.commandCenterNav.goTo({idx})")
                    page.wait_for_timeout(80)
                    title = page.inner_text("#onScreenTitle")
                    all_failures.extend(check_slide(page, idx + 1, title, vp, w, h))
                page.close()
            browser.close()
    finally:
        httpd.shutdown()

    return {"slides_total": slides_total, "viewports": viewports, "failures": all_failures}


def print_report(report):
    print(f"Slides: {report['slides_total']} | Viewports: {', '.join(report['viewports'])}")
    if not report["failures"]:
        print("PASSED: zero scroll, zero clipping, zero off-canvas content across all slides/viewports.")
        return True
    print(f"FAILED: {len(report['failures'])} issue(s) found.\n")
    for f in report["failures"]:
        print(f"  [{f['type']}] slide {f['slide']} \"{f['title']}\" @ {f['viewport']} — {f['selector']}")
        print(f"      {f['details']}")
    return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("deck_html")
    parser.add_argument("--viewports", default=",".join(DEFAULT_VIEWPORTS))
    parser.add_argument("--json-out", default=None)
    args = parser.parse_args()

    report = validate(args.deck_html, args.viewports.split(","))
    ok = print_report(report)
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    sys.exit(0 if ok else 1)
