"""Shared pytest fixtures: serves the built example deck locally and yields a Playwright page."""
import http.server
import socketserver
import threading
from pathlib import Path

import pytest
from playwright.sync_api import sync_playwright

DECK_PATH = (Path(__file__).parent.parent / "examples" / "sample-command-center.html").resolve()


@pytest.fixture(scope="session")
def deck_url():
    directory = DECK_PATH.parent
    handler = lambda *a, **kw: http.server.SimpleHTTPRequestHandler(*a, directory=str(directory), **kw)
    httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    port = httpd.server_address[1]
    yield f"http://127.0.0.1:{port}/{DECK_PATH.name}"
    httpd.shutdown()


@pytest.fixture()
def page(deck_url):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        pg = browser.new_page(viewport={"width": 1920, "height": 1080})
        pg.goto(deck_url)
        pg.wait_for_selector(".cc")
        yield pg
        browser.close()
