"""No filler/placeholder text, no empty required fields, transitions read like real spoken lines."""
import json
from pathlib import Path

EXAMPLES_DIR = Path(__file__).parent.parent / "examples"
FILLER_VALUES = {"none", "ninguno", "n/a", "-", "\u2014", ""}
STAGE_DIRECTION_MARKERS = ["next slide", "pasar al siguiente", "click", "advance the slide"]


def _load(name):
    return json.loads((EXAMPLES_DIR / name).read_text(encoding="utf-8"))


def test_no_filler_placeholder_text_in_optional_fields():
    for fname in ["sample-input.json", "sample-input-high-density.json"]:
        data = _load(fname)
        for s in data["slides"]:
            for field in ("exercise", "watch_for"):
                val = s.get(field)
                if val is not None:
                    assert val.strip().lower() not in FILLER_VALUES, (
                        f"{fname} slide '{s['on_screen']}': field '{field}' is filler text; omit it instead."
                    )


def test_transitions_are_not_stage_directions():
    for fname in ["sample-input.json", "sample-input-high-density.json"]:
        data = _load(fname)
        slides = data["slides"]
        for idx, s in enumerate(slides):
            is_last = idx == len(slides) - 1
            transition = (s.get("transition") or "").lower()
            if is_last:
                continue
            assert transition, f"{fname} slide '{s['on_screen']}': missing transition."
            for marker in STAGE_DIRECTION_MARKERS:
                assert marker not in transition, (
                    f"{fname} slide '{s['on_screen']}': transition reads like a stage direction ('{marker}')."
                )


def test_editorial_budget_soft_limits_respected_in_examples():
    for fname in ["sample-input.json", "sample-input-high-density.json"]:
        data = _load(fname)
        for s in data["slides"]:
            assert len(s.get("script", [])) <= 5, f"{fname} slide '{s['on_screen']}' exceeds hard beat limit."
            assert len(s.get("questions", []) or []) <= 3, f"{fname} slide '{s['on_screen']}' exceeds hard question limit."


def test_three_movement_structure_present_in_substantive_slides():
    """Every slide in the bundled examples builds its script around Enmarcar -> Profundizar ->
    Aplicar/Aterrizar (see SKILL.md 'Estructura narrativa de tres movimientos'). The third
    movement accepts either label depending on nuance (personal application vs. crisp synthesis)."""
    required_first_two = {"enmarcar", "profundizar"}
    third_movement_aliases = {"aplicar", "aterrizar"}
    for fname in ["sample-input.json", "sample-input-high-density.json"]:
        data = _load(fname)
        for s in data["slides"]:
            beats = {b["beat"].strip().lower() for b in s.get("script", [])}
            missing = required_first_two - beats
            assert not missing, f"{fname} slide '{s['on_screen']}' missing movement(s): {missing}"
            assert beats & third_movement_aliases, (
                f"{fname} slide '{s['on_screen']}' missing a third movement (Aplicar or Aterrizar)."
            )
