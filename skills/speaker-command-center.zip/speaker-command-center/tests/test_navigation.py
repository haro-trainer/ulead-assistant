"""Keyboard/click navigation, jump-to-slide, and 1:1 slide-count sync sanity."""


def test_keyboard_next_and_prev(page):
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 0
    page.keyboard.press("ArrowRight")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 1
    page.keyboard.press("ArrowLeft")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 0


def test_click_buttons(page):
    page.click("#nextBtn")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 1
    page.click("#prevBtn")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 0


def test_home_and_end(page):
    total = page.evaluate("window.commandCenterNav.getTotal()")
    page.keyboard.press("End")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == total - 1
    page.keyboard.press("Home")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 0


def test_prev_disabled_on_first_next_disabled_on_last(page):
    assert page.get_attribute("#prevBtn", "disabled") is not None
    page.keyboard.press("End")
    page.wait_for_timeout(80)
    assert page.get_attribute("#nextBtn", "disabled") is not None


def test_jump_to_slide_by_typing_number(page):
    page.keyboard.press("2")
    page.wait_for_timeout(80)
    assert page.evaluate("document.getElementById('jumpOverlay').classList.contains('visible')") is True
    assert page.inner_text("#jumpValue") == "2"
    page.keyboard.press("Enter")
    page.wait_for_timeout(80)
    assert page.evaluate("window.commandCenterNav.getCurrent()") == 1
    assert page.evaluate("document.getElementById('jumpOverlay').classList.contains('visible')") is False


def test_jump_overlay_escape_cancels_without_moving(page):
    start = page.evaluate("window.commandCenterNav.getCurrent()")
    page.keyboard.press("3")
    page.wait_for_timeout(50)
    page.keyboard.press("Escape")
    page.wait_for_timeout(50)
    assert page.evaluate("document.getElementById('jumpOverlay').classList.contains('visible')") is False
    assert page.evaluate("window.commandCenterNav.getCurrent()") == start
