/* navigation.js — command center navigation. Expects a global `SLIDES` array (injected by
   build_command_center.py) matching schemas/session-schema.json's "slides" items. */
(function () {
  let i = 0;
  const el = (id) => document.getElementById(id);

  function render() {
    const s = SLIDES[i];
    el('onScreenTitle').textContent = s.on_screen || '';
    el('pace').textContent = s.pace || '';
    el('counter').textContent = `${i + 1} / ${SLIDES.length}`;

    el('script').innerHTML = (s.script || [])
      .map((b) => `<span class="beat">${escapeHtml(b.beat)}</span><p>${escapeHtml(b.text)}</p>`)
      .join('');

    el('questions').innerHTML = (s.questions || [])
      .map((q) => `<li>${escapeHtml(q)}</li>`)
      .join('') || '<li>—</li>';

    el('exercise').textContent = s.exercise || '—';
    el('watch').textContent = s.watch_for || '—';
    el('transition').textContent = s.transition || '(Last slide — no further transition.)';

    el('progress').style.width = `${((i + 1) / SLIDES.length) * 100}%`;
    el('prevBtn').disabled = i === 0;
    el('nextBtn').disabled = i === SLIDES.length - 1;

    el('talkTrack').scrollTop = 0;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  function next() { if (i < SLIDES.length - 1) { i++; render(); } }
  function prev() { if (i > 0) { i--; render(); } }
  function goTo(n) { i = Math.max(0, Math.min(SLIDES.length - 1, n)); render(); }

  // --- Jump to slide by typing a number ---
  let jumpBuffer = '';
  let jumpTimeout = null;
  const jumpOverlay = el('jumpOverlay');
  const jumpValue = el('jumpValue');

  function showJumpOverlay() {
    jumpValue.textContent = jumpBuffer || '\u2014';
    jumpOverlay.classList.add('visible');
    clearTimeout(jumpTimeout);
    jumpTimeout = setTimeout(cancelJump, 2500); // auto-cancel if the speaker stops typing
  }
  function cancelJump() {
    jumpBuffer = '';
    jumpOverlay.classList.remove('visible');
    clearTimeout(jumpTimeout);
  }
  function confirmJump() {
    if (jumpBuffer) {
      const n = parseInt(jumpBuffer, 10) - 1; // slides are 1-indexed for the speaker
      if (!isNaN(n)) goTo(n);
    }
    cancelJump();
  }

  document.addEventListener('keydown', (e) => {
    // Digits 0-9 (without modifier keys) start/continue a jump-to-slide entry.
    if (/^[0-9]$/.test(e.key) && !e.metaKey && !e.ctrlKey && !e.altKey) {
      e.preventDefault();
      jumpBuffer = (jumpBuffer + e.key).slice(0, 3); // up to 999 slides
      showJumpOverlay();
      return;
    }
    if (jumpOverlay.classList.contains('visible')) {
      if (e.key === 'Enter') { e.preventDefault(); confirmJump(); return; }
      if (e.key === 'Escape') { e.preventDefault(); cancelJump(); return; }
      if (e.key === 'Backspace') {
        e.preventDefault();
        jumpBuffer = jumpBuffer.slice(0, -1);
        if (jumpBuffer) { showJumpOverlay(); } else { cancelJump(); }
        return;
      }
    }
  });

  document.addEventListener('keydown', (e) => {
    if (jumpOverlay.classList.contains('visible')) return; // digits/Enter/Esc handled above
    if (['ArrowRight', ' ', 'PageDown'].includes(e.key)) { e.preventDefault(); next(); }
    if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); prev(); }
    if (e.key === 'Home') { e.preventDefault(); goTo(0); }
    if (e.key === 'End') { e.preventDefault(); goTo(SLIDES.length - 1); }
  });

  el('nextBtn').addEventListener('click', next);
  el('prevBtn').addEventListener('click', prev);

  render();

  // Exposed for testing/automation.
  window.commandCenterNav = { next, prev, goTo, getCurrent: () => i, getTotal: () => SLIDES.length };
})();
