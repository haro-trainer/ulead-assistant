/* navigation.js — command center engine.
   Expects a global `SLIDES` array (injected by build_command_center.py) matching
   schemas/session-schema.json's "slides" items.

   Zero-scroll strategy: after every render, fitToViewport() measures the ACTUAL rendered size of
   the critical containers and shrinks a single --scale custom property in small steps until nothing
   overflows — down to a hard MIN_SCALE floor that keeps secondary text >=12px and primary narrative
   text >=15px (see templates/theme.css base sizes). If content still overflows at the floor, that is
   a genuine content-budget problem: fitToViewport() returns false and sets
   document.documentElement.dataset.fitFailed = "true" so an external test (tests/validate_no_scroll.py)
   can catch it — this script never truncates, clips, or silently scrolls to hide the difference. */
(function () {
  let i = 0;
  const el = (id) => document.getElementById(id);
  const MIN_SCALE = 0.72;
  const SCALE_STEP = 0.02;

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  function buildCard(kind, labelText, bodyHtml) {
    const wrap = document.createElement('div');
    wrap.className = `card ${kind}`;
    wrap.innerHTML = `<div class="label">${escapeHtml(labelText)}</div>${bodyHtml}`;
    return wrap;
  }

  // Maps common beat labels (and their synonyms, ES/EN) to one of the three narrative movements
  // for color coding. Unmatched labels (Abrir, Puente, Cerrar...) stay neutral by design.
  const MOVEMENT_MAP = {
    enmarcar: 'mv-enmarcar', frame: 'mv-enmarcar', framing: 'mv-enmarcar',
    declarar: 'mv-enmarcar', presentar: 'mv-enmarcar', provocar: 'mv-enmarcar',
    profundizar: 'mv-profundizar', deepen: 'mv-profundizar', narrar: 'mv-profundizar',
    historia: 'mv-profundizar', escena: 'mv-profundizar', ejemplo: 'mv-profundizar',
    analogia: 'mv-profundizar', 'analogía': 'mv-profundizar', contrastar: 'mv-profundizar',
    aplicar: 'mv-aplicar', apply: 'mv-aplicar', transferir: 'mv-aplicar',
    ejercitar: 'mv-aplicar', practicar: 'mv-aplicar', activar: 'mv-aplicar',
  };
  function movementClass(beatLabel) {
    const key = (beatLabel || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return MOVEMENT_MAP[key] || '';
  }

  function render() {
    const s = SLIDES[i];
    el('onScreenTitle').textContent = s.on_screen || '';
    el('pace').textContent = s.pace || '';
    el('counter').textContent = `${i + 1} / ${SLIDES.length}`;

    el('script').innerHTML = (s.script || [])
      .map((b) => `<span class="beat ${movementClass(b.beat)}">${escapeHtml(b.beat)}</span><p>${escapeHtml(b.text)}</p>`)
      .join('');

    // Only build a card for fields that actually have content — an omitted/empty field is not
    // rendered at all, and the other cards' flex:1 automatically fills the freed space.
    const side = el('side');
    side.innerHTML = '';
    const hasQuestions = Array.isArray(s.questions) && s.questions.filter((q) => q && q.trim()).length > 0;
    const hasExercise = typeof s.exercise === 'string' && s.exercise.trim().length > 0;
    const hasWatch = typeof s.watch_for === 'string' && s.watch_for.trim().length > 0;

    if (hasQuestions) {
      const items = s.questions.filter((q) => q && q.trim())
        .map((q) => `<li>${escapeHtml(q)}</li>`).join('');
      side.appendChild(buildCard('questions', 'Ask the audience', `<ul>${items}</ul>`));
    }
    if (hasExercise) {
      side.appendChild(buildCard('exercise', 'Possible exercise', `<p>${escapeHtml(s.exercise)}</p>`));
    }
    if (hasWatch) {
      side.appendChild(buildCard('watch', 'Watch for', `<p>${escapeHtml(s.watch_for)}</p>`));
    }

    const isLast = i === SLIDES.length - 1;
    el('transition').textContent = s.transition
      ? s.transition
      : (isLast ? 'End of session — no further transition.' : '');

    el('progress').style.width = `${((i + 1) / SLIDES.length) * 100}%`;
    el('prevBtn').disabled = i === 0;
    el('nextBtn').disabled = isLast;

    // Reset to full scale on every slide change, then let fitToViewport() shrink only as much as
    // this specific slide's content actually needs.
    document.documentElement.style.setProperty('--scale', '1');
    document.documentElement.removeAttribute('data-fit-failed');
    requestAnimationFrame(() => fitToViewport());
  }

  // --- Zero-scroll auto-fit ---
  const CRITICAL_SELECTORS = [
    'html', 'body', '.cc', 'header', '.body', '.talk-track', '.script', '.side',
    '.card', '.card ul', '.card p', 'footer', '.transition', '.transition .text', '.nav',
  ];

  function isOverflowing() {
    const doc = document.documentElement;
    if (doc.scrollHeight > doc.clientHeight + 1 || doc.scrollWidth > doc.clientWidth + 1) return true;
    for (const sel of CRITICAL_SELECTORS) {
      const nodes = document.querySelectorAll(sel);
      for (const node of nodes) {
        if (node.scrollHeight > node.clientHeight + 1) return true;
        if (node.scrollWidth > node.clientWidth + 1) return true;
      }
    }
    return false;
  }

  function fitToViewport() {
    const root = document.documentElement;
    let scale = 1;
    root.style.setProperty('--scale', scale.toFixed(3));
    if (!isOverflowing()) return true;

    while (scale > MIN_SCALE) {
      scale = Math.max(MIN_SCALE, scale - SCALE_STEP);
      root.style.setProperty('--scale', scale.toFixed(3));
      if (!isOverflowing()) return true;
    }
    // Even at the readability floor, content still overflows: this is a real content-budget
    // violation, not something the layout can absorb. Flag it instead of hiding it.
    root.dataset.fitFailed = 'true';
    return false;
  }

  function next() { if (i < SLIDES.length - 1) { i++; render(); } }
  function prev() { if (i > 0) { i--; render(); } }
  function goTo(n) { i = Math.max(0, Math.min(SLIDES.length - 1, n)); render(); }

  // --- Jump to slide by typing a number ---
  let jumpBuffer = '';
  let jumpTimeout = null;
  const jumpOverlay = el('jumpOverlay');
  const jumpValue = el('jumpValue');

  function showJumpOverlay() {
    jumpValue.textContent = jumpBuffer || '\u2014';
    jumpOverlay.classList.add('visible');
    clearTimeout(jumpTimeout);
    jumpTimeout = setTimeout(cancelJump, 2500);
  }
  function cancelJump() {
    jumpBuffer = '';
    jumpOverlay.classList.remove('visible');
    clearTimeout(jumpTimeout);
  }
  function confirmJump() {
    if (jumpBuffer) {
      const n = parseInt(jumpBuffer, 10) - 1;
      if (!isNaN(n)) goTo(n);
    }
    cancelJump();
  }

  document.addEventListener('keydown', (e) => {
    if (/^[0-9]$/.test(e.key) && !e.metaKey && !e.ctrlKey && !e.altKey) {
      e.preventDefault();
      jumpBuffer = (jumpBuffer + e.key).slice(0, 3);
      showJumpOverlay();
      return;
    }
    if (jumpOverlay.classList.contains('visible')) {
      if (e.key === 'Enter') { e.preventDefault(); confirmJump(); return; }
      if (e.key === 'Escape') { e.preventDefault(); cancelJump(); return; }
      if (e.key === 'Backspace') {
        e.preventDefault();
        jumpBuffer = jumpBuffer.slice(0, -1);
        if (jumpBuffer) { showJumpOverlay(); } else { cancelJump(); }
        return;
      }
    }
  });

  document.addEventListener('keydown', (e) => {
    if (jumpOverlay.classList.contains('visible')) return;
    if (['ArrowRight', ' ', 'PageDown'].includes(e.key)) { e.preventDefault(); next(); }
    if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); prev(); }
    if (e.key === 'Home') { e.preventDefault(); goTo(0); }
    if (e.key === 'End') { e.preventDefault(); goTo(SLIDES.length - 1); }
  });

  el('nextBtn').addEventListener('click', next);
  el('prevBtn').addEventListener('click', prev);

  let resizeTimeout = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      document.documentElement.style.setProperty('--scale', '1');
      fitToViewport();
    }, 120);
  });

  render();

  // Exposed for testing/automation (tests/validate_no_scroll.py, tests/*.py).
  window.commandCenterNav = {
    next, prev, goTo,
    getCurrent: () => i,
    getTotal: () => SLIDES.length,
    fitToViewport,
    isOverflowing,
  };
})();
