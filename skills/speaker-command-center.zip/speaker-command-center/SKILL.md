---
name: speaker-command-center
description: >-
  Genera un "centro de comando" HTML para el orador: una vista de presenter-notes en pantalla separada
  que muestra, para cada slide, el guion narrativo (talk track) en tono cercano y relatable, preguntas
  para mantener a la audiencia enganchada, un posible ejercicio, advertencias/énfasis a cuidar, y el
  mensaje de transición hacia la siguiente idea. Navegable con flechas del teclado, visualmente claro
  para leer de un vistazo mientras se habla. Úsalo cuando el usuario pida "notas del orador en pantalla
  separada", "command center para el presentador", "algo que pueda ver mientras presento", "guion de
  presentador navegable", o quiera convertir un deck/plan de sesión en una consola de apoyo en vivo para
  quien facilita. Complementa (no reemplaza) el deck HTML dirigido a la audiencia.
---

# Speaker Command Center

Este skill genera una página HTML **para uso exclusivo del orador**, pensada para un segundo monitor
mientras el deck de audiencia se proyecta en el primero. No es una presentación — es una consola de
apoyo en vivo: en cualquier momento de la charla, el orador debe poder ver de un vistazo qué decir,
qué preguntar, qué vigilar, y cómo pasar a la siguiente idea, sin buscar entre notas desordenadas.

## Cuándo se activa

- "Genera las notas del orador en una pantalla separada / segundo monitor."
- "Necesito un command center para presentar."
- "Convierte este deck/plan de sesión en un guion navegable para el presentador."
- "Algo que pueda ver mientras hablo, con preguntas para la audiencia y las transiciones."

## Relación con otros skills

- Si ya existe un deck generado con `premium-pedagogical-presentation-builder`, este skill puede
  tomar sus `speaker_notes` y su secuencia de slides como punto de partida, pero **siempre las
  reescribe** en el formato de "beats" narrativos de este skill (ver más abajo) — las notas de un
  deck de audiencia están escritas para explicar el slide, no para ser leídas en vivo por el orador
  mientras mira un segundo monitor; la reescritura es necesaria, no opcional.
- Si no existe un deck previo, este skill puede trabajar directamente desde un plan de sesión o el
  contenido que el usuario provea en la conversación.
- Este skill nunca modifica ni reemplaza el deck de audiencia — genera un archivo HTML aparte.

## Insumos

- El contenido de la sesión: plan de clase, deck existente, o el tema/secuencia que el usuario describa.
- Opcional: número de slides del deck de audiencia y sus títulos/tipos, para mantener el contador y el
  "on screen now" sincronizados con lo que el público está viendo.
- Opcional: preferencias de tono (más formal/más cercano), duración objetivo por slide para calibrar el
  indicador de ritmo.

Si el usuario no da suficiente contenido para construir el talk track de cada slide, pregunta por el
plan de sesión antes de generar — no inventes contenido académico no respaldado por una fuente.

## Qué contiene cada entrada de slide (el "bloque" de información del orador)

Para cada slide del command center, construye:

1. **`on_screen`**: título/tipo del slide tal como aparece en el deck de audiencia — para que el
   orador siempre sepa qué está viendo el público en ese momento.
2. **`pace`**: una nota breve de ritmo ("a tiempo", "1 min adelantado") — opcional, útil si el usuario
   quiere control de tiempo, pero no inventes cifras de tiempo reales no provistas; usa una etiqueta
   cualitativa si no hay datos de timing.
3. **`script`**: el talk track narrativo, dividido en **beats cortos** (Abrir / Puente / Cerrar idea,
   u otras etiquetas que reflejen la función retórica del momento) — nunca un párrafo único largo. Cada
   beat debe sonar a algo que la persona diría en voz alta, en su propio tono, no a un resumen académico.
4. **`questions`**: 1-3 preguntas concretas para lanzar a la audiencia en ese momento, que mantengan el
   engagement (no preguntas retóricas ya respondidas en el propio guion).
5. **`exercise`**: un ejercicio breve posible para ese momento (puede ser "ninguno planeado aquí, mantén
   el ritmo" si el slide es puramente de framing — no fuerces un ejercicio donde no corresponde).
6. **`watch_for`**: un error común, mala interpretación, o énfasis que el orador debe cuidar en ese
   momento específico — información que normalmente solo tiene un facilitador experimentado.
7. **`transition`**: la frase puente hacia el siguiente slide, escrita para decirse **en voz alta,
   textualmente** — nunca una instrucción de escenario como "pasar al siguiente slide". Debe conectar
   la idea actual con la que sigue, no ser un simple "ahora veamos...".

## Reglas de redacción del talk track (lo más importante de este skill)

- **Tono narrativo y cercano ("relatable")**: escribe como si el orador le hablara a un colega, no
  como si leyera una diapositiva en voz alta. Usa contracciones y ritmo hablado cuando el idioma lo
  permita, evita jerga académica innecesaria.
- **Beats cortos, no un bloque de texto**: cada beat debe poder leerse de un vistazo (2-4 líneas máx.)
  sin que el orador pierda el hilo si levanta la vista hacia la audiencia y luego regresa.
- **Las preguntas son para lanzar, no para leer literalmente si no calzan** — redáctalas naturales,
  como las diría alguien en vivo, no como ítems de examen.
- **La transición nunca es una instrucción de producción** ("pasar al siguiente slide", "hacer clic
  en avanzar") — siempre es la frase puente real que el orador dice para conectar ideas.
- **No inventes contenido académico** que no esté respaldado por el plan/deck de origen — si hace
  falta un ejemplo o pregunta y no hay material suficiente, deriva algo razonable del contenido
  existente y no de temas ajenos a la sesión.

## Estructura visual (ver `templates/command-center-template.html`)

- **Encabezado**: qué está viendo la audiencia ahora mismo, indicador de ritmo, contador de slides.
- **Cuerpo en dos columnas**: talk track narrativo (columna ancha, tipografía grande, beats con
  etiqueta de función retórica) + columna lateral con tres tarjetas codificadas por color: preguntas
  (ámbar), ejercicio (verde azulado), a vigilar (rojo).
- **Barra inferior de transición**: visualmente distinta (violeta), siempre visible, con la frase
  puente al siguiente slide + controles de navegación.
- **Barra de progreso** en el borde superior de toda la pantalla.

Estos colores y proporciones son un punto de partida — si el usuario adjunta marca institucional,
ajusta la paleta manteniendo el mismo principio: cada tipo de información debe ser reconocible por
color sin necesidad de leer la etiqueta cada vez.

## Controles requeridos

| Tecla / control | Función |
|---|---|
| → / Espacio / Av Pág | Slide siguiente |
| ← / Re Pág | Slide anterior |
| Teclas numéricas + Enter | Saltar directamente a un slide específico (muestra un overlay con el número mientras se escribe; Esc cancela) |
| Botones visibles prev/next | Mismo efecto, con estado deshabilitado en el primer/último slide |
| Barra de progreso | Se actualiza con cada cambio de slide |
| Contador (`n / total`) | Insignia grande y de alto contraste en el encabezado — es el ancla principal de "dónde estoy", debe leerse de un vistazo sin buscarlo |

No se requiere modo pantalla completa ni notas ocultas — a diferencia del deck de audiencia, **todo**
el contenido de este HTML es siempre visible; es la herramienta del orador, no algo que deba ocultarse.

## Regla de "sin scroll" (obligatoria)

El orador no debe tener que hacer scroll en ningún momento — debe poder leer todo lo que necesita para
un slide de un vistazo, sin gestos adicionales. Para lograrlo:

- El motor (`templates/theme.css`) usa tipografía fluida basada en `vh` (`clamp(...)`) que se ajusta
  automáticamente a la altura de la ventana, en vez de tamaños fijos que puedan desbordar.
- Al redactar contenido, mantén cada slide dentro de un presupuesto razonable: **máximo 3-4 beats de
  talk track**, cada uno de **1-3 oraciones cortas**; **máximo 3 preguntas**; el ejercicio y "a vigilar"
  en **1-2 oraciones** cada uno. Si el contenido real de la sesión exige más, divide ese momento en dos
  entradas de slide en vez de sobrecargar una sola.
- El `overflow-y:auto` en el panel de talk track y en las tarjetas laterales es una **red de seguridad**,
  no el mecanismo principal — si el contenido generado activa el scroll en un uso normal, es señal de
  que el texto es demasiado largo y debe acortarse, no de que el diseño está funcionando como se espera.
- Antes de entregar, si es posible, verifica visualmente (o pide al usuario confirmar) que ningún panel
  necesitó scroll con el contenido real generado.

## Flujo de trabajo

1. **Reunir el contenido de la sesión** (deck existente, plan de clase, o lo que el usuario describa
   en la conversación). Si es insuficiente, pregunta antes de continuar.
2. **Construir un bloque de orador por cada slide** siguiendo la sección "Qué contiene cada entrada de
   slide" — con especial cuidado en que el talk track suene hablado, no leído.
3. **Verificar continuidad**: la `transition` del slide N debe conectar naturalmente con el `on_screen`
   o el primer beat del slide N+1 — léelos en secuencia antes de entregar y ajusta si el salto se
   siente abrupto.
4. **Construir el JSON de entrada** según `schemas/session-schema.json`.
5. **Generar el HTML** con `scripts/build_command_center.py`.
6. **Revisar contra `checklists/quality-checklist.md`** antes de entregar.
7. **Entregar el archivo `.html`** — recuerda al usuario que es para uso exclusivo del orador (nunca
   proyectarlo a la audiencia).

## Reglas no negociables

- Nunca mezcles contenido dirigido a la audiencia con contenido de facilitación en el mismo archivo —
  este HTML es exclusivamente para el orador.
- Nunca escribas la transición como instrucción de escenario — siempre como frase real a decir en voz
  alta.
- Nunca generes un solo bloque de texto largo como talk track — siempre en beats cortos y escaneables.
- Nunca inventes preguntas, ejercicios o advertencias desconectadas del contenido real de la sesión.
- Nunca dejes un slide sin al menos un beat de talk track y una frase de transición (salvo el último
  slide, que puede cerrar sin transición hacia adelante).

## Contrato de salida

- Un único archivo `[nombre-sesión]-command-center.html`, autocontenido, sin dependencias externas.
- Opcional: el JSON de entrada usado (`[nombre-sesión]-command-center-input.json`) si el usuario quiere
  poder editarlo y regenerar más adelante.
