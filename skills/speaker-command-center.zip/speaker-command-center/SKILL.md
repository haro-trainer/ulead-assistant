---
name: speaker-command-center
description: >-
  Genera un "centro de comando" HTML para el orador: una vista de presenter-notes en pantalla separada
  que muestra, para cada slide, el guion narrativo (talk track) en tono cercano y relatable, preguntas
  para mantener a la audiencia enganchada, un posible ejercicio, advertencias/énfasis a cuidar, y el
  mensaje de transición hacia la siguiente idea. Navegable con flechas del teclado o saltando a un
  número de slide, visualmente claro para leer de un vistazo mientras se habla, y garantizado sin scroll
  en ningún componente. Úsalo cuando el usuario pida "notas del orador en pantalla separada", "command
  center para el presentador", "algo que pueda ver mientras presento", "guion de presentador navegable",
  o quiera convertir un deck/plan de sesión en una consola de apoyo en vivo para quien facilita.
  Complementa (no reemplaza) el deck HTML dirigido a la audiencia.
---

# Speaker Command Center

Este skill genera una página HTML **para uso exclusivo del orador**, pensada para un segundo monitor
mientras el deck de audiencia se proyecta en el primero. No es una presentación — es una consola de
apoyo en vivo: en cualquier momento de la charla, el orador debe poder ver de un vistazo qué decir,
qué preguntar, qué vigilar, y cómo pasar a la siguiente idea, sin buscar entre notas desordenadas y
**sin nunca tener que hacer scroll**.

## Cuándo se activa

- "Genera las notas del orador en una pantalla separada / segundo monitor."
- "Necesito un command center para presentar."
- "Convierte este deck/plan de sesión en un guion navegable para el presentador."
- "Algo que pueda ver mientras hablo, con preguntas para la audiencia y las transiciones."

## Relación con otros skills

- Si ya existe un deck generado con `premium-pedagogical-presentation-builder`, este skill puede
  tomar sus `speaker_notes` y su secuencia de slides como punto de partida, pero **siempre las
  reescribe** en el formato de "beats" narrativos de este skill (ver más abajo) — las notas de un
  deck de audiencia están escritas para explicar el slide, no para ser leídas en vivo por el orador
  mientras mira un segundo monitor; la reescritura es necesaria, no opcional.
- Si no existe un deck previo, este skill puede trabajar directamente desde un plan de sesión o el
  contenido que el usuario provea en la conversación.
- Este skill nunca modifica ni reemplaza el deck de audiencia — genera un archivo HTML aparte, y
  mantiene con él una **relación exacta 1:1**: una entrada del orador por cada slide de audiencia,
  mismo orden, mismo título/tipo referenciado en `on_screen`. Usa `--audience-deck` en
  `scripts/build_command_center.py` para verificar esta sincronización contra el JSON de insumo del
  deck de audiencia cuando esté disponible.

## Insumos

- El contenido de la sesión: plan de clase, deck existente, o el tema/secuencia que el usuario describa.
- Opcional: número de slides del deck de audiencia y sus títulos/tipos (`audience_slide_count` en el
  esquema, o el JSON completo del deck vía `--audience-deck`), para verificar la sincronización 1:1.
- Opcional: preferencias de tono (más formal/más cercano), duración objetivo por slide para calibrar el
  indicador de ritmo.

Si el usuario no da suficiente contenido para construir el talk track de cada slide, pregunta por el
plan de sesión antes de generar — no inventes contenido académico no respaldado por una fuente.

## Qué contiene cada entrada de slide (el "bloque" de información del orador)

Para cada slide del command center, construye (ver `schemas/session-schema.json`):

1. **`on_screen`**: título/tipo del slide tal como aparece en el deck de audiencia — para que el
   orador siempre sepa qué está viendo el público en ese momento. **Requerido.**
2. **`pace`**: una nota breve de ritmo ("a tiempo", "1 min adelantado") — opcional, cualitativa, nunca
   inventes cifras de tiempo reales no provistas.
3. **`script`**: el talk track narrativo, dividido en **beats cortos** (Abrir / Puente / Cerrar idea,
   u otras etiquetas que reflejen la función retórica del momento) — nunca un párrafo único largo. Cada
   beat debe sonar a algo que la persona diría en voz alta, en su propio tono. **Requerido, 1-5 beats,
   presupuesto blando 3-4** (ver "Presupuesto editorial" abajo).
4. **`questions`**: 1-3 preguntas concretas para lanzar a la audiencia, que mantengan el engagement.
   **Opcional — omite el campo por completo si ninguna pregunta aporta valor**, nunca dejes un array
   vacío con texto de relleno.
5. **`exercise`**: un ejercicio breve posible para ese momento. **Opcional — omite el campo por
   completo si no aplica**, nunca escribas "ninguno" o similar.
6. **`watch_for`**: un error común, mala interpretación, o énfasis que el orador debe cuidar en ese
   momento específico. **Opcional, misma regla que `exercise`.**
7. **`transition`**: la frase puente hacia el siguiente slide, escrita para decirse **en voz alta,
   textualmente** — nunca una instrucción de escenario como "pasar al siguiente slide". **Requerido en
   todos los slides excepto el último.**

## Reglas de redacción del talk track (lo más importante de este skill)

- **Tono narrativo y cercano ("relatable")**: escribe como si el orador le hablara a un colega, no
  como si leyera una diapositiva en voz alta. Usa contracciones y ritmo hablado cuando el idioma lo
  permita, evita jerga académica innecesaria. La narrativa debe seguir siendo **rica, oral y llamativa**
  — el presupuesto editorial (abajo) es sobre longitud y foco, no una licencia para volverla telegráfica
  o sin valor.
- **Beats cortos, no un bloque de texto**: cada beat debe poder leerse de un vistazo (2-4 líneas máx.)
  sin que el orador pierda el hilo si levanta la vista hacia la audiencia y luego regresa.
- **Las preguntas son para lanzar, no para leer literalmente si no calzan** — redáctalas naturales,
  como las diría alguien en vivo, no como ítems de examen.
- **La transición nunca es una instrucción de producción** — siempre es la frase puente real que el
  orador dice para conectar ideas, una oración corta y completa.
- **No inventes contenido académico** que no esté respaldado por el plan/deck de origen.

## Estructura narrativa de tres movimientos: Enmarcar → Profundizar → Aplicar

Esta es la columna vertebral que hace que un talk track se sienta narrado y no leído, y lo que separa
una sesión memorable de una sesión correcta pero olvidable. **Todo slide con contenido sustantivo**
(no logística, no un receso) debe construir su `script` recorriendo estos tres movimientos, en este
orden, usando esos nombres exactos como `beat` — son la base obligatoria; beats conectores como
`Abrir`, `Puente` o `Cerrar` pueden añadirse como apertura/cierre alrededor de ellos, pero no los
reemplazan.

### 1. Enmarcar — planta la idea y lo que está en juego
Establece en una o dos frases **por qué esto importa ahora mismo**, antes de explicar el concepto. No
es un titular académico ("hoy veremos X"); es una afirmación o pregunta que crea tensión o curiosidad.

**Frases de arranque útiles para Enmarcar:**
- "Aquí va la idea que quiero que se lleven de este bloque…"
- "Antes de seguir, déjenme plantear algo que probablemente ya viven todos los días…"
- "Esta es la pregunta incómoda que casi nadie hace en voz alta…"
- "Todo lo que viene ahora depende de una sola distinción…"
- "Si solo recuerdan una frase de los próximos cinco minutos, que sea esta…"
- "Piensen en esto un segundo antes de que yo diga nada más…"

### 2. Profundizar — dale cuerpo con una escena, ejemplo o contraste concreto
Aquí vive la narrativa real: una escena que se pueda imaginar (hora, lugar, personaje, tensión), una
analogía que traduzca lo abstracto a algo cotidiano, o un contraste antes/después. Evita la explicación
puramente conceptual — un concepto sin una imagen mental no es memorable.

**Frases de arranque útiles para Profundizar:**
- "Imaginen la escena: son las ocho de la mañana y…"
- "Dejenme contarles algo que pasa en casi todas las organizaciones…"
- "Piensen en esto como [analogía cotidiana]…"
- "Hay una diferencia entre lo que la gente dice y lo que realmente hace aquí — miren…"
- "La primera vez que vi esto pasar fue…" / "Seguramente a alguno le ha pasado…"
- "Contrastemos dos escenas: la primera es… la segunda es…"

### 3. Aplicar — trae la idea de vuelta al mundo del participante
Cierra el movimiento conectando la idea con la vida profesional real de la audiencia: qué van a hacer
distinto, qué pregunta se van a llevar a su próxima reunión, cómo se ve esto en su propio trabajo. Es
lo que convierte un concepto en algo accionable y lo que la audiencia realmente recuerda después.

**Frases de arranque útiles para Aplicar:**
- "¿Cómo se vería esto en su trabajo la próxima semana?"
- "La próxima vez que alguien les pida [situación común], ahora van a poder…"
- "No hace falta esperar a mañana para probar esto — piensen en su propio caso ahora mismo…"
- "Esa es la pregunta que quiero que se lleven a su próxima reunión…"
- "Esto no es teoría: es lo que van a hacer distinto en cuanto salgan de esta sala…"

### Ejemplo de los tres movimientos encadenados

```json
"script": [
  { "beat": "Enmarcar", "text": "Aquí va la idea que quiero que se lleven de este bloque: BI empieza con una decisión, no con una tabla." },
  { "beat": "Profundizar", "text": "Imaginen a un gerente de abastecimiento un lunes a las ocho, con presupuesto y espacio limitados, decidiendo qué reponer antes del cierre. Ahí la analítica deja de ser contemplativa." },
  { "beat": "Aplicar", "text": "La próxima vez que alguien les pida 'un dashboard', pregunten primero: '¿qué decisión concreta vas a tomar con esto?'." }
]
```

### Reglas de calidad para que sea memorable, no solo correcto

- **Una escena vale más que tres adjetivos**: en vez de "esto es muy importante", describe la escena
  donde importa.
- **Usa segunda persona y presente**: "imaginen", "piensen", "ustedes van a..." — mantiene al orador
  hablándole directamente a la sala, no narrando en abstracto.
- **Un contraste bien puesto vence a una lista de características**: "no es X, es Y" es más memorable
  que enumerar atributos.
- **Los callbacks generan cohesión**: cuando tenga sentido, referencia una escena o frase de un slide
  anterior de la misma sesión — refuerza que la sesión es un solo hilo narrativo, no slides sueltos.
- **No sacrifiques precisión por dramatismo**: la escena/analogía debe seguir siendo fiel al contenido
  académico de origen — nunca la inventes para sonar interesante si distorsiona el concepto real.
- **Preguntas, ejercicio y "a vigilar" también se benefician del mismo estándar**: una pregunta que
  invite a imaginar una situación propia ("¿cuál es la última vez que ustedes...?") engancha más que
  una pregunta de definición ("¿qué es X?").

## Presupuesto editorial (límite inicial, confirmado por render real)

- **3-4 beats narrativos como máximo** por slide (límite duro: 5), cada uno breve, oral y escaneable.
  En la práctica, esto normalmente es: los tres movimientos obligatorios (Enmarcar, Profundizar,
  Aplicar) más, si hace falta, un beat conector de apertura o cierre (Abrir, Puente, Cerrar).
- El guion completo debe privilegiar una escena, ejemplo, contraste o analogía relevante — evita repetir
  la misma idea con otras palabras.
- **Máximo 2 preguntas** útiles para la audiencia por defecto; 3 solo si `validate_no_scroll.py` confirma
  que caben sin comprometer legibilidad (límite duro: 3).
- **Ejercicio y "a vigilar"**: una instrucción o idea breve cada uno, o se omiten por completo si no
  aportan valor — nunca texto de relleno como "ninguno" o "—".
- **Transición**: una frase hablada corta y completa.
- Estos números son un punto de partida, **no la fuente de verdad** — el criterio final es el tamaño
  renderizado real, porque idiomas, palabras largas y resoluciones distintas cambian el ajuste. Usa
  `scripts/build_command_center.py` (avisos blandos) y luego `tests/validate_no_scroll.py` (veredicto
  real) para confirmar.

## Regla de "cero scroll" (obligatoria, condición técnica de aceptación)

El orador nunca debe hacer scroll, y **ningún componente interno** (guion, tarjetas, lista, encabezado,
pie, transición, overlay, controles) puede tener scroll propio. Esto aplica a **todos los slides**, no
a una muestra — es una condición técnica de aceptación verificada por `tests/validate_no_scroll.py`
antes de cualquier entrega.

**Está prohibido simular que el contenido cabe mediante**: `overflow:auto`/`scroll` como mecanismo
principal, `text-overflow:ellipsis`, `-webkit-line-clamp`, recorte de texto, o reducir la tipografía por
debajo del piso de legibilidad (15px para el guion narrativo principal, 12px para todo lo demás).

**Cómo se logra (motor en `templates/theme.css` + `templates/navigation.js`):**
1. **Grid con filas/columnas que se contraen correctamente**: `100dvh` (con fallback `vh`),
   `grid-template-rows: auto minmax(0,1fr) auto`, `min-height:0` / `min-width:0` en cada contenedor
   intermedio. El encabezado y el pie crecen según su contenido (para permitir que un título largo
   pase a dos líneas sin truncarse); el área central absorbe el espacio restante.
2. **Tarjetas opcionales vacías se omiten por completo** (`navigation.js` solo construye la tarjeta de
   preguntas/ejercicio/a-vigilar si el campo tiene contenido real) — el espacio liberado se redistribuye
   automáticamente entre las tarjetas restantes vía `flex:1`.
3. **Tipografía fluida con piso duro**: una única variable `--scale` (ver `theme.css`) escala toda la
   tipografía a la vez. Tras cada render, `fitToViewport()` mide el tamaño real de los contenedores
   críticos y reduce `--scale` en pasos pequeños hasta que nada se desborda, sin bajar de `MIN_SCALE`
   (0.72), que garantiza que el texto secundario nunca caiga por debajo de 12px ni el guion narrativo
   por debajo de 15px (los tamaños base en `theme.css` están calculados para eso).
4. Si el contenido sigue sin caber incluso en el piso mínimo, `fitToViewport()` marca
   `document.documentElement.dataset.fitFailed = "true"` en vez de recortar nada — esa señal es lo que
   `tests/validate_no_scroll.py` usa para fallar la validación explícitamente.
5. **No se apilan las columnas verticalmente en pantallas angostas** (eso aumentaría la altura total y
   arriesgaría desbordamiento) — el layout de 2 columnas se mantiene, solo se ajustan proporciones y
   espaciados vía media queries.

## Política de corrección cuando un slide no cabe

Si `tests/validate_no_scroll.py` reporta una falla para un slide, corrige **en este orden** y vuelve a
validar:

1. Elimina redundancias y acorta formulaciones sin perder la historia ni la idea pedagógica.
2. Omite tarjetas opcionales que no aporten valor real (en vez de intentar comprimir su texto).
3. Ajusta distribución, espaciado y padding dentro de los límites de legibilidad ya definidos en el motor.
4. Reequilibra el ancho entre el guion y la columna lateral si un lado está sistemáticamente más
   apretado que el otro.
5. Si aún no cabe, **detén la generación** e informa explícitamente qué slide excede el presupuesto y
   qué contenido debería priorizarse — nunca entregues silenciosamente un HTML con scroll, contenido
   cortado, o tipografía ilegible.

**Nunca** dividas una entrada del orador en dos pantallas para que "quepa" — eso rompe la sincronización
1:1 con el deck de audiencia, que es una regla más importante que la comodidad de layout.

## Estructura visual (ver `templates/command-center-template.html`)

- **Encabezado**: título del slide de audiencia en curso (grande, sin recorte — puede pasar a dos
  líneas), indicador de ritmo, y un contador de slides prominente (insignia grande de alto contraste).
- **Cuerpo en dos columnas**: talk track narrativo (columna ancha) + columna lateral con hasta tres
  tarjetas codificadas por color: preguntas (ámbar), ejercicio (verde azulado), a vigilar (rojo) — solo
  se muestran las que tienen contenido real.
- **Barra inferior de transición**: visualmente distinta (violeta), siempre visible, con la frase
  puente al siguiente slide + controles de navegación.
- **Barra de progreso** en el borde superior de toda la pantalla.
- **Overlay de salto a slide**: al escribir un número aparece un overlay centrado grande mostrando el
  número tecleado; `Enter` confirma, `Esc`/`Backspace` cancelan o corrigen.

Estos colores y proporciones son un punto de partida — si el usuario adjunta marca institucional,
ajusta la paleta manteniendo el mismo principio: cada tipo de información debe ser reconocible por
color sin necesidad de leer la etiqueta cada vez. Mantén siempre contraste WCAG AA y un foco visible
en los controles interactivos (ya implementado en `theme.css` vía `:focus-visible`).

## Controles requeridos

| Tecla / control | Función |
|---|---|
| → / Espacio / Av Pág | Slide siguiente |
| ← / Re Pág | Slide anterior |
| Teclas numéricas + Enter | Saltar directamente a un slide específico (overlay mientras se escribe; Esc cancela) |
| Inicio / Fin | Primer / último slide |
| Botones visibles prev/next | Mismo efecto, con estado deshabilitado en el primer/último slide |
| Barra de progreso | Se actualiza con cada cambio de slide |
| Contador (`n / total`) | Insignia grande y de alto contraste en el encabezado |

No se requiere modo pantalla completa ni notas ocultas — a diferencia del deck de audiencia, **todo**
el contenido de este HTML es siempre visible; es la herramienta del orador, no algo que deba ocultarse.
Al cambiar de slide, el estado de navegación se reinicia (incluida la escala de tipografía, que vuelve
a 1 y se reajusta solo si ese slide lo necesita) — nunca se usa `scrollTop = 0` como sustituto de una
solución de layout, porque no debería existir scroll que resetear.

## Flujo de trabajo

1. **Reunir el contenido de la sesión** (deck existente, plan de clase, o lo que el usuario describa
   en la conversación). Si es insuficiente, pregunta antes de continuar.
2. **Construir un bloque de orador por cada slide** siguiendo la sección "Qué contiene cada entrada de
   slide", respetando el presupuesto editorial, con especial cuidado en que el talk track suene hablado.
3. **Verificar continuidad**: la `transition` del slide N debe conectar naturalmente con el `on_screen`
   o el primer beat del slide N+1 — léelos en secuencia antes de entregar y ajusta si el salto se
   siente abrupto.
4. **Construir el JSON de entrada** según `schemas/session-schema.json`.
5. **Generar el HTML** con `scripts/build_command_center.py` (valida estructura, avisa sobre presupuesto
   editorial, y opcionalmente verifica sincronización 1:1 contra el deck de audiencia).
6. **Ejecutar la validación rigurosa de cero-scroll**: `python3 tests/validate_no_scroll.py <deck.html>`
   en los 4 viewports requeridos, para todos los slides. Si falla, aplica la "Política de corrección"
   de arriba y repite hasta pasar.
7. **Revisar contra `checklists/quality-checklist.md`** antes de entregar.
8. **Entregar el archivo `.html`** — recuerda al usuario que es para uso exclusivo del orador (nunca
   proyectarlo a la audiencia).

## Validación obligatoria antes de entregar

```bash
# 1. Construir (valida estructura + avisa sobre presupuesto editorial + chequeo de sincronización opcional)
python3 scripts/build_command_center.py session.json out/command-center.html --skill-root . \
    --audience-deck path/to/audience-presentation-input.json   # opcional

# 2. Validación rigurosa de cero-scroll en los 4 viewports requeridos, todos los slides
python3 tests/validate_no_scroll.py out/command-center.html

# 3. Suite completa (navegación, salto por número, integridad de contenido, cero-scroll)
python3 -m pytest tests/ -v
```

No se declara completo un Command Center si `validate_no_scroll.py` reporta cualquier falla, o si algún
test de la suite no pudo ejecutarse por una limitación real del entorno (en ese caso, se documenta la
limitación explícitamente en vez de asumir que pasó).

## Reglas no negociables

- Nunca mezcles contenido dirigido a la audiencia con contenido de facilitación en el mismo archivo.
- Nunca escribas la transición como instrucción de escenario.
- Nunca generes un solo bloque de texto largo como talk track.
- Nunca inventes preguntas, ejercicios o advertencias desconectadas del contenido real de la sesión.
- Nunca dejes un slide sin al menos un beat de talk track y una frase de transición (salvo el último).
- Nunca entregues un Command Center con scroll, clipping, texto oculto, o tipografía por debajo del
  piso de legibilidad — la validación de `tests/validate_no_scroll.py` es la condición de aceptación.
- Nunca rompas la sincronización 1:1 con el deck de audiencia dividiendo una entrada en dos pantallas.

## Contrato de salida

- Un único archivo `[nombre-sesión]-command-center.html`, autocontenido, sin dependencias externas.
- Opcional: el JSON de entrada usado (`[nombre-sesión]-command-center-input.json`) si el usuario quiere
  poder editarlo y regenerar más adelante.
