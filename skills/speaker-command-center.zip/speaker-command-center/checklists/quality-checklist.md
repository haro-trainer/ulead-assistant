# Checklist de calidad — Speaker Command Center

## Contenido y narrativa
- [ ] Cada slide tiene al menos un beat de talk track y (salvo el último) una frase de transición.
- [ ] El talk track está en beats cortos y escaneables (presupuesto blando: 3-4), nunca un párrafo único largo.
- [ ] El tono suena hablado/cercano, no leído de una diapositiva ni académico — sigue siendo rico y útil
      para presentar, no telegráfico.
- [ ] Las preguntas están redactadas como se dirían en vivo (máximo 2 por defecto, 3 solo si el render
      real confirma que caben).
- [ ] La transición de cada slide es una frase real a decir en voz alta — nunca "pasar al siguiente slide".
- [ ] Ningún dato fue inventado sin respaldo en el plan/deck de origen.
- [ ] Ninguna tarjeta opcional (ejercicio, a vigilar, preguntas) contiene texto de relleno como "ninguno"
      o "—" — si no aporta valor, el campo se omite por completo.
- [ ] "on_screen" de cada bloque coincide con el título/tipo real del slide de audiencia correspondiente,
      y el conteo/orden es 1:1 con el deck (`audience_slide_count`, si se provee, coincide).

## Contrato de cero scroll (obligatorio, verificable)
- [ ] `python3 scripts/build_command_center.py` corrió sin errores de validación estructural.
- [ ] `python3 tests/validate_no_scroll.py <deck.html>` pasa en **1280×720, 1366×768, 1440×900 y 1920×1080**
      para **todos** los slides — no solo una muestra.
- [ ] Cero elementos con `overflow`/`overflow-x`/`overflow-y` computado como `auto` o `scroll`.
- [ ] Cero texto oculto por `text-overflow:ellipsis` o `-webkit-line-clamp` en título o transición.
- [ ] Cero contenido fuera del viewport (`off-canvas`).
- [ ] Ninguna fuente por debajo de 15px (texto narrativo principal) ni 12px (todo lo demás).
- [ ] Si `data-fit-failed="true"` aparece en algún slide, **no se entrega** — se acorta el contenido de
      ese slide siguiendo la política de corrección de `SKILL.md` y se vuelve a validar.
- [ ] Los controles de navegación (prev/next) están visibles, dentro del viewport y no cubiertos por
      otro elemento en los 4 viewports.

## Funcionamiento
- [ ] Flechas, Espacio, Av/Re Pág, Inicio, Fin, botones, y salto numérico (dígitos + Enter) funcionan.
- [ ] El archivo es autocontenido (sin dependencias externas) y nunca se confunde con el deck de audiencia.
