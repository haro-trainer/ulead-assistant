# Checklist de calidad — Speaker Command Center

- [ ] Cada slide tiene al menos un beat de talk track y (salvo el último) una frase de transición.
- [ ] El talk track está en beats cortos y escaneables, nunca un párrafo único largo.
- [ ] El tono suena hablado/cercano, no leído de una diapositiva ni académico.
- [ ] Las preguntas están redactadas como se dirían en vivo, no como ítems de examen.
- [ ] La transición de cada slide es una frase real a decir en voz alta — nunca "pasar al siguiente slide".
- [ ] Leídas en secuencia, las transiciones conectan naturalmente con el slide siguiente (sin saltos abruptos).
- [ ] Ningún dato (pregunta, ejercicio, advertencia) fue inventado sin respaldo en el plan/deck de origen.
- [ ] "on_screen" de cada bloque coincide con el título/tipo real del slide de audiencia correspondiente.
- [ ] Navegación por teclado (flechas, Espacio, Av/Re Pág, Inicio, Fin) funciona; botones se deshabilitan
      en el primer/último slide.
- [ ] El archivo es autocontenido (sin dependencias externas) y no se confunde con el deck de audiencia.
