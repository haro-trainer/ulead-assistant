# applied-case-designer

Skill especializado en diseñar la especificación completa de un **Caso práctico aplicado**: el proyecto que
un estudiante inicia durante el bloque de taller en clase y completa de forma autónoma para entregarlo al
inicio de la sesión siguiente (patrón de cadencia rotativa del modelo de práctica aplicada).

## ¿Qué lo hace distinto de `course-assessment-and-activity-designer`?

Ese skill diseña *cualquier* actividad de evaluación. Este skill está afinado para un patrón muy específico
y recurrente: arranque en vivo con el profesor presente + cierre autónomo antes de la próxima clase. Por
eso este skill:

- **Investiga en la web antes de idear** — nunca propone un proyecto genérico sacado de memoria; busca
  datasets, casos de industria o escenarios vigentes relacionados con el tema exacto de la sesión.
- **Verifica un presupuesto de tiempo explícito** para la parte que ocurre en clase — si no cabe en el
  bloque de taller disponible, el diseño se ajusta antes de entregarse.
- **Separa el diseño en dos partes desde el origen** (taller en clase / trabajo autónomo), no como una
  tarea normal a la que se le agrega una fecha límite.
- **Verifica cada herramienta contra la lista aprobada del programa** y documenta instalación/uso — nunca
  introduce una herramienta nueva sin marcarla como pendiente de aprobación.

## Instalación

Copia la carpeta `applied-case-designer/` a tu directorio de skills, junto a `university-syllabus-designer`
y `course-assessment-and-activity-designer`. Los tres son independientes pero están pensados para trabajar
en secuencia dentro del mismo programa académico.

## Uso típico

```
Ya tengo el sílabo aprobado de "Streaming, Event-Driven Architecture y Analítica en Tiempo Real".
La Sesión 3 trata sobre procesamiento con Spark Structured Streaming / Flink (ventanas, watermarks,
datos tardíos) y ahí se abre el Caso práctico aplicado 2 (25% de la nota), con 60 minutos de
taller disponibles en clase. Diséñame la especificación completa del caso.
```

Claude:

1. Confirma el contexto (tema, RA, tiempo de taller, herramientas del curso).
2. Investiga en la web escenarios/datasets reales de clickstream o eventos en tiempo real vigentes.
3. Idea un caso concreto y llamativo, dividido en Parte A (taller) y Parte B (autónoma).
4. Desglosa la Parte A en subtareas con tiempo, verificando que quepa en 60 minutos.
5. Verifica cada herramienta contra la lista aprobada del curso y busca su documentación oficial de
   instalación y uso.
6. Entrega la especificación completa: narrativa, guion de taller, guía de facilitación para el profesor,
   instrucciones de la parte autónoma, herramientas verificadas con su documentación, recursos, solución
   modelo, rúbrica y fuentes consultadas.

## Estructura del paquete

```text
applied-case-designer/
├── SKILL.md
├── README.md
├── prompts/
│   ├── research-and-ideation-prompt.md
│   ├── feasibility-check-prompt.md
│   └── tooling-and-documentation-prompt.md
├── templates/
│   ├── applied-case-spec-template.md
│   └── time-budget-template.md
├── validators/
│   └── applied-case-quality-checklist.md
└── examples/
    ├── sample-input.md
    └── sample-output.md
```

## Historial de versiones

| Versión | Cambios |
|---|---|
| v1.2 | Se agrega verificación obligatoria de **herramientas aprobadas para el programa**: toda herramienta usada en el caso debe estar en la lista aprobada (heredada del sílabo) o quedar marcada explícitamente como "pendiente de aprobación". Se agrega la sección de **documentación y guías de instalación/uso**: cada herramienta usada debe tener un enlace a su guía oficial de instalación y uno a su guía de uso específica, con fecha de consulta. Nuevo archivo `prompts/tooling-and-documentation-prompt.md`; nuevas secciones 6 y 7 en `templates/applied-case-spec-template.md`. |
| v1.1 | Se corrige el tiempo de taller por defecto: en vez de asumir ~60% de la duración total de la sesión (~108 min en una sesión de 3 horas), ahora se usa el bloque exacto **"Taller o caso práctico"** de la agenda de sesión vigente de `university-syllabus-designer` (60 min en una sesión de 3 horas), con reglas de escalamiento proporcional a otras duraciones. Se aclara que los bloques de Discusión y reflexión y Aplicación al contexto laboral no cuentan como tiempo de construcción activa. |
| v1.0 | Versión inicial del skill. |

## Límites del skill

- No define el sílabo, los resultados de aprendizaje del curso ni el peso de la evaluación — eso viene de
  `university-syllabus-designer` como insumo.
- No sustituye el criterio del profesor sobre el tiempo real disponible en su grupo: la estimación de
  tiempo es una propuesta que requiere confirmación antes de usarse con estudiantes.
- No califica entregas — para eso existe `academic-grader`.
