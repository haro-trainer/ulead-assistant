# Prompt de referencia — Verificación de factibilidad de tiempo

Este paso es lo que separa un caso "interesante en el papel" de uno realmente ejecutable en clase. No es
opcional ni se puede estimar "a ojo" sin desglosar.

## Paso 1 — Desglosar la Parte A en subtareas

Lista cada subtarea que el estudiante haría durante el taller, en el orden real en que ocurriría, incluidos
pasos que a veces se olvidan: configurar el entorno, leer el enunciado, hacer preguntas al profesor,
resolver un primer error. Asigna un tiempo estimado a cada una en minutos.

Ejemplo de desglose (no es una plantilla fija, es ilustrativo):
- Explicación del caso y arranque guiado por el profesor: 10 min
- Configuración del entorno/herramienta (si no viene preconfigurado): 15 min
- Construcción de la primera parte funcional: 40 min
- Prueba/validación inicial con el profesor circulando: 15 min
- Checkpoint grupal + resolución de bloqueos comunes: 15 min
- Cierre: qué queda para completar de forma autónoma: 5 min

## Paso 2 — Sumar y comparar contra el tiempo real disponible

Suma el desglose. Compáralo contra el tiempo de taller que el usuario indicó (o el supuesto de ~60% de la
sesión si no se dio explícitamente).

- **Si la suma excede el tiempo disponible:** recorta alcance (menos pasos, un dataset más pequeño o ya
  preparado, más starter code) o extiende el checkpoint grupal para resolver bloqueos en conjunto en vez de
  uno por uno. Vuelve a sumar después de ajustar.
- **Si la suma es notablemente menor al tiempo disponible:** el caso se queda corto — añade un paso de
  mayor profundidad (una variante, un caso borde adicional) en vez de dejar tiempo muerto.

## Paso 3 — Estimar la Parte B (trabajo autónomo)

Estima cuánto le tomaría a un estudiante promedio del programa completar lo que falta, considerando que
tiene otras responsabilidades (es un programa ejecutivo). Como referencia general, 2 a 4 horas suele ser
razonable entre sesiones semanales; si tu estimación se sale de ese rango, dilo explícitamente y explica la
razón (p. ej. "este caso integra contenido de varias sesiones porque es el cierre del módulo").

## Paso 4 — Documentar el resultado

En la especificación final (`templates/time-budget-template.md`), muestra el desglose completo y la suma,
no solo el número final — esto le permite al profesor auditar la estimación y ajustarla a su grupo real sin
tener que rehacer el análisis desde cero.
