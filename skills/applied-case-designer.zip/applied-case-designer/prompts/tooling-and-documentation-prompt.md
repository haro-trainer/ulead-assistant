# Prompt de referencia — Herramientas aprobadas y documentación oficial

## Paso 1 — Listar cada herramienta que el caso realmente usa

Revisa la Parte A y la Parte B del caso y extrae una lista exhaustiva de herramientas/tecnologías
requeridas (lenguajes, librerías, plataformas, servicios cloud, cuentas free-tier). No omitas herramientas
"obvias" o de infraestructura (p. ej. Docker, si el caso lo necesita para levantar algo localmente).

## Paso 2 — Verificar cada una contra la lista aprobada del programa

Para cada herramienta de la lista:
- **Está en la lista aprobada** → continúa, no requiere nada especial.
- **No está en la lista aprobada** → no la uses en silencio. Dos opciones:
  1. Busca una alternativa equivalente que sí esté aprobada y ajusta el caso para usarla.
  2. Si no hay alternativa razonable, propón explícitamente la herramienta nueva, explica por qué el caso
     la necesita, y márcala como "pendiente de aprobación" en la especificación — nunca la dejes como si ya
     estuviera aprobada.

## Paso 3 — Buscar documentación oficial de instalación y de uso

Para cada herramienta que sí se usará (aprobada o pendiente de aprobación), ejecuta `web_search`/
`web_fetch` para encontrar:

1. **Guía de instalación / inicio rápido** — busca términos como "[herramienta] official quickstart",
   "[herramienta] installation guide", o el nombre de la sección "Getting Started" del sitio oficial.
2. **Guía de uso específica** — no basta con la portada de la documentación; busca la página que cubre
   exactamente el concepto o la API que el caso usa (p. ej., si el caso usa ventanas de tiempo en Spark
   Structured Streaming, el enlace debe apuntar a la sección de "Window Operations", no solo a la guía
   general).

Reglas:
- Prioriza siempre el dominio oficial de la herramienta (su sitio de documentación, no un blog o tutorial
  de terceros) — verifica que el dominio corresponda al proyecto/empresa real antes de citarlo.
- Si la herramienta no tiene documentación oficial accesible o suficientemente clara, puedes usar una
  fuente de terceros de buena calidad (documentación de un proveedor cloud oficial, tutorial de una
  universidad reconocida), pero dilo explícitamente en la especificación.
- Registra la fecha de consulta — versiones y URLs de documentación cambian.
- Si la herramienta tiene múltiples versiones activas (p. ej. Spark 3.x vs 4.x), prioriza la versión que
  el programa ya esté usando; si no se sabe cuál, usa la documentación de la versión estable más reciente y
  dilo.

## Paso 4 — Documentar en la especificación

Usa la tabla de `templates/applied-case-spec-template.md` sección 7:

| Herramienta | ¿Aprobada? | Guía de instalación | Guía de uso específica | Fecha de consulta |
|---|---|---|---|---|

No dejes ninguna fila sin al menos un enlace de instalación y uno de uso, salvo que la herramienta ya esté
preconfigurada por el curso (en cuyo caso, dilo en vez de dejar la celda vacía sin explicación).
