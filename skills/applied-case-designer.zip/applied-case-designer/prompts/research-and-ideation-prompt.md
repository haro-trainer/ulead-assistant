# Prompt de referencia — Investigación e ideación

Objetivo: llegar a un caso práctico fundamentado en algo real y vigente, no en la primera idea genérica que
venga a la mente.

## Paso 1 — Extraer el "núcleo técnico" de la sesión

Identifica en 1-2 frases qué habilidad concreta se practica (p. ej. "configurar ventanas de tiempo y
watermarks en un pipeline de streaming para manejar datos tardíos"). Todo lo que investigues y propongas
debe servir a ese núcleo, no a un tema adyacente.

## Paso 2 — Buscar 2-3 ángulos reales antes de elegir

Ejecuta búsquedas específicas (no genéricas) combinando el núcleo técnico con posibles industrias o
escenarios, por ejemplo:
- "[tema técnico] caso de uso [industria 1]"
- "[tema técnico] dataset público"
- "[herramienta del curso] ejemplo aplicado [año actual]"

Para cada ángulo encontrado, anota: la fuente, qué la hace interesante/vigente, y si hay datos o
documentación reales disponibles para usar (no solo una idea sin sustento).

## Paso 3 — Elegir y justificar

Elige el ángulo que mejor combine: relevancia estricta al tema, atractivo narrativo, y disponibilidad de
datos o herramientas reales para trabajar en el tiempo disponible. Escribe 2-3 líneas explicando por qué
se eligió ese y no los otros — esto ayuda al profesor a entender la decisión y a pedir un cambio informado
si lo prefiere.

## Qué evitar

- Proyectos "de juguete" desconectados de un escenario real (p. ej. "cuenta las palabras de un texto"
  cuando el tema es arquitecturas de streaming empresariales).
- Reciclar el mismo tipo de escenario en sesiones consecutivas (si el caso anterior ya usó una empresa de
  ecommerce, busca variar la industria o el ángulo en el siguiente, salvo que el programa tenga un
  proyecto integrador que deba mantenerse consistente — en ese caso, dilo explícitamente).
- Datos o estadísticas presentadas como reales sin haberlas verificado por búsqueda.
