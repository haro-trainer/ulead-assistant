# Plantilla — Presupuesto de tiempo (Parte A, taller en clase)

**Tiempo de taller disponible por defecto: 60 minutos** (bloque "Taller o caso práctico" de la agenda de
sesión vigente, para una sesión de 3 horas — ver
`university-syllabus-designer/references/agenda-sesion-tipo.md`). Si la sesión del usuario dura distinto,
escala este valor proporcionalmente (33.3% de la duración total) y decláralo como supuesto.

## Desglose

| # | Subtarea | Tiempo (min) | Acumulado (min) |
|---|---|---|---|
| 1 | [...] | [...] | [...] |
| 2 | [...] | [...] | [...] |
| 3 | [...] | [...] | [...] |
| ... | | | |
| **Total** | | **[suma]** | |

## Verificación

```
Tiempo de taller disponible:  [X] min
Tiempo total del guion:       [Y] min
Diferencia:                   [X - Y] min
```

- Si `Y > X`: **no factible tal como está** — recorta alcance o simplifica antes de entregar la
  especificación. Documenta qué se recortó y por qué en la sección de trazabilidad.
- Si `Y` es mucho menor que `X` (más de ~15-20% de holgura sin usar): el caso probablemente se queda corto
  — añade profundidad antes de entregar.
- Si `Y ≈ X` (dentro de un margen razonable, ~10%): factible, procede.

## Estimación de la Parte B (trabajo autónomo)

| Aspecto | Estimación |
|---|---|
| Tiempo estimado para completar | [horas] |
| ¿Dentro del rango típico (2-4 h)? | [sí/no — si no, justificar] |
| Justificación si se sale del rango | [...] |
