# Plantilla — Especificación completa del Caso práctico aplicado

```markdown
# Caso práctico aplicado [#] — [Nombre llamativo del caso]

## 1. Ficha resumen

| Campo | Valor |
|---|---|
| Curso / Sesión | [curso] — Sesión [#] |
| Resultado(s) de aprendizaje evaluado(s) | [RA #, texto] |
| Peso en la evaluación | [%] |
| Se abre en | Sesión [#] (taller en clase) |
| Se entrega al inicio de | Sesión [#+1] |
| Tiempo de taller disponible en clase | [minutos] |
| Tiempo estimado de trabajo autónomo | [horas] |
| Herramientas/tecnologías usadas | [lista, ya vistas en el curso] |

## 2. Narrativa / escenario

[2-4 párrafos que presentan el problema o caso de forma concreta y atractiva: quién es el "cliente" o
contexto, qué problema real enfrenta, por qué importa. Debe conectar con el contexto laboral del
estudiante. Fundamentado en la investigación de la Fase 2 — cita fuente si usas datos/casos reales.]

## 3. Parte A — Guion de taller en clase

**Tiempo total disponible:** [minutos] | **Tiempo total del guion:** [minutos] (ver
`time-budget-template.md` para el desglose completo)

| Subtarea | Tiempo | Qué hace el estudiante | Punto de arranque provisto |
|---|---|---|---|
| [ej. Explicación + arranque guiado] | [min] | [...] | [...] |
| [ej. Construcción de la primera parte] | [min] | [...] | [starter code / dataset / plantilla] |
| [ej. Checkpoint grupal] | [min] | [...] | — |
| [ej. Cierre: qué queda pendiente] | [min] | [...] | — |

**Al finalizar el taller, el estudiante debe tener:** [estado concreto y verificable — no "haber avanzado
algo", sino un hito observable, p. ej. "un topic de Kafka creado y publicando al menos 10 eventos de
prueba"].

## 4. Parte B — Trabajo autónomo (entre sesiones)

**Tiempo estimado:** [horas]

**Qué falta completar:**
1. [...]
2. [...]

**Qué debe entregar:** [formato exacto, dónde, cómo]

## 5. Guía de facilitación para el profesor

- **Cómo lanzar el taller:** [primeras instrucciones, qué mostrar/decir]
- **Bloqueos comunes y cómo destrabarlos:** [2-4 problemas típicos y su solución rápida]
- **Cuándo hacer el checkpoint grupal:** [momento sugerido]
- **Cómo cerrar el bloque de clase:** [qué decir para que quede claro qué sigue de forma autónoma]

## 6. Herramientas utilizadas

| Herramienta | ¿Aprobada para el programa? | Uso en este caso |
|---|---|---|
| [...] | Sí / No — pendiente de aprobación | [para qué se usa en la Parte A o B] |

*(Si alguna herramienta está marcada "pendiente de aprobación", explica aquí mismo por qué es necesaria y
qué alternativa aprobada se consideró, si la hay — ver `prompts/tooling-and-documentation-prompt.md`.)*

## 7. Documentación y guías de instalación/uso

| Herramienta | Guía de instalación | Guía de uso específica | Fecha de consulta |
|---|---|---|---|
| [...] | [enlace oficial] | [enlace oficial a la sección exacta que aplica] | [...] |

## 8. Recursos necesarios

- [Dataset, starter code, plantillas, cuentas free-tier]

## 9. Solución modelo / resultado esperado

[Descripción de una solución de referencia. Si el caso admite variantes razonables, dilo explícitamente y
por qué.]

## 10. Rúbrica de calificación

[Usar el formato de `course-assessment-and-activity-designer/templates/rubric-template.md`: criterios
ligados al RA evaluado, pesos que sumen 100% de la nota de este caso, niveles de desempeño observables.]

## 11. Fuentes consultadas (investigación de ideación, Fase 2)

| Fuente | Qué aportó | Fecha de consulta |
|---|---|---|
| [...] | [...] | [...] |

## Trazabilidad

**Supuestos realizados:** [...]
**Información faltante:** [...]
**Elementos que requieren aprobación del profesor:** [especialmente la estimación de tiempo]
```
