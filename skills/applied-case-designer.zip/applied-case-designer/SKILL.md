---
name: applied-case-designer
description: "Diseña la especificación completa de un Caso práctico aplicado: un proyecto que el estudiante inicia en el taller de clase (tiempo de práctica de la sesión) y completa de forma autónoma para entregarlo al inicio de la sesión siguiente, según la cadencia de práctica aplicada de la universidad. Investiga en la web para idear un proyecto llamativo y vigente, relevante al tema exacto de la sesión, y verifica que sea factible en el tiempo de taller disponible. Lista las herramientas usadas verificándolas contra las aprobadas del programa, e incluye enlaces a documentación oficial de instalación y uso. Úsalo cuando pidan diseñar el 'caso práctico aplicado' o el 'taller' de una sesión. No lo uses para calificar (usa academic-grader), el sílabo (usa university-syllabus-designer), ni actividades sin ese patrón taller+entrega (usa course-assessment-and-activity-designer)."
---

# Diseñador de Caso Práctico Aplicado

## Por qué existe este skill como algo separado

`course-assessment-and-activity-designer` desarrolla cualquier tipo de actividad de evaluación en general.
Pero el "Caso práctico aplicado" del modelo de práctica aplicada (ver
`university-syllabus-designer/references/modelo-practica-aplicada.md`) tiene una forma muy específica que
merece su propio proceso de diseño:

- **Nace en vivo, en el taller de clase** — el estudiante no lo recibe como un enunciado frío para hacer en
  casa; lo empieza a construir en el momento, con el profesor presente para desbloquear dudas.
- **Cruza la frontera de la sesión** — arranca dentro del bloque **"Taller o caso práctico"** de la agenda
  de sesión vigente (60 min en una sesión de 3 horas — ver
  `university-syllabus-designer/references/agenda-sesion-tipo.md`) y termina *fuera* de clase, con entrega
  al inicio de la sesión siguiente.
- **Tiene que ser genuinamente atractivo** — al repetirse sesión tras sesión, un caso práctico genérico
  ("construye un CRUD", "limpia este CSV") se vuelve predecible y pierde poder pedagógico. Cada caso debe
  sentirse como un reto real y relevante, no una tarea de relleno.
- **Tiene una restricción de tiempo dura y verificable** — si el arranque en clase no cabe en el bloque de
  taller disponible, el diseño falló, sin importar qué tan interesante sea la idea.

Este skill existe para sostener esas cuatro exigencias a la vez, cada vez que se diseña un caso práctico —
no solo la primera vez.

## Flujo de trabajo

### Fase 1 — Recolectar el contexto de la sesión

Insumos obligatorios (pídelos si faltan; no los inventes):

- Tema/contenido de la sesión en la que se abre el caso.
- Resultado(s) de aprendizaje del sílabo que este caso debe evaluar.
- Duración del bloque de taller/práctica disponible en clase. **Por defecto, este es exactamente el bloque
  "Taller o caso práctico" de la agenda de sesión vigente: 60 minutos en una sesión de 3 horas** (ver
  `university-syllabus-designer/references/agenda-sesion-tipo.md`). Si la sesión dura distinto a 3 horas,
  escala este bloque proporcionalmente según esa misma referencia (33.3% de la duración total de la
  sesión), y decláralo como supuesto si el usuario no dio el tiempo exacto de su sesión.
- Herramientas/tecnologías que el curso ya está usando (no introduzcas una herramienta nueva sin avisar).
- **Lista de herramientas aprobadas para el programa/curso.** Esta es la lista contra la que se valida
  cualquier herramienta que el caso práctico use (ver Fase 5, paso de verificación de herramientas). Debe
  heredarse del sílabo aprobado (sección 16 "Herramientas y recursos" de
  `university-syllabus-designer/templates/syllabus-template.md`) o de lo que el usuario indique
  explícitamente. Si no se recibe ninguna lista, pregúntala antes de diseñar el caso — no asumas que
  cualquier herramienta popular está aprobada para este programa.
- Peso de este caso en la evaluación del curso y sesión en la que se entrega (normalmente, el inicio de la
  sesión siguiente).

Insumos opcionales útiles: perfil de los estudiantes (industria, rol), nivel del curso, si el caso debe
conectar con un proyecto integrador más grande del programa.

### Fase 2 — Investigar antes de idear

No inventes el proyecto desde la memoria. Antes de proponer nada, usa `web_search`/`web_fetch` para
fundamentar la idea en algo vigente y real:

- Busca escenarios, datasets públicos, casos de la industria, herramientas o tendencias actuales
  directamente relacionados con el tema de la sesión — evita ejemplos de juguete genéricos que podrías
  haber escrito sin buscar nada.
- Prioriza fuentes con datos o casos reales y recientes (repositorios de datasets abiertos, documentación
  oficial de herramientas del curso, noticias o reportes de industria, papers aplicados) sobre ejemplos
  inventados.
- Si el tema lo permite, busca 2-3 ángulos distintos (p. ej. tres industrias distintas donde aplica el
  mismo concepto técnico) antes de elegir uno — esto evita quedarte con la primera idea obvia.
- Cita la fuente y la fecha de consulta de cualquier dato, dataset o caso externo que uses en la
  especificación final.

Ve `prompts/research-and-ideation-prompt.md` para el patrón de búsqueda e ideación.

### Fase 3 — Idear el caso práctico

Con la investigación en mano, diseña un caso que sea:

- **Relevante de forma estricta** al tema exacto de la sesión y al resultado de aprendizaje que evalúa —
  no una versión genérica "que también aplicaría a cualquier otra sesión".
- **Llamativo** — tiene una narrativa o un problema concreto que el estudiante pueda visualizar (una
  empresa, un escenario, una pregunta real que resolver), no una lista abstracta de requisitos técnicos.
- **Aplicable al contexto laboral** — conecta con decisiones que el estudiante tomaría en su rol o
  industria, coherente con el enfoque ejecutivo-aplicado del programa.
- **Dividido naturalmente en dos partes** desde el diseño, no como una división forzada después:
  - **Parte A (taller en clase):** lo que se construye/decide/arranca con el profesor presente, dentro del
    bloque "Taller o caso práctico" (60 min en una sesión de 3 horas).
  - **Parte B (trabajo autónomo):** lo que el estudiante completa solo, antes de la siguiente sesión.

  Los bloques de **Discusión y reflexión** y **Aplicación al contexto laboral** que siguen en la agenda de
  la misma sesión (ver `agenda-sesion-tipo.md`) pueden usarse para conversar sobre decisiones de diseño del
  caso recién abierto o su relevancia para la industria del estudiante — pero **no forman parte del
  presupuesto de tiempo de construcción activa**; no asumas minutos adicionales de esos bloques al
  verificar la factibilidad en la Fase 4.

### Fase 4 — Verificar la factibilidad de tiempo (paso crítico, no opcional)

Antes de dar el diseño por bueno, desglosa la Parte A en subtareas con tiempo estimado y súmalas. Usa
`templates/time-budget-template.md`.

- Si la suma de la Parte A **excede** el tiempo de taller disponible, **rediseña el alcance** — recorta,
  simplifica, o provee más andamiaje (starter code, plantilla, dataset ya preparado) hasta que quepa. No
  entregues un caso que no quepa en el tiempo real de la sesión "porque la idea es buena".
- Si la suma de la Parte A deja mucho tiempo libre (el caso es demasiado corto para el bloque), amplía el
  alcance de la Parte A en vez de dejar tiempo muerto en el taller.
- Estima también un tiempo razonable para la Parte B (trabajo autónomo entre sesiones) — como referencia,
  algo completable en 2 a 4 horas suele ser razonable para un programa ejecutivo con estudiantes que
  trabajan; si tu estimación se sale mucho de ese rango, dilo explícitamente y explica por qué este caso
  lo amerita.
- Documenta la estimación de tiempo de forma explícita en la especificación final — un coordinador o
  profesor debe poder ver de un vistazo que el caso es factible, no solo confiar en tu palabra.

Ve `prompts/feasibility-check-prompt.md` para el patrón de verificación.

### Fase 4.5 — Verificar herramientas aprobadas y documentar instalación/uso

Antes de redactar la especificación final, resuelve dos cosas para cada herramienta que el caso práctico
requiera:

1. **Verificación contra la lista aprobada.** Cada herramienta usada en la Parte A o la Parte B debe
   aparecer en la lista de herramientas aprobadas del programa/curso (recolectada en la Fase 1). Si el caso
   que diseñaste requiere una herramienta que no está en esa lista:
   - No la agregues en silencio. Repórtala explícitamente como una **herramienta nueva propuesta**, explica
     por qué es necesaria, y pide aprobación antes de usarla — igual disciplina que con cambios al esquema
     de evaluación en `university-syllabus-designer`.
   - Si es posible, ofrece una alternativa dentro de la lista aprobada y señala el trade-off.
2. **Documentación oficial con guía de instalación y de uso.** Para cada herramienta efectivamente usada,
   busca con `web_search`/`web_fetch` su documentación oficial vigente y localiza específicamente:
   - Un enlace a la **guía de instalación/inicio rápido** (quickstart, getting started).
   - Un enlace a la **guía de uso** relevante para lo que el caso pide hacer (p. ej. la sección de la API o
     el concepto específico que se usa, no solo la página de inicio genérica).
   - Prioriza siempre la documentación oficial de la herramienta sobre blogs o tutoriales de terceros;
     usa fuentes de terceros solo si la herramienta no tiene documentación oficial accesible, y dilo.
   - Registra la fecha de consulta de cada enlace — la documentación de software cambia con las versiones.

Ve `templates/applied-case-spec-template.md`, secciones 6 y 7, para el formato exacto de estas dos partes
en la especificación final.

### Fase 5 — Redactar la especificación completa

Usa `templates/applied-case-spec-template.md`. La especificación debe incluir:

1. Ficha resumen (tema, RA evaluado, peso, sesión de apertura y de entrega, tiempo de taller y tiempo
   estimado de trabajo autónomo).
2. Narrativa/escenario del caso (lo que lo hace llamativo y real).
3. Parte A — Guion de taller en clase: subtareas con tiempo estimado, punto de arranque provisto al
   estudiante (starter code/dataset/plantilla), y checkpoints sugeridos para el profesor.
4. Parte B — Instrucciones de trabajo autónomo: qué falta completar, formato de entrega, tiempo estimado.
5. Guía de facilitación para el profesor: cómo lanzar el taller, qué bloqueos son comunes y cómo
   destrabarlos, cómo cerrar el bloque de clase antes de que los estudiantes continúen solos.
6. **Herramientas utilizadas** — lista completa, cada una marcada como "aprobada" (ya en la lista del
   programa) o "nueva, pendiente de aprobación" (ver Fase 4.5).
7. **Documentación y guías de instalación/uso** — tabla con, para cada herramienta: enlace a la guía de
   instalación, enlace a la guía de uso específica, y fecha de consulta (ver Fase 4.5).
8. Recursos necesarios (dataset, starter code, cuentas free-tier si aplica).
9. Solución modelo o resultado esperado, aclarando si admite variantes válidas.
10. Rúbrica de calificación (puedes reutilizar `templates/rubric-template.md` de
    `course-assessment-and-activity-designer` como formato).
11. Fuentes consultadas en la investigación de ideación (Fase 2), con fecha de consulta — distintas de las
    fuentes de documentación técnica de la Fase 4.5, aunque pueden solaparse.

### Fase 6 — Control de calidad y trazabilidad

Recorre `validators/applied-case-quality-checklist.md` completo. Cierra siempre con: supuestos realizados,
información faltante, y elementos que requieren aprobación del profesor antes de usarse con estudiantes
(especialmente la estimación de tiempo, que depende del grupo real, y cualquier herramienta nueva
propuesta que no estuviera en la lista aprobada).

## Archivos de referencia

- `prompts/research-and-ideation-prompt.md` — cómo investigar y generar 2-3 ángulos antes de elegir uno.
- `prompts/feasibility-check-prompt.md` — cómo desglosar y verificar el presupuesto de tiempo.
- `prompts/tooling-and-documentation-prompt.md` — cómo verificar herramientas contra la lista aprobada y
  encontrar su documentación oficial de instalación/uso.
- `templates/applied-case-spec-template.md` — estructura completa de la especificación (11 secciones).
- `templates/time-budget-template.md` — formato de desglose de tiempo de la Parte A.
- `validators/applied-case-quality-checklist.md` — checklist de calidad antes de entregar.
- `examples/sample-input.md` y `examples/sample-output.md` — ejemplo funcional completo.

## Relación con los otros skills

- **`university-syllabus-designer`** define el modelo de práctica aplicada, la agenda de sesión de 6
  bloques y el esquema de evaluación a nivel de curso — este skill no los redefine, los hereda como
  contexto de entrada (tema de sesión, RA, peso, y el tiempo exacto del bloque "Taller o caso práctico").
- **`course-assessment-and-activity-designer`** sigue siendo el skill de propósito general para tareas,
  quizzes, exámenes y proyectos que **no** siguen el patrón específico taller-en-clase +
  entrega-en-la-siguiente-sesión. Si una actividad no cruza la frontera de dos sesiones ni tiene un
  componente de arranque en vivo, ese es el skill correcto, no este.
- Si el usuario ya tiene un sílabo con la cadencia de casos prácticos rotativos y pide "desarróllame el
  caso práctico de la sesión 3", este es el skill que debe usarse.
