# Ejemplo de salida — Especificación completa (extracto)

> Generado a partir de `sample-input.md`, siguiendo las 7 fases de `SKILL.md`. Este extracto muestra las
> secciones más ilustrativas de la especificación completa (la 1, 2, 3, 4, 6, 7 y 11).

---

## Fase 2 (investigación) — resumen de lo encontrado

Se investigaron tres ángulos reales antes de elegir:

1. **Detección de abandono de carrito por sesión ("sessionization")** — un patrón estándar de la industria
   donde se agrupan eventos de clickstream por ventanas de tiempo para detectar cuándo un usuario abandona
   el proceso de compra; usado explícitamente como caso de enseñanza por Databricks en su demo de streaming
   avanzado para ilustrar ventanas y sesiones.
2. **Analítica de tendencias en tiempo real sobre Wikipedia** — Confluent y IBM tienen demos públicas donde
   se procesan ediciones/clics reales de Wikipedia con Kafka + Spark/ksqlDB para detectar temas en
   tendencia, usando un dataset público real de clickstream.
3. **Dashboard de comportamiento de usuario en ecommerce** — patrón genérico de clickstream→Kafka→Spark
   ampliamente documentado, pero sin un ángulo de negocio tan concreto como el abandono de carrito.

**Ángulo elegido: detección de abandono de carrito en tiempo real.** Se eligió sobre los otros dos porque
conecta directamente con el proyecto integrador omnicanal del programa (retail/ecommerce), tiene una acción
de negocio clara y accionable (disparar una alerta de marketing), y su lógica —agrupar eventos por sesión
dentro de una ventana de tiempo y decidir si la sesión "expiró" sin checkout— es exactamente el núcleo
técnico de la sesión (ventanas + watermark + datos tardíos), no un ejercicio adyacente.

**Fuentes consultadas:**
- Databricks, "Spark Streaming — Advanced" (demo de sessionization para detección de abandono de carrito),
  consultado el 16 de julio de 2026.
- Confluent, blog de clickstream con ksqlDB/Kafka Connect/Elasticsearch, consultado el 16 de julio de 2026
  (referencia de arquitectura, no se usa su dataset directamente).

---

## 1. Ficha resumen

| Campo | Valor |
|---|---|
| Curso / Sesión | Streaming, Event-Driven Architecture y Analítica en Tiempo Real — Sesión 3 |
| Resultado de aprendizaje evaluado | RA3: configurar un pipeline con ventanas de tiempo y manejo de datos tardíos |
| Peso en la evaluación | 25% |
| Se abre en | Sesión 3 (taller en clase) |
| Se entrega al inicio de | Sesión 4 |
| Tiempo de taller disponible en clase | 60 minutos (bloque "Taller o caso práctico") |
| Tiempo estimado de trabajo autónomo | ~3 horas |
| Herramientas usadas | Kafka (local o Confluent Cloud Trial), Spark Structured Streaming, Python |

## 2. Narrativa / escenario — "El carrito que se enfría"

La empresa omnicanal del proyecto integrador pierde ventas por carritos abandonados, pero su equipo de
marketing solo se entera *al día siguiente*, cuando revisa un reporte — para entonces, el cliente ya
decidió no comprar. Te contratan como ingeniero de datos para construir el primer prototipo de un sistema
que detecte, **mientras está pasando**, cuándo una sesión de compra "se enfría": el usuario agregó
productos al carrito pero no completó el checkout en un tiempo razonable. El sistema debe emitir una alerta
en cuanto detecta el abandono — no una hora después.

Este es el mismo patrón de "sessionization" que usan plataformas de streaming reales para decidir cuándo
cerrar una sesión de usuario, con la complicación extra de que algunos eventos (como un clic tardío de "iba
a pagar pero se distrajo") pueden llegar fuera de orden — exactamente el problema de datos tardíos que la
sesión de hoy enseña a resolver.

## 3. Parte A — Guion de taller en clase (60 min)

| # | Subtarea | Tiempo | Qué hace el estudiante | Punto de arranque provisto |
|---|---|---|---|---|
| 1 | Presentación del caso + arranque guiado | 5 min | Entiende el problema de negocio y el criterio de "carrito abandonado" | Enunciado + diagrama del flujo |
| 2 | Levantar el productor de eventos | 10 min | Ejecuta un script provisto que simula eventos de clickstream (`add_to_cart`, `view_item`, `checkout`) con timestamps, incluyendo algunos eventos tardíos intencionalmente | Script Python de simulación (provisto, no se escribe desde cero) |
| 3 | Construir la agregación por ventana | 25 min | Completa la lógica clave de un job de Spark Structured Streaming que agrupa eventos por `session_id` en una ventana de 10 minutos con watermark de 3 minutos, y marca como "abandonada" toda sesión con `add_to_cart` sin `checkout` al cierre de la ventana | Notebook con la estructura base ya lista (imports, lectura del topic, esqueleto de la función de ventana); el estudiante completa solo la lógica de agregación/watermark |
| 4 | Prueba rápida con un dato tardío | 10 min | Corre un caso de prueba pre-generado con un evento tardío y observa el comportamiento | Caso de prueba provisto (no se genera desde cero) |
| 5 | Checkpoint grupal | 7 min | Comparte resultados, el profesor resuelve bloqueos comunes en conjunto | — |
| 6 | Cierre: qué falta para la entrega | 3 min | Recibe instrucciones claras de la Parte B | — |
| **Total** | | **60 min** | | |

**Al finalizar el taller, el estudiante debe tener:** un job de Spark Structured Streaming corriendo
localmente que agrupa eventos simulados por sesión en ventanas de 10 minutos, con al menos una sesión
correctamente marcada como "abandonada" y haber observado (aunque sea sin documentar todavía) qué ocurre
con un evento tardío — la documentación formal de esa decisión queda para la Parte B.

*(Verificación de factibilidad: 5+10+25+10+7+3 = 60 min, coincide exactamente con el tiempo disponible del
bloque "Taller o caso práctico" — ver desglose completo con `templates/time-budget-template.md`. El bloque
posterior de Discusión y reflexión, 30 min, puede usarse para profundizar en las decisiones de ventana si
el profesor lo desea, pero no se cuenta como tiempo de construcción.)*

## 4. Parte B — Trabajo autónomo (~3 horas, entrega al inicio de Sesión 4)

Qué falta completar:
1. Conectar la salida del job a una tabla en DuckDB o PostgreSQL (ya usados en el curso) para persistir las
   alertas de abandono.
2. Construir un dashboard simple en Streamlit que muestre las sesiones abandonadas en tiempo casi-real
   (refrescando cada X segundos).
3. Documentar en un README de 1 página: qué tamaño de ventana y watermark se eligió y por qué, y qué pasaría
   si un cliente real tardara más de 10 minutos en pagar de forma legítima (falso positivo).

**Qué debe entregar:** repositorio Git con el pipeline completo, el dashboard, y el README de decisiones.

## 6. Herramientas utilizadas

| Herramienta | ¿Aprobada para el programa? | Uso en este caso |
|---|---|---|
| Python | Sí | Script de simulación de eventos de clickstream (Parte A) |
| Apache Kafka (local, vía Docker) | Sí | Topic donde se publican los eventos simulados |
| Spark Structured Streaming | Sí | Job de agregación por ventana con watermark (Parte A y B) |
| DuckDB o PostgreSQL | Sí | Persistencia de las alertas de abandono (Parte B) |
| Streamlit | Sí | Dashboard simple de sesiones abandonadas (Parte B) |
| Docker | Sí | Levantar Kafka local sin instalación nativa |

Ninguna herramienta nueva fue necesaria fuera de la lista aprobada del curso (ver `sample-input.md`).

## 7. Documentación y guías de instalación/uso

| Herramienta | Guía de instalación | Guía de uso específica | Fecha de consulta |
|---|---|---|---|
| Apache Kafka | [Quickstart oficial de Kafka](https://kafka.apache.org/quickstart/) — descarga, arranque del broker y creación de un topic | [Quickstart oficial de Kafka](https://kafka.apache.org/quickstart/) — sección de producer/consumer para publicar y leer eventos | 29 de julio de 2026 |
| Spark Structured Streaming | Instalación cubierta en la guía general de Spark enlazada desde el [Structured Streaming Programming Guide](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html) | Misma guía, sección de operaciones de ventana ("Window Operations on Event Time") para la lógica de ventana/watermark que pide el caso | 29 de julio de 2026 |
| Docker | [Documentación oficial de instalación de Docker](https://docs.docker.com/get-started/get-docker/) | [Docker — guía "Get started"](https://docs.docker.com/get-started/) | 29 de julio de 2026 |
| DuckDB | [Documentación oficial de instalación de DuckDB](https://duckdb.org/docs/installation/) | [Guía de uso de la API Python de DuckDB](https://duckdb.org/docs/api/python/overview) | 29 de julio de 2026 |
| Streamlit | [Guía oficial de instalación de Streamlit](https://docs.streamlit.io/get-started/installation) | [Guía oficial "Get started" de Streamlit](https://docs.streamlit.io/get-started) | 29 de julio de 2026 |

*(Estos enlaces deben re-verificarse en el momento real de uso del caso, ya que la documentación de
software cambia de versión con frecuencia; la fecha de consulta queda registrada para trazabilidad.)*

## 11. Fuentes consultadas (investigación de ideación, Fase 2)

| Fuente | Qué aportó | Fecha de consulta |
|---|---|---|
| Databricks — "Spark Streaming — Advanced" (demo de sessionization) | Validó el patrón de abandono de carrito vía sessionization como caso de enseñanza estándar de la industria | 16 de julio de 2026 |
| Confluent — blog de clickstream con ksqlDB/Kafka Connect | Referencia de arquitectura para el flujo eventos→Kafka→procesamiento→visualización | 16 de julio de 2026 |

## Trazabilidad

**Supuestos realizados:**
- Se usó el tiempo de taller por defecto de la agenda vigente (60 min, bloque "Taller o caso práctico" de
  una sesión de 3 horas) al no haberse indicado un tiempo distinto en la conversación de ejemplo — pendiente
  de confirmar contra la agenda real del profesor.
- Se estimó la Parte B en ~3 horas, dentro del rango típico de 2-4 horas para el programa.
- Todas las herramientas usadas ya estaban en la lista aprobada del curso (sección "Herramientas ya vistas
  en el curso" de `sample-input.md`); no fue necesario proponer ninguna herramienta nueva.

**Información faltante:** ninguna crítica para este ejemplo; en un caso real, confirmar si el profesor
prefiere Confluent Cloud Trial o Kafka local según el acceso del grupo.

**Elementos que requieren aprobación del profesor:**
- Validar que 10 min de ventana / 3 min de watermark sea el valor pedagógicamente deseado (se eligió por
  ser fácil de verificar en clase, no porque sea el único valor correcto).
- Confirmar el tiempo real de taller disponible en su grupo antes de usar este guion tal cual.
