# Ejemplo de entrada — Caso funcional

## Contexto de sesión (heredado del sílabo aprobado)

- **Curso:** Streaming, Event-Driven Architecture y Analítica en Tiempo Real (Máster en Big Data Analytics).
- **Sesión:** 3 — "Procesamiento con Flink / Spark Structured Streaming".
- **Núcleo técnico de la sesión:** ventanas de tiempo, watermarks y manejo de datos tardíos en streaming.
- **Resultado de aprendizaje evaluado:** RA3 — "Configurar un pipeline de streaming con Kafka y Spark
  Structured Streaming o Flink que procese eventos con ventanas de tiempo y maneje datos tardíos."
- **Este caso corresponde a:** Caso práctico aplicado 2 (25% de la nota final).
- **Se abre en:** Sesión 3 | **Se entrega al inicio de:** Sesión 4.
- **Tiempo de taller disponible en clase:** 60 minutos (bloque "Taller o caso práctico" de la agenda de
  sesión vigente, para una sesión de 3 horas — ver
  `university-syllabus-designer/references/agenda-sesion-tipo.md`).
- **Herramientas ya vistas en el curso / aprobadas para el programa:** Apache Kafka, Confluent Cloud Trial,
  Apache Flink, Spark Structured Streaming, Redpanda (opcional), PostgreSQL, DuckDB, Streamlit, Python,
  Docker, Google Colab, GitHub. *(Heredado de la sección 16 "Herramientas y recursos" del sílabo aprobado;
  el skill debe verificar contra esta lista cualquier herramienta que el caso proponga usar.)*
- **Perfil de estudiantes:** profesionales de datos/TI en formación ejecutiva (contexto omnicanal/retail
  del proyecto integrador del programa).

## Lo que el usuario pide

"Diséñame la especificación completa del Caso práctico aplicado 2 para la Sesión 3."
