# Checklist de calidad — Caso práctico aplicado

## Relevancia e ideación
- [ ] El caso está anclado al núcleo técnico exacto de la sesión (Paso 1 de
      `prompts/research-and-ideation-prompt.md`), no a un tema adyacente o genérico.
- [ ] Se investigaron al menos 2-3 ángulos reales antes de elegir uno, y la elección está justificada.
- [ ] La narrativa/escenario es concreta y atractiva — no una lista abstracta de requisitos técnicos.
- [ ] Ningún dato o caso presentado como real fue inventado sin verificarlo por búsqueda web; las fuentes
      están citadas con fecha de consulta.
- [ ] El caso no repite el mismo tipo de escenario que el caso práctico inmediatamente anterior del curso
      (salvo que exista un proyecto integrador que deba mantenerse consistente, y esto esté explícito).

## Estructura en dos partes
- [ ] La Parte A (taller en clase) y la Parte B (trabajo autónomo) están claramente separadas y la
      transición entre ambas es natural, no forzada.
- [ ] La Parte A termina en un hito concreto y verificable, no en "haber avanzado algo".
- [ ] La Parte B especifica exactamente qué falta completar y en qué formato se entrega.

## Factibilidad de tiempo (crítico)
- [ ] La Parte A está desglosada en subtareas con tiempo estimado (`templates/time-budget-template.md`).
- [ ] La suma del desglose cabe dentro del tiempo de taller disponible (o el caso fue recortado hasta que
      cupiera).
- [ ] El desglose no deja una holgura excesiva sin usar (el caso no se queda corto para el tiempo
      disponible).
- [ ] La estimación de tiempo de la Parte B está en un rango razonable (o se justificó por qué no).

## Herramientas y documentación
- [ ] Toda herramienta usada en la Parte A o la Parte B fue verificada contra la lista de herramientas
      aprobadas del programa/curso.
- [ ] Cualquier herramienta que no estuviera en la lista aprobada está marcada explícitamente como
      "pendiente de aprobación", con justificación y, si existe, alternativa aprobada considerada — nunca
      se agregó en silencio.
- [ ] Cada herramienta usada tiene, en la tabla de documentación, un enlace a guía de instalación y un
      enlace a guía de uso específica (no solo la portada genérica de la documentación).
- [ ] Los enlaces de documentación priorizan la fuente oficial de la herramienta sobre blogs o tutoriales de
      terceros, salvo que se indique explícitamente que no hay documentación oficial accesible.
- [ ] Cada enlace de documentación tiene su fecha de consulta registrada.

## Facilitación y recursos
- [ ] La guía de facilitación para el profesor incluye cómo lanzar el taller, bloqueos comunes y cómo
      cerrar el bloque de clase.
- [ ] Los recursos necesarios (dataset, starter code, herramientas) están completos y usan tecnologías ya
      vistas en el curso, salvo que se justifique introducir una nueva.

## Evaluación
- [ ] La rúbrica está ligada al resultado de aprendizaje evaluado y sus pesos suman 100% de la nota de este
      caso.
- [ ] La solución modelo es coherente con lo que la Parte A + Parte B realmente piden.

## Cierre
- [ ] La especificación incluye supuestos realizados, información faltante y elementos pendientes de
      aprobación del profesor — especialmente la estimación de tiempo.
