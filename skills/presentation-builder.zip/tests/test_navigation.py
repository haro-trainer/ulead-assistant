"""Test 7 (spec section 23): previous/next controls work by keyboard and click."""


def test_keyboard_next_and_prev(page):
    assert page.evaluate("window.deckNav.getCurrent()") == 0
    page.keyboard.press("ArrowRight")
    page.wait_for_timeout(50)
    assert page.evaluate("window.deckNav.getCurrent()") == 1
    page.keyboard.press("ArrowLeft")
    page.wait_for_timeout(50)
    assert page.evaluate("window.deckNav.getCurrent()") == 0


def test_click_next_and_prev_buttons(page):
    page.click(".nav-btn.next")
    page.wait_for_timeout(50)
    assert page.evaluate("window.deckNav.getCurrent()") == 1
    page.click(".nav-btn.prev")
    page.wait_for_timeout(50)
    assert page.evaluate("window.deckNav.getCurrent()") == 0


def test_home_and_end_keys(page):
    total = page.evaluate("window.deckNav.getTotal()")
    page.keyboard.press("End")
    page.wait_for_timeout(50)
    assert page.evaluate("window.deckNav.getCurrent()") == total - 1
    page.keyboard.press("Home")
    page.wait_for_timeout(50)
    assert page.evaluate("window.deckNav.getCurrent()") == 0


def test_prev_button_disabled_on_first_slide(page):
    assert page.get_attribute(".nav-btn.prev", "disabled") is not None


def test_next_button_disabled_on_last_slide(page):
    page.keyboard.press("End")
    page.wait_for_timeout(50)
    assert page.get_attribute(".nav-btn.next", "disabled") is not None
