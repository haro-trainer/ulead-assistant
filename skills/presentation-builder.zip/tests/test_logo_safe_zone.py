"""Test 3 (spec section 23): the cover logo bounding box must not intersect the title panel."""


def _rects_intersect(a, b):
    return not (a["x"] + a["width"] <= b["x"] or a["x"] >= b["x"] + b["width"]
                or a["y"] + a["height"] <= b["y"] or a["y"] >= b["y"] + b["height"])


def test_logo_does_not_overlap_title_on_cover_slide(page):
    page.evaluate("window.deckNav.goTo(0)")
    page.wait_for_timeout(50)
    logo_box = page.query_selector(".slide.active .logo").bounding_box()
    title_box = page.query_selector(".slide.active h1").bounding_box()
    assert logo_box is not None and title_box is not None
    assert not _rects_intersect(logo_box, title_box), "Logo overlaps the title panel on the cover slide."


def test_logo_does_not_overlap_navigation(page):
    page.evaluate("window.deckNav.goTo(0)")
    page.wait_for_timeout(50)
    logo_box = page.query_selector(".slide.active .logo").bounding_box()
    for selector in [".nav-btn.prev", ".nav-btn.next"]:
        nav_box = page.query_selector(selector).bounding_box()
        assert not _rects_intersect(logo_box, nav_box), f"Logo overlaps {selector}."
