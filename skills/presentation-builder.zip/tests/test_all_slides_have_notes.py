"""Test 1 (spec section 23): 100% of slides contain a non-empty .notes element."""


def test_every_slide_has_nonempty_notes(page):
    empty = page.evaluate("""
        Array.from(document.querySelectorAll('.slide')).map((s, i) => ({
            index: i,
            hasNotes: !!(s.querySelector('.notes') && s.querySelector('.notes').textContent.trim().length)
        })).filter(x => !x.hasNotes).map(x => x.index)
    """)
    assert empty == [], f"Slides missing notes: {empty}"


def test_notes_hidden_by_default(page):
    visible = page.evaluate(
        "Array.from(document.querySelectorAll('.notes.visible')).length"
    )
    assert visible == 0
