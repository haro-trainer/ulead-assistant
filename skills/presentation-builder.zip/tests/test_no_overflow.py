"""Test 5 (spec section 23): no primary content block may exceed the slide viewport."""
import pytest

RESOLUTIONS = [(1366, 768), (1920, 1080)]


@pytest.mark.parametrize("width,height", RESOLUTIONS)
def test_no_off_canvas_content_across_all_slides(deck_url, width, height):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": width, "height": height})
        page.goto(deck_url)
        page.wait_for_selector(".slide.active")
        total = page.evaluate("window.deckNav.getTotal()")

        offenders = []
        for i in range(total):
            page.evaluate(f"window.deckNav.goTo({i})")
            page.wait_for_timeout(30)
            off_canvas = page.evaluate("""
                (() => {
                    const active = document.querySelector('.slide.active');
                    const vw = window.innerWidth, vh = window.innerHeight;
                    const offenders = [];
                    active.querySelectorAll('h1, h2, .card, table').forEach(el => {
                        const r = el.getBoundingClientRect();
                        if (r.width === 0 && r.height === 0) return;
                        if (r.left < -1 || r.top < -1 || r.right > vw + 1 || r.bottom > vh + 1) {
                            offenders.push(el.tagName);
                        }
                    });
                    return offenders;
                })()
            """)
            if off_canvas:
                offenders.append((i, off_canvas))
        browser.close()

    assert offenders == [], f"Off-canvas content at {width}x{height}: {offenders}"
