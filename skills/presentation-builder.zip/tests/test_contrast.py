"""Test 4 (spec section 23) + accessibility rules from SKILL.md: no blank cards, sufficient contrast."""
import json
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).parent.parent / "scripts"
THEME_PATH = Path(__file__).parent.parent / "examples" / "sample-theme.json"


def test_theme_contrast_passes_wcag_aa():
    result = subprocess.run(
        [sys.executable, str(SCRIPTS_DIR / "audit_accessibility.py"), str(THEME_PATH)],
        capture_output=True, text=True,
    )
    report = json.loads(result.stdout)
    failing = [r for r in report["results"] if not r["passed"]]
    assert failing == [], f"Contrast pairs below WCAG AA threshold: {failing}"


def test_no_blank_cards_with_text(page):
    total = page.evaluate("window.deckNav.getTotal()")
    offenders = []
    for i in range(total):
        page.evaluate(f"window.deckNav.goTo({i})")
        page.wait_for_timeout(20)
        blank = page.evaluate("""
            Array.from(document.querySelectorAll('.slide.active .card')).filter(c => {
                const r = c.getBoundingClientRect();
                const hasText = (c.textContent || '').trim().length > 0;
                return hasText && (r.width === 0 || r.height === 0);
            }).length
        """)
        if blank:
            offenders.append((i, blank))
    assert offenders == [], f"Blank/zero-size cards with text found on slides: {offenders}"
