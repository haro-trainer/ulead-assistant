"""Test 2 (spec section 23): S toggles notes on/off, repeated across >=3 slide types/backgrounds."""
import pytest


def _bg_of(page, index):
    return page.evaluate(f"""
        (() => {{
            const s = document.querySelectorAll('.slide')[{index}];
            if (s.classList.contains('bg-dark')) return 'bg-dark';
            if (s.classList.contains('bg-brand')) return 'bg-brand';
            return 'bg-light';
        }})()
    """)


@pytest.mark.parametrize("slide_index", [0, 1, 2])
def test_notes_toggle_on_multiple_slide_types(page, slide_index):
    page.evaluate(f"window.deckNav.goTo({slide_index})")
    page.wait_for_timeout(50)
    assert page.evaluate("window.notesState.isVisible()") is False

    page.keyboard.press("KeyS")
    page.wait_for_timeout(50)
    assert page.evaluate("window.notesState.isVisible()") is True

    page.keyboard.press("KeyS")
    page.wait_for_timeout(50)
    assert page.evaluate("window.notesState.isVisible()") is False


def test_notes_only_visible_on_active_slide(page):
    page.evaluate("window.deckNav.goTo(0)")
    page.keyboard.press("KeyS")
    page.wait_for_timeout(50)
    visible_notes = page.evaluate(
        "Array.from(document.querySelectorAll('.notes.visible')).length"
    )
    assert visible_notes == 1
