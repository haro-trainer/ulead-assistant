#!/usr/bin/env python3
"""
package_skill.py — zips this skill directory (excluding scratch/output artifacts) into a
distributable .zip, after confirming the expected top-level files/folders are present.

Usage:
    python3 package_skill.py <skill_dir> <output_zip>
"""
import argparse
import sys
import zipfile
from pathlib import Path

EXPECTED_TOP_LEVEL = [
    "SKILL.md", "README.md", "CHANGELOG.md", "LICENSE-or-USAGE-NOTES.md",
    "templates", "slide-archetypes", "prompts", "schemas", "scripts",
    "checklists", "examples", "tests",
]

EXCLUDE_DIR_NAMES = {"__pycache__", ".pytest_cache", "audit", "screenshots"}


def validate_structure(skill_dir: Path):
    missing = [name for name in EXPECTED_TOP_LEVEL if not (skill_dir / name).exists()]
    return missing


def package(skill_dir, output_zip):
    skill_dir = Path(skill_dir)
    missing = validate_structure(skill_dir)
    if missing:
        print(f"WARNING: missing expected top-level items: {missing}")

    skill_name = skill_dir.name
    output_zip = Path(output_zip)
    output_zip.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(skill_dir.rglob("*")):
            if path.is_dir():
                continue
            if any(part in EXCLUDE_DIR_NAMES for part in path.relative_to(skill_dir).parts):
                continue
            arcname = Path(skill_name) / path.relative_to(skill_dir)
            zf.write(path, arcname)
            count += 1

    print(f"Packaged {count} files into {output_zip}")
    return output_zip


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir")
    parser.add_argument("output_zip")
    args = parser.parse_args()
    package(args.skill_dir, args.output_zip)
