#!/usr/bin/env python3
"""
build_deck.py — assembles a standalone HTML presentation from a presentation-input JSON
(matching schemas/presentation-input-schema.json) plus the templates in templates/.

Usage:
    python3 build_deck.py <presentation.json> <output.html> [--skill-root PATH]

This script contains real, functional builder logic for all 16 slide archetypes defined in
schemas/slide-schema.json — it does not merely describe the process.
"""
import json
import sys
import argparse
import html
from pathlib import Path


def esc(s):
    return html.escape(str(s), quote=True)


def build_cards_html(cards, cols=3):
    if not cards:
        return ""
    items = "".join(
        f'<div class="card"><p class="card-title">{esc(c.get("title",""))}</p>'
        f'<p>{esc(c.get("text",""))}</p></div>'
        for c in cards
    )
    return f'<div class="grid-cards cols-{min(max(cols,1),5)}">{items}</div>'


def build_table_html(table):
    if not table:
        return ""
    headers = "".join(f"<th>{esc(h)}</th>" for h in table.get("headers", []))
    rows = "".join(
        "<tr>" + "".join(f"<td>{esc(cell)}</td>" for cell in row) + "</tr>"
        for row in table.get("rows", [])
    )
    return f"<table><tr>{headers}</tr>{rows}</table>"


def build_quiz_html(quiz):
    if not quiz:
        return ""
    options = quiz.get("options", [])[:4]
    letters = ["A", "B", "C", "D"]
    cards = "".join(
        f'<div class="card"><p>{letters[i]}) {esc(opt)}</p></div>'
        for i, opt in enumerate(options)
    )
    return (
        f'<span class="pill">Pon a prueba tu criterio</span>'
        f'<h2>{esc(quiz.get("question",""))}</h2>'
        f'<div class="grid-cards cols-2">{cards}</div>'
    )


# --- one builder function per archetype (16 total, matches slide-archetypes/) ---

def render_cover(s, theme):
    return (
        f'<img class="logo" src="{esc(theme.get("logo_path",""))}" alt="{esc(theme.get("institution_name","")) } logo">'
        f'<div style="margin-top:auto; padding-top:48px;">'
        f'<div class="eyebrow">{esc(s.get("eyebrow",""))}</div>'
        f'<h1>{esc(s.get("title",""))}</h1>'
        + "".join(f"<p>{esc(b)}</p>" for b in s.get("body", []))
        + "</div>"
    )


def render_provocative_question(s, theme):
    return (
        f'<div style="margin:auto; max-width:80%;">'
        f'<span class="pill">{esc(s.get("eyebrow","Piensa en esto"))}</span>'
        f'<h1 style="margin-top:.4em;">{esc(s.get("title",""))}</h1></div>'
    )


def render_learning_promise(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_cards_html(s.get("cards", []), cols=3)


def render_agenda(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_cards_html(s.get("cards", []), cols=4)


def render_definition(s, theme):
    body = "".join(f"<p>{esc(b)}</p>" for b in s.get("body", []))
    return f"<span class='eyebrow'>{esc(s.get('eyebrow',''))}</span><h1>{esc(s.get('title',''))}</h1>{body}"


def render_misconceptions(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_cards_html(s.get("cards", []), cols=2)


def render_timeline(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_cards_html(s.get("cards", []), cols=4)


def render_architecture_map(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_cards_html(s.get("cards", []), cols=5)


def render_comparison(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_table_html(s.get("table", {}))


def render_case_study(s, theme):
    cards = build_cards_html(s.get("cards", []), cols=2)
    decision = s.get("body", [""])[0] if s.get("body") else ""
    return f"<h2>{esc(s.get('title',''))}</h2>{cards}<p class='eyebrow'>Decisión requerida: {esc(decision)}</p>"


def render_activity(s, theme):
    body = "".join(f"<p>{esc(b)}</p>" for b in s.get("body", []))
    return f"<span class='pill'>Tu reto</span><h1>{esc(s.get('title',''))}</h1>{body}"


def render_canvas(s, theme):
    return f"<h2>{esc(s.get('title',''))}</h2>" + build_table_html(s.get("table", {}))


def render_quiz(s, theme):
    return build_quiz_html(s.get("quiz", {}))


def render_synthesis(s, theme):
    return f"<h2>{esc(s.get('title','Ideas para llevarte'))}</h2>" + build_cards_html(s.get("cards", []), cols=3)


def render_homework(s, theme):
    cards = build_cards_html(s.get("cards", []), cols=3)
    why = s.get("body", [""])[0] if s.get("body") else ""
    return f"<h2>{esc(s.get('title','Antes de la próxima sesión'))}</h2>{cards}<p>{esc(why)}</p>"


def render_final_statement(s, theme):
    body = "".join(f"<p>{esc(b)}</p>" for b in s.get("body", []))
    return (
        f'<img class="logo" src="{esc(theme.get("logo_path",""))}" alt="{esc(theme.get("institution_name",""))} logo">'
        f'<div style="margin:auto; padding-top:56px; text-align:center; max-width:70%;">'
        f"<h1>{esc(s.get('title',''))}</h1>{body}</div>"
    )


SLIDE_BUILDERS = {
    "cover": render_cover,
    "provocative-question": render_provocative_question,
    "learning-promise": render_learning_promise,
    "agenda": render_agenda,
    "definition": render_definition,
    "misconceptions": render_misconceptions,
    "timeline": render_timeline,
    "architecture-map": render_architecture_map,
    "comparison": render_comparison,
    "case-study": render_case_study,
    "activity": render_activity,
    "canvas": render_canvas,
    "quiz": render_quiz,
    "synthesis": render_synthesis,
    "homework": render_homework,
    "final-statement": render_final_statement,
}


def render_slide(slide, index, theme):
    builder = SLIDE_BUILDERS.get(slide["type"])
    if builder is None:
        raise ValueError(f"Unknown slide type: {slide['type']}")
    inner = builder(slide, theme)
    bg = slide.get("background", "bg-light")
    active = " active" if index == 0 else ""
    notes = esc(slide.get("speaker_notes", ""))
    sid = esc(slide.get("id", f"slide-{index+1:02d}"))
    return (
        f'<section class="slide {bg}{active}" data-type="{esc(slide["type"])}" id="{sid}">'
        f"{inner}"
        f'<aside class="notes">{notes}</aside>'
        f"</section>"
    )


def build_theme_css(theme_css_template, theme):
    css = theme_css_template
    replacements = {
        "--brand-primary: #ff861e;": f"--brand-primary: {theme.get('primary', '#ff861e')};",
        "--brand-secondary: #f79a18;": f"--brand-secondary: {theme.get('secondary', '#f79a18')};",
        "--brand-dark: #202020;": f"--brand-dark: {theme.get('dark', '#202020')};",
        "--brand-light: #f4f1ed;": f"--brand-light: {theme.get('light', '#f4f1ed')};",
    }
    for old, new in replacements.items():
        css = css.replace(old, new)
    return css


def build_deck(presentation_json_path, output_path, skill_root):
    skill_root = Path(skill_root)
    data = json.loads(Path(presentation_json_path).read_text(encoding="utf-8"))

    theme = data.get("theme", {})
    slides = data.get("slides", [])
    if not slides:
        raise ValueError("presentation input has no slides")

    slides_html = "\n".join(render_slide(s, i, theme) for i, s in enumerate(slides))

    template = (skill_root / "templates" / "deck-template.html").read_text(encoding="utf-8")
    theme_css = build_theme_css((skill_root / "templates" / "theme-template.css").read_text(encoding="utf-8"), theme)
    responsive_css = (skill_root / "templates" / "responsive.css").read_text(encoding="utf-8")
    print_css = (skill_root / "templates" / "print.css").read_text(encoding="utf-8")
    navigation_js = (skill_root / "templates" / "navigation.js").read_text(encoding="utf-8")
    speaker_notes_js = (skill_root / "templates" / "speaker-notes.js").read_text(encoding="utf-8")

    output = (
        template
        .replace("{{LANG}}", esc(data.get("language", "es")))
        .replace("{{TITLE}}", esc(data.get("title", "")))
        .replace("{{THEME_CSS}}", theme_css)
        .replace("{{RESPONSIVE_CSS}}", responsive_css)
        .replace("{{PRINT_CSS}}", print_css)
        .replace("{{SLIDES_HTML}}", slides_html)
        .replace("{{SLIDE_COUNT}}", str(len(slides)))
        .replace("{{NAVIGATION_JS}}", navigation_js)
        .replace("{{SPEAKER_NOTES_JS}}", speaker_notes_js)
    )

    Path(output_path).write_text(output, encoding="utf-8")
    print(f"Deck built: {output_path} ({len(slides)} slides)")
    return output_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("presentation_json")
    parser.add_argument("output_html")
    parser.add_argument("--skill-root", default=str(Path(__file__).resolve().parent.parent))
    args = parser.parse_args()
    build_deck(args.presentation_json, args.output_html, args.skill_root)
