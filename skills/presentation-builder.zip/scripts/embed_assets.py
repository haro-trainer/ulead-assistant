#!/usr/bin/env python3
"""
embed_assets.py — replaces local image src="path/to/file.png" references in a built HTML deck
with embedded base64 data URIs, so the deck works fully offline.

Usage:
    python3 embed_assets.py <deck.html> <output.html> [--assets-dir DIR]
"""
import argparse
import base64
import mimetypes
import re
from pathlib import Path

IMG_SRC_RE = re.compile(r'src="([^"]+)"')


def to_data_uri(path: Path) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    mime = mime or "application/octet-stream"
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"


def embed_assets(deck_html_path, output_path, assets_dir=None):
    html = Path(deck_html_path).read_text(encoding="utf-8")
    assets_dir = Path(assets_dir) if assets_dir else Path(deck_html_path).parent

    embedded = 0
    missing = []

    def replace(match):
        nonlocal embedded
        src = match.group(1)
        if src.startswith("data:") or src.startswith("http://") or src.startswith("https://"):
            return match.group(0)
        candidate = assets_dir / src
        if not candidate.exists():
            missing.append(src)
            return match.group(0)
        embedded += 1
        return f'src="{to_data_uri(candidate)}"'

    new_html = IMG_SRC_RE.sub(replace, html)
    Path(output_path).write_text(new_html, encoding="utf-8")

    print(f"Embedded {embedded} local asset(s).")
    if missing:
        print(f"WARNING: {len(missing)} asset path(s) could not be resolved and were left as-is: {missing}")
    return {"embedded": embedded, "missing": missing}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("deck_html")
    parser.add_argument("output_html")
    parser.add_argument("--assets-dir", default=None)
    args = parser.parse_args()
    embed_assets(args.deck_html, args.output_html, args.assets_dir)
