#!/usr/bin/env python3
"""
render_slides.py — serves the deck locally, drives it with the same keyboard events a user
would use, captures screenshots per slide at required resolutions, toggles speaker notes with
"S" and captures notes-state screenshots, and runs audit_layout.js on each active slide.

Usage:
    python3 render_slides.py <deck.html> <output_dir> [--resolutions 1366x768,1920x1080]

Requires: playwright (pip install playwright --break-system-packages && playwright install chromium)
"""
import argparse
import http.server
import json
import socketserver
import threading
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

DEFAULT_RESOLUTIONS = ["1366x768", "1920x1080"]


def serve_directory(directory, port=0):
    handler = lambda *a, **kw: http.server.SimpleHTTPRequestHandler(*a, directory=str(directory), **kw)
    httpd = socketserver.TCPServer(("127.0.0.1", port), handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, httpd.server_address[1]


def render(deck_html_path, output_dir, resolutions=None):
    resolutions = resolutions or DEFAULT_RESOLUTIONS
    deck_path = Path(deck_html_path).resolve()
    output_dir = Path(output_dir)
    (output_dir / "screenshots").mkdir(parents=True, exist_ok=True)

    audit_js = (Path(__file__).parent / "audit_layout.js").read_text(encoding="utf-8")

    httpd, port = serve_directory(deck_path.parent)
    url = f"http://127.0.0.1:{port}/{deck_path.name}"

    all_issues = []
    slides_total = 0
    slides_with_notes = 0
    notes_toggle_ok = True
    navigation_ok = True

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            for res in resolutions:
                w, h = (int(x) for x in res.split("x"))
                page = browser.new_page(viewport={"width": w, "height": h})
                page.goto(url)
                page.wait_for_selector(".slide.active")
                slides_total = page.evaluate("window.deckNav.getTotal()")

                res_dir = output_dir / "screenshots" / res
                res_dir.mkdir(parents=True, exist_ok=True)

                for i in range(slides_total):
                    page.evaluate(f"window.deckNav.goTo({i})")
                    page.wait_for_timeout(60)

                    # Layout audit on this slide/resolution.
                    issues = page.evaluate(audit_js + "\nwindow.__auditActiveSlide();")
                    for issue in issues:
                        issue["resolution"] = res
                        all_issues.append(issue)
                        if issue["type"] == "MISSING_NOTES":
                            pass
                        elif "notes" not in issue.get("selector", ""):
                            pass
                    has_notes = page.evaluate(
                        "document.querySelector('.slide.active .notes')?.textContent.trim().length > 0"
                    )
                    if has_notes and res == resolutions[0]:
                        slides_with_notes += 1

                    slide_num = str(i + 1).zfill(2)
                    page.screenshot(path=str(res_dir / f"slide-{slide_num}.png"))

                    # Notes-state screenshots: only for first slide, one dark, one brand, one light
                    # (kept lightweight — capture notes-visible variant for slide 1 always).
                    if i == 0:
                        page.keyboard.press("KeyS")
                        page.wait_for_timeout(60)
                        visible_after_press = page.evaluate("window.notesState.isVisible()")
                        if not visible_after_press:
                            notes_toggle_ok = False
                        page.screenshot(path=str(res_dir / f"slide-{slide_num}-notes.png"))
                        page.keyboard.press("KeyS")
                        page.wait_for_timeout(60)
                        visible_after_second_press = page.evaluate("window.notesState.isVisible()")
                        if visible_after_second_press:
                            notes_toggle_ok = False

                # Navigation sanity check: keyboard ArrowRight/ArrowLeft.
                page.evaluate("window.deckNav.goTo(0)")
                page.keyboard.press("ArrowRight")
                page.wait_for_timeout(60)
                after_right = page.evaluate("window.deckNav.getCurrent()")
                page.keyboard.press("ArrowLeft")
                page.wait_for_timeout(60)
                after_left = page.evaluate("window.deckNav.getCurrent()")
                if not (after_right == 1 and after_left == 0):
                    navigation_ok = False

                page.close()
            browser.close()
    finally:
        httpd.shutdown()

    report = {
        "slides_total": slides_total,
        "slides_with_notes": slides_with_notes,
        "resolutions_tested": resolutions,
        "navigation_status": "passed" if navigation_ok else "failed",
        "notes_toggle_status": "passed" if notes_toggle_ok else "failed",
        "fullscreen_status": "not_tested",  # requires OS-level fullscreen API, not testable headless
        "contrast_status": "see audit_accessibility.py output",
        "logo_safe_zone_status": "passed" if not any(i["type"].startswith("LOGO_OVERLAP") for i in all_issues) else "failed",
        "issues": all_issues,
    }

    (output_dir / "layout-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")

    md_lines = [
        "# Layout & Screenshot Audit Report", "",
        f"- Slides total: {slides_total}",
        f"- Slides with notes (checked at {resolutions[0]}): {slides_with_notes}/{slides_total}",
        f"- Resolutions tested: {', '.join(resolutions)}",
        f"- Navigation: {report['navigation_status']}",
        f"- Notes toggle (S key): {report['notes_toggle_status']}",
        f"- Logo safe zone: {report['logo_safe_zone_status']}",
        f"- Issues found: {len(all_issues)}", "",
    ]
    if all_issues:
        md_lines.append("## Issues")
        for issue in all_issues:
            md_lines.append(
                f"- [{issue['severity'].upper()}] slide {issue.get('slide', issue.get('resolution', '?'))} "
                f"— {issue['type']}: {issue.get('details', '')}"
            )
    (output_dir / "layout-report.md").write_text("\n".join(md_lines), encoding="utf-8")

    print(json.dumps(report, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("deck_html")
    parser.add_argument("output_dir")
    parser.add_argument("--resolutions", default=",".join(DEFAULT_RESOLUTIONS))
    args = parser.parse_args()
    render(args.deck_html, args.output_dir, args.resolutions.split(","))
