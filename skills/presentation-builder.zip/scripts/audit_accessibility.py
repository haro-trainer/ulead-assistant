#!/usr/bin/env python3
"""
audit_accessibility.py — computes WCAG contrast ratios for the foreground/background color
pairs actually used by the theme (card-on-light, card-on-dark, brand gradient text, etc.)
and flags any pair below the AA thresholds (4.5:1 normal text, 3:1 large text).

Usage:
    python3 audit_accessibility.py <theme.json>
"""
import argparse
import json
import sys
from pathlib import Path


def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def relative_luminance(hex_color):
    r, g, b = (c / 255 for c in hex_to_rgb(hex_color))

    def lin(c):
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    r, g, b = lin(r), lin(g), lin(b)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast_ratio(hex_a, hex_b):
    l1, l2 = relative_luminance(hex_a), relative_luminance(hex_b)
    lighter, darker = max(l1, l2), min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)


def composite_over_black(hex_color, black_alpha):
    r, g, b = hex_to_rgb(hex_color)
    factor = 1 - black_alpha
    r, g, b = int(r * factor), int(g * factor), int(b * factor)
    return f"#{r:02x}{g:02x}{b:02x}"


# Pairs the deck engine actually uses (see templates/deck-template.html + theme-template.css).
# bg-brand renders a 38% black overlay atop the primary gradient stop (see deck-template.html),
# so the effective background near the orange end of the gradient is the composited color below,
# not the raw primary color.
PAIR_CHECKS = [
    ("text_on_light_vs_light_card", "text_on_light", "surface_card_light", 4.5),
    ("text_on_dark_vs_dark_card", "text_on_dark", "surface_card_dark", 4.5),
    ("text_on_dark_vs_brand_dark_bg", "text_on_dark", "dark", 4.5),
    ("text_on_dark_vs_brand_primary_bg_with_overlay", "text_on_dark", "__brand_primary_composited", 3.0),
]


def audit_accessibility(theme_path):
    theme = json.loads(Path(theme_path).read_text(encoding="utf-8"))

    defaults = {
        "text_on_light": "#202020",
        "text_on_dark": "#ffffff",
        "surface_card_light": "#ffffff",
        "surface_card_dark": "#2b2b2b",
    }
    merged = {**defaults, **theme}
    merged["__brand_primary_composited"] = composite_over_black(merged.get("primary", "#ff861e"), 0.38)

    issues = []
    results = []
    for name, fg_key, bg_key, threshold in PAIR_CHECKS:
        fg = merged.get(fg_key)
        bg = merged.get(bg_key)
        if not fg or not bg:
            continue
        ratio = round(contrast_ratio(fg, bg), 2)
        passed = ratio >= threshold
        results.append({"pair": name, "fg": fg, "bg": bg, "ratio": ratio, "threshold": threshold, "passed": passed})
        if not passed:
            issues.append({
                "slide": "theme",
                "type": "LOW_CONTRAST",
                "severity": "critical",
                "details": f"{name}: {fg} on {bg} = {ratio}:1, below required {threshold}:1",
            })

    return {"results": results, "issues": issues}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("theme_json")
    args = parser.parse_args()
    report = audit_accessibility(args.theme_json)
    print(json.dumps(report, indent=2))
    sys.exit(1 if report["issues"] else 0)
