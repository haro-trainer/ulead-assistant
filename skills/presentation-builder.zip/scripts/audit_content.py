#!/usr/bin/env python3
"""
audit_content.py — flags internal/production-facing phrases found in VISIBLE slide text
(as opposed to <aside class="notes">, where such phrases are acceptable).

Usage:
    python3 audit_content.py <deck.html>
"""
import argparse
import json
import re
import sys
from pathlib import Path

FLAGGED_PHRASES = [
    "quick verification", "verificación rápida",
    "memorable closing", "cierre memorable", "cierre memorable de la sesión",
    "teacher note", "nota del profesor", "nota para el profesor", "explicación del profesor",
    "instructor prompt", "prompt del instructor",
    "debrief",
    "transition slide", "slide de transición", "transición",
    "teaching objective", "objetivo de enseñanza",
    "explain here", "explica aquí",
    "ask students", "pregunta a los estudiantes",
    "present this", "presenta esto",
    "show the audience", "muestra a la audiencia",
    "activity verification", "verificación de la actividad",
]

SLIDE_RE = re.compile(r'<section[^>]*class="[^"]*slide[^"]*"[^>]*>(.*?)</section>', re.S)
NOTES_RE = re.compile(r'<aside class="notes">.*?</aside>', re.S)
TAG_RE = re.compile(r"<[^>]+>")


def audit_content(deck_html_path):
    html = Path(deck_html_path).read_text(encoding="utf-8")
    issues = []

    for i, slide_match in enumerate(SLIDE_RE.finditer(html), start=1):
        slide_html = slide_match.group(1)
        visible_html = NOTES_RE.sub("", slide_html)
        visible_text = TAG_RE.sub(" ", visible_html).lower()

        for phrase in FLAGGED_PHRASES:
            if phrase in visible_text:
                issues.append({
                    "slide": i,
                    "type": "AUDIENCE_LANGUAGE_VIOLATION",
                    "severity": "high",
                    "details": f'Found production-facing phrase "{phrase}" in visible slide text.',
                })

    report = {"slides_scanned": len(SLIDE_RE.findall(html)), "issues": issues}
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("deck_html")
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    report = audit_content(args.deck_html)
    text = json.dumps(report, indent=2, ensure_ascii=False)
    print(text)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    sys.exit(1 if report["issues"] else 0)
