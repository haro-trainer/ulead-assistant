/**
 * audit_layout.js — layout audit logic, meant to run inside the deck's own browser context
 * (injected via Playwright's page.evaluate in scripts/render_slides.py). Returns a JSON-
 * serializable array of issues for the currently active slide.
 *
 * Checks: off-canvas elements, logo/title/card/notes overlap, empty-but-textful cards,
 * unreadable inherited colors (fg == bg), overflowing tables, missing notes, missing alt text,
 * zero-height visual containers.
 */
window.__auditActiveSlide = function () {
  const issues = [];
  const active = document.querySelector('.slide.active');
  if (!active) {
    issues.push({ type: 'NO_ACTIVE_SLIDE', severity: 'critical', details: 'No .slide.active found.' });
    return issues;
  }

  const viewport = { w: window.innerWidth, h: window.innerHeight };
  const slideId = active.id || '(no id)';

  function rect(el) { return el.getBoundingClientRect(); }
  function isOffCanvas(r) {
    return r.left < -1 || r.top < -1 || r.right > viewport.w + 1 || r.bottom > viewport.h + 1;
  }
  function intersects(a, b) {
    return !(a.right <= b.left || a.left >= b.right || a.bottom <= b.top || a.top >= b.bottom);
  }
  function rgbToTuple(rgbStr) {
    const m = rgbStr.match(/rgba?\(([^)]+)\)/);
    if (!m) return null;
    return m[1].split(',').map(s => parseFloat(s.trim()));
  }

  // 1. Off-canvas primary content blocks.
  active.querySelectorAll('h1, h2, .card, table, .notes.visible').forEach((el) => {
    const r = rect(el);
    if (r.width === 0 && r.height === 0) return;
    if (isOffCanvas(r)) {
      issues.push({
        type: 'OFF_CANVAS', severity: 'critical', selector: describeSelector(el),
        details: `Element extends outside the ${viewport.w}x${viewport.h} viewport on slide ${slideId}.`,
      });
    }
  });

  // 2. Logo overlap with title/subtitle/nav.
  const logo = active.querySelector('.logo');
  if (logo) {
    const logoRect = rect(logo);
    active.querySelectorAll('h1, h2, .eyebrow').forEach((el) => {
      if (intersects(logoRect, rect(el))) {
        issues.push({
          type: 'LOGO_OVERLAP', severity: 'critical', selector: describeSelector(el),
          details: `Logo bounding box overlaps ${describeSelector(el)} on slide ${slideId}.`,
        });
      }
    });
    document.querySelectorAll('.nav-btn').forEach((btn) => {
      if (intersects(logoRect, rect(btn))) {
        issues.push({
          type: 'LOGO_OVERLAP_NAV', severity: 'high', selector: '.nav-btn',
          details: `Logo overlaps navigation control on slide ${slideId}.`,
        });
      }
    });
  }

  // 3. Card/title overlap (any two cards overlapping each other).
  const cards = Array.from(active.querySelectorAll('.card'));
  for (let i = 0; i < cards.length; i++) {
    for (let j = i + 1; j < cards.length; j++) {
      if (intersects(rect(cards[i]), rect(cards[j]))) {
        issues.push({
          type: 'CARD_OVERLAP', severity: 'high', selector: '.card',
          details: `Two cards overlap on slide ${slideId}.`,
        });
      }
    }
  }

  // 4. Empty-but-textful cards / zero-height visual containers.
  cards.forEach((card) => {
    const r = rect(card);
    const hasText = (card.textContent || '').trim().length > 0;
    if (hasText && (r.width === 0 || r.height === 0)) {
      issues.push({
        type: 'ZERO_SIZE_CONTAINER', severity: 'critical', selector: describeSelector(card),
        details: `Card has text but zero rendered size on slide ${slideId}.`,
      });
    }
  });

  // 5. Unreadable inherited colors (foreground == background, or near-identical).
  // Skipped for backgrounds with alpha < 0.5 (e.g. translucent pills over a dark/brand slide) —
  // those are a valid documented pattern (white text on a translucent white-tinted pill) and
  // their real contrast depends on the slide background behind them, not the pill's own fill.
  active.querySelectorAll('.card, .card *, table td, table th, .pill').forEach((el) => {
    const style = getComputedStyle(el);
    const fg = rgbToTuple(style.color);
    const bg = rgbToTuple(style.backgroundColor);
    if (!fg || !bg || style.backgroundColor === 'rgba(0, 0, 0, 0)') return;
    const bgAlpha = bg.length > 3 ? bg[3] : 1;
    if (bgAlpha < 0.5) return;
    const dist = Math.abs(fg[0] - bg[0]) + Math.abs(fg[1] - bg[1]) + Math.abs(fg[2] - bg[2]);
    if (dist < 20 && (el.textContent || '').trim().length > 0) {
      issues.push({
        type: 'LOW_CONTRAST', severity: 'critical', selector: describeSelector(el),
        foreground: style.color, background: style.backgroundColor,
        details: `Foreground nearly identical to background on slide ${slideId}.`,
      });
    }
  });

  // 6. Overflowing tables.
  active.querySelectorAll('table').forEach((t) => {
    if (t.scrollWidth > t.clientWidth + 2) {
      issues.push({
        type: 'TABLE_OVERFLOW', severity: 'high', selector: 'table',
        details: `Table content overflows its container on slide ${slideId}.`,
      });
    }
  });

  // 7. Missing notes.
  const notes = active.querySelector('.notes');
  if (!notes || !notes.textContent.trim()) {
    issues.push({
      type: 'MISSING_NOTES', severity: 'critical', selector: '.notes',
      details: `Slide ${slideId} has no speaker notes.`,
    });
  }

  // 8. Missing alt text on images.
  active.querySelectorAll('img').forEach((img) => {
    if (!img.getAttribute('alt')) {
      issues.push({
        type: 'MISSING_ALT_TEXT', severity: 'medium', selector: describeSelector(img),
        details: `Image missing alt text on slide ${slideId}.`,
      });
    }
  });

  return issues;

  function describeSelector(el) {
    if (el.id) return '#' + el.id;
    if (el.className) return el.tagName.toLowerCase() + '.' + String(el.className).split(' ').join('.');
    return el.tagName.toLowerCase();
  }
};
