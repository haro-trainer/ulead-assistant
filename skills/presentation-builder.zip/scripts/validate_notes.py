#!/usr/bin/env python3
"""
validate_notes.py — dedicated check that every slide has non-empty speaker notes AND that the
"S" key correctly toggles them, tested on at least 3 different slide types (dark/light/brand
backgrounds), as required before delivery.

Usage:
    python3 validate_notes.py <deck.html>

Exit code 0 = passed, 1 = failed.
"""
import argparse
import sys
import http.server
import socketserver
import threading
from pathlib import Path

from playwright.sync_api import sync_playwright


def serve_directory(directory, port=0):
    handler = lambda *a, **kw: http.server.SimpleHTTPRequestHandler(*a, directory=str(directory), **kw)
    httpd = socketserver.TCPServer(("127.0.0.1", port), handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    return httpd, httpd.server_address[1]


def validate_notes(deck_html_path):
    deck_path = Path(deck_html_path).resolve()
    httpd, port = serve_directory(deck_path.parent)
    url = f"http://127.0.0.1:{port}/{deck_path.name}"

    failures = []
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page(viewport={"width": 1920, "height": 1080})
            page.goto(url)
            page.wait_for_selector(".slide.active")

            total = page.evaluate("window.deckNav.getTotal()")
            empty_notes = page.evaluate("""
                Array.from(document.querySelectorAll('.slide')).map((s, i) => ({
                    index: i,
                    empty: !s.querySelector('.notes') || !s.querySelector('.notes').textContent.trim()
                })).filter(x => x.empty).map(x => x.index)
            """)
            if empty_notes:
                failures.append(f"Slides with empty/missing notes: {empty_notes}")

            # Sample up to 3 different backgrounds for the toggle check.
            backgrounds_seen = set()
            sample_indices = []
            bg_map = page.evaluate("""
                Array.from(document.querySelectorAll('.slide')).map(s =>
                    s.classList.contains('bg-dark') ? 'bg-dark' :
                    s.classList.contains('bg-brand') ? 'bg-brand' : 'bg-light'
                )
            """)
            for i, bg in enumerate(bg_map):
                if bg not in backgrounds_seen:
                    backgrounds_seen.add(bg)
                    sample_indices.append(i)
                if len(sample_indices) >= 3:
                    break

            for i in sample_indices:
                page.evaluate(f"window.deckNav.goTo({i})")
                page.wait_for_timeout(50)
                page.keyboard.press("KeyS")
                page.wait_for_timeout(50)
                visible = page.evaluate("window.notesState.isVisible()")
                if not visible:
                    failures.append(f"Slide {i} (bg={bg_map[i]}): notes did not appear after pressing S")
                page.keyboard.press("KeyS")
                page.wait_for_timeout(50)
                hidden_again = not page.evaluate("window.notesState.isVisible()")
                if not hidden_again:
                    failures.append(f"Slide {i} (bg={bg_map[i]}): notes did not hide after pressing S again")

            browser.close()
    finally:
        httpd.shutdown()

    if failures:
        print("FAILED:")
        for f in failures:
            print(f" - {f}")
        return False
    print(f"PASSED: all {total} slides have notes; S toggle verified on {len(sample_indices)} slide backgrounds.")
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("deck_html")
    args = parser.parse_args()
    ok = validate_notes(args.deck_html)
    sys.exit(0 if ok else 1)
