#!/usr/bin/env python3
"""
extract_assets.py — inspects a logo/reference image and proposes theme color tokens
(schemas/theme-schema.json shape). Requires Pillow.

Usage:
    python3 extract_assets.py <image_path> [--top N]
"""
import argparse
import json
import sys

try:
    from PIL import Image
except ImportError:
    print("Pillow is required: pip install Pillow --break-system-packages", file=sys.stderr)
    sys.exit(1)


def dominant_colors(image_path, top=6, min_alpha=50, min_distance=10):
    im = Image.open(image_path).convert("RGBA")
    colors = im.getcolors(im.width * im.height) or []
    colors.sort(key=lambda c: -c[0])

    picked = []
    for count, (r, g, b, a) in colors:
        if a < min_alpha:
            continue
        if any(abs(r - r2) < min_distance and abs(g - g2) < min_distance and abs(b - b2) < min_distance
               for r2, g2, b2 in picked):
            continue
        picked.append((r, g, b))
        if len(picked) >= top:
            break
    return [f"#{r:02x}{g:02x}{b:02x}" for r, g, b in picked]


def luminance(hex_color):
    hex_color = hex_color.lstrip("#")
    r, g, b = (int(hex_color[i:i+2], 16) / 255 for i in (0, 2, 4))

    def lin(c):
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def propose_theme(colors):
    if not colors:
        return {}
    by_lum = sorted(colors, key=luminance)
    dark = by_lum[0]
    light = by_lum[-1] if luminance(by_lum[-1]) > 0.6 else "#f4f1ed"
    # pick the most saturated-looking mid color as primary (heuristic: not near-gray)
    primary = colors[0]
    for c in colors:
        r, g, b = (int(c[i:i+2], 16) for i in (1, 3, 5))
        if max(r, g, b) - min(r, g, b) > 40:
            primary = c
            break
    return {
        "primary": primary,
        "secondary": colors[1] if len(colors) > 1 else primary,
        "dark": dark,
        "light": light,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("image_path")
    parser.add_argument("--top", type=int, default=6)
    args = parser.parse_args()

    colors = dominant_colors(args.image_path, top=args.top)
    theme = propose_theme(colors)
    print(json.dumps({"dominant_colors": colors, "proposed_theme": theme}, indent=2))
