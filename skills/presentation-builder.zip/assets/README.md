# assets/

This folder ships only a **placeholder** logo (`placeholder-logo/logo-placeholder.svg`) so the sample
deck renders without depending on any institution's real branding.

To use your own institutional logo:
1. Place your logo file(s) here (e.g. `assets/your-logo.png`, plus white/dark/transparent variants if needed).
2. Point `theme.logo_path` in your presentation-input JSON to the real file.
3. Run `scripts/embed_assets.py` to inline it as base64 for offline delivery.

Do not commit a client's real logo into a shared/public copy of this skill unless explicitly authorized —
keep it local to the specific deck being produced.
