# premium-pedagogical-presentation-builder

A Claude skill that transforms approved academic/professional content into a visually premium,
pedagogically rigorous, self-contained HTML presentation — with narrative speaker notes, keyboard
navigation, fullscreen mode, and a mandatory visual/contrast/layout audit before delivery.

## What this skill produces

- A single-file HTML deck (`*.html`) that runs offline in any modern browser.
- Speaker notes on every slide, toggled with `S`, hidden by default.
- Keyboard + click navigation, progress bar, slide counter.
- A layout/contrast/content audit with screenshots at 1366×768 and 1920×1080.
- A `final-quality-report.md` documenting exactly what was validated.

## Quick start

```bash
# 1. Build a deck from a presentation-input JSON (see schemas/presentation-input-schema.json)
python3 scripts/build_deck.py examples/sample-slide-outline.json out/deck.html --skill-root .

# 2. Embed local images as base64 for fully offline delivery
python3 scripts/embed_assets.py out/deck.html out/deck.html --assets-dir out

# 3. Validate speaker notes toggle across slide types
python3 scripts/validate_notes.py out/deck.html

# 4. Render screenshots + run the layout audit
python3 scripts/render_slides.py out/deck.html out/audit --resolutions 1366x768,1920x1080

# 5. Audit visible content for internal/production language
python3 scripts/audit_content.py out/deck.html

# 6. Audit theme contrast (WCAG AA)
python3 scripts/audit_accessibility.py examples/sample-theme.json
```

## Directory guide

| Path | Purpose |
|---|---|
| `SKILL.md` | Full workflow, trigger conditions, non-negotiable rules — read this first. |
| `templates/` | The reusable deck engine (HTML/CSS/JS). Never hard-code colors — always read theme tokens. |
| `slide-archetypes/` | Reference markup for each of the 16 slide types. |
| `prompts/` | Supporting prompts for each authoring stage (extraction, outline, notes, QA). |
| `schemas/` | JSON Schemas for the presentation input, a slide, the theme, and the audit report. |
| `scripts/` | Functional Python/JS: build, embed assets, extract brand colors, render screenshots, audit. |
| `checklists/` | Manual checklists for instructional design, visual design, accessibility, notes, final delivery. |
| `examples/` | A generic (non-proprietary) end-to-end sample: input → outline → deck → audit report. |
| `tests/` | Automated Playwright-based tests that run against a built deck. |
| `assets/` | Placeholder logo only — replace with the real institution's logo per deck, never ship a client's real logo in a shared copy of this skill. |

## Using your own brand

1. Run `python3 scripts/extract_assets.py path/to/logo.png` to get a proposed color theme.
2. Fill in `theme` in your presentation-input JSON (see `schemas/theme-schema.json`).
3. Point `theme.logo_path` at your own logo file (keep it outside the shared skill copy).
4. Build, embed, audit, and deliver.

## Requirements

- Python 3.9+
- `Pillow` (brand color extraction) — `pip install Pillow --break-system-packages`
- `playwright` (screenshot/layout audits) — `pip install playwright --break-system-packages && playwright install chromium`

If Playwright/Chromium is unavailable in the environment, see "Failure handling" in `SKILL.md`: the
skill must never claim visual validation passed without it, and must fall back to structural/DOM-only
checks, marking the result clearly as unvalidated.
