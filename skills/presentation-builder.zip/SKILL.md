---
name: premium-pedagogical-presentation-builder
description: >-
  Transforma contenido académico o profesional ya aprobado (sílabo, plan de sesión, documentos, decks
  existentes) en una presentación HTML autocontenida, visualmente premium y pedagógicamente rigurosa, con
  notas de orador narrativas para el profesor, navegación por teclado, modo pantalla completa, y una auditoría
  visual y de contraste antes de entregar. Úsalo cuando el usuario pida "crea una presentación HTML", "arma
  un deck para esta clase", "convierte este plan de sesión en slides", "usa este logo y estilo de marca",
  "genera notas de orador", "haz la presentación más atractiva", "audita el deck", o "convierte este contenido
  de curso en una presentación premium". Aplica para cursos universitarios, educación ejecutiva, talleres
  técnicos, entrenamiento corporativo y programas de máster.
---

# Premium Pedagogical Presentation Builder

Este skill actúa simultáneamente como diseñador instruccional, estratega de presentaciones, diseñador de
comunicación visual, especialista en storytelling, desarrollador front-end, revisor de accesibilidad,
revisor de calidad y redactor de notas de orador. Su propósito no es poner texto en diapositivas: es
transformar material fuente en una experiencia de enseñanza en vivo que mantiene la atención, construye
ideas progresivamente, y deja al profesor con una imagen profesional y diferenciada.

## Cuándo se activa

- "Crea una presentación HTML / un deck para esta clase."
- "Convierte este plan de sesión / sílabo en slides."
- "Usa este logo y esta paleta de marca."
- "Genera las notas de orador."
- "Haz la presentación más atractiva / más profesional."
- "Audita el deck por errores visuales."
- "Convierte este contenido de curso en una presentación premium."

## Insumos

**Requeridos (al menos uno debe existir o preguntarse):**
- Contenido académico fuente: sílabo, plan de sesión, documento de contenido, o el tema ya presente en la
  conversación.

**Opcionales:**
- Deck HTML existente, capturas de pantalla, logo institucional, guía de marca/paleta de colores, casos
  aplicados, rúbricas, guías de estudiante, biografía del profesor, cronograma del curso.

Antes de generar nada, **clasifica cada artefacto adjunto**:

| Tipo de artefacto | Rol |
|---|---|
| Sílabo | Fuente de verdad: objetivos, resultados, evaluación, alcance |
| Plan de sesión | Fuente de verdad: tiempos, temas, actividades, secuencia |
| Documento de contenido | Fuente de verdad: material académico detallado |
| Deck de referencia (HTML/PDF/PPTX) | Referencia visual/estructural — **nunca fuente de contenido académico** |
| Guía de marca / logo | Identidad institucional (colores, tipografía, uso del logo) |
| Captura de pantalla | Referencia visual o evidencia de un defecto a corregir |
| Caso de estudio | Contenido de actividad aplicada |
| Rúbrica | Alineamiento de evaluación |
| Guía de estudiante | Apoyo de actividad |
| Perfil del profesor | Presentación del instructor |

**Regla no negociable:** si el usuario indica que un archivo es solo referencia de formato/estilo (como un
deck HTML anterior, o capturas de pantalla), **nunca** reutilices su contenido académico para un tema
distinto — solo su patrón visual, de interacción, o las lecciones de defectos a no repetir. Si hay
información faltante, en conflicto, o desactualizada entre artefactos, señálalo explícitamente antes de
continuar.

## Preguntas a realizar (solo si no están ya respondidas por los adjuntos)

1. Título de la presentación y programa/curso.
2. Número de sesión.
3. Audiencia objetivo y duración de la sesión.
4. Modalidad de entrega (presencial/virtual/híbrida) e idioma.
5. Número o ritmo deseado de slides.
6. Branding institucional (si no hay adjunto).
7. ¿Se requieren notas de orador? (por defecto sí).
8. ¿Actividades individuales o grupales?
9. Formato final: ¿solo HTML, HTML + PDF, o HTML + PowerPoint?
10. ¿Habrá acceso a internet durante la sesión? (define si los recursos deben ir embebidos).
11. ¿Incluir quizzes, casos, actividades, reflexión, homework, referencias?

No preguntes por información que ya esté en los archivos adjuntos. Si hay suficiente información, procede
sin fricción adicional.

## Flujo de trabajo

1. **Inspeccionar los archivos** y clasificarlos (ver tabla arriba).
2. **Identificar la fuente de verdad** para contenido académico vs. referencias visuales.
3. **Extraer el sistema de marca**: colores primario/secundario, variantes de logo, fondos seguros para el
   logo (ver `prompts/content-extraction-prompt.md` y `schemas/theme-schema.json`).
4. **Extraer los resultados de aprendizaje** del sílabo/plan (verbos Bloom observables).
5. **Construir el arco pedagógico** (ver sección "Estructura pedagógica" abajo).
6. **Crear el esquema de slides** (`schemas/slide-schema.json`) — un JSON con un slide por elemento del arco.
7. **Seleccionar arquetipos de slide** de `slide-archetypes/` para cada elemento del esquema.
8. **Redactar el contenido visible** en lenguaje dirigido a la audiencia (ver `prompts/audience-language-rewriter.md`).
9. **Generar las notas de orador** para cada slide (ver `prompts/speaker-notes-prompt.md`).
10. **Construir el HTML** con `scripts/build_deck.py` a partir del esquema y el tema.
11. **Embeber assets** (`scripts/embed_assets.py` / `scripts/extract_assets.py`) para uso offline si se requiere.
12. **Auditar el contenido** (`scripts/audit_content.py`) — frases de producción visibles al público.
13. **Auditar el contraste y accesibilidad** (`scripts/audit_accessibility.py`).
14. **Renderizar capturas de pantalla** (`scripts/render_slides.py`) en las resoluciones requeridas.
15. **Corregir los problemas** detectados antes de continuar.
16. **Validar controles** (navegación, pantalla completa, toggle de notas con `S`) con `scripts/validate_notes.py`
    y `tests/`.
17. **Empaquetar la entrega** (deck final + `final-quality-report.md` + capturas de auditoría).

## Estructura pedagógica por defecto

Usa esta secuencia como base, adaptándola al material fuente (el número de slides puede variar, pero el
ritmo pedagógico debe mantenerse):

**Apertura:** portada institucional → pregunta provocadora → promesa de aprendizaje → agenda/mapa de la sesión.
**Fundamento conceptual:** replanteamiento del concepto central → corrección de mitos comunes → marco o
modelo → extensión del modelo al contexto actual.
**Progresión histórica o lógica:** evolución/línea de tiempo → fortalezas y límites del modelo anterior →
transición clave → principio memorable.
**Aplicación moderna:** arquitectura o enfoque actual → capacidades o patrones → nueva necesidad de
negocio/usuario → mapa conceptual integrado.
**Aprendizaje aplicado:** actividad breve de decisión → caso aplicado → canvas/matriz de taller → discusión
o reto grupal.
**Verificación de aprendizaje:** quiz dirigido al estudiante → ideas clave a retener → preparación para la
siguiente sesión → frase de cierre memorable.

No más de **4 slides consecutivos puramente expositivos** sin justificación explícita — alterna siempre
explicación, pregunta, visualización, ejemplo, actividad, reflexión, aplicación de caso y síntesis.

## Principios de diseño no negociables

- **Contenido dirigido a la audiencia**: todo texto visible se redacta para el estudiante. Nunca aparecen
  en pantalla etiquetas de producción como "verificación rápida", "cierre memorable", "nota del profesor",
  "debrief", "transición" — esas instrucciones viven exclusivamente en las notas de orador. Usa en su lugar
  lenguaje como "Pon a prueba tu criterio", "¿Qué decidirías tú?", "Tu reto", "Antes de la próxima sesión".
- **Una idea central por slide.** Puede haber detalle de apoyo, pero debe existir un foco visual y
  conceptual claro.
- **Mostrar, no solo decir**: prioriza diagramas, líneas de tiempo, matrices, comparaciones antes/después,
  mapas de decisión, tarjetas de escenario — evita párrafos largos tipo documento.
- **Balance ejecutivo-técnico**: cuando la fuente es técnica, conecta capacidades técnicas con implicaciones
  de negocio, riesgos, decisiones y trade-offs.
- **Mensajes memorables**: extrae o crea frases breves que capturen la lección esencial, siempre respaldadas
  por el contenido fuente — nunca inventadas de forma que distorsionen el significado académico.
- **Densidad controlada** (ver límites exactos en la sección siguiente).

## Límites de densidad de contenido

| Elemento | Límite |
|---|---|
| Palabras visibles en un slide conceptual estándar | 35–45 |
| Bullets cortos | máx. 6 |
| Tarjetas en una fila | máx. 5 |
| Pills de síntesis | máx. 10 |
| Columnas en una tabla | máx. 5 |
| Oraciones por tarjeta | máx. 2 |
| Opciones de respuesta en quiz | máx. 4 |

Cuando el contenido exceda estos límites: divide en varios slides, convierte prosa en diagrama, mueve la
explicación a notas, acorta el lenguaje visible, usa divulgación progresiva, o crea un slide de apéndice.
**Nunca reduzcas el tamaño de fuente por debajo del mínimo solo para que quepa el contenido.**

## Tamaños mínimos de fuente (lienzo de diseño 1920×1080)

| Elemento | Mínimo |
|---|---|
| Título principal | 54px |
| Título de sección | 42px |
| Título de tarjeta | 26px |
| Texto de cuerpo | 22px |
| Texto de tabla | 20px |
| Captions | 18px |
| Notas de orador | 18px |

## Reglas de contraste

- Tarjetas claras → texto con `--text-on-light`. Tarjetas oscuras → texto con `--text-on-dark`.
- Slides naranja/degradado → texto principal blanco, texto "eyebrow" en naranja claro/crema, texto dentro
  de tarjetas blancas siempre oscuro.
- Objetivo WCAG AA: texto normal 4.5:1, texto grande 3:1.
- Cada tarjeta, tabla, ítem de timeline o pill debe declarar su color de texto explícitamente — nunca
  depender de la herencia de color.

## Reglas de layout

- Márgenes seguros: izquierda/derecha 5–7%, superior 5–7%, inferior 7–9%.
- Zona segura del logo: fija y protegida — nunca debe superponerse con el panel de título, subtítulo, texto
  de fondo, elementos decorativos, ni controles de navegación.
- Zona segura de navegación: 90px en los costados izquierdo y derecho.
- Zona segura de notas: overlay inferior únicamente.
- Nada debe salir del lienzo, quedar detrás del logo, quedar bajo las flechas de navegación, recortarse por
  el viewport, o extenderse bajo la barra de progreso.

## Controles requeridos en el deck

| Tecla | Función |
|---|---|
| → / Espacio / Av Pág | Slide siguiente |
| ← / Re Pág | Slide anterior |
| F | Pantalla completa |
| S | Mostrar/ocultar notas de orador |
| Inicio / Fin | Primer / último slide |
| Esc | Cerrar modal o notas |

Las flechas de navegación deben ser suficientemente grandes, permanecer visibles sin obstruir contenido,
tener alto contraste, incluir etiquetas accesibles, atenuarse en el primer/último slide, y funcionar
independientemente de zonas de clic. El deck debe mostrar número de slide, total de slides, y barra de
progreso.

## Notas de orador

Cada slide debe tener notas de orador narrativas (no metadatos fragmentados) que cubran: propósito del
slide, frase de apertura sugerida, explicación central, error conceptual a anticipar, pregunta sugerida
para la audiencia, y transición al siguiente slide. Deben: existir en el 100% de los slides, mostrarse solo
en el slide activo, alternar correctamente con `S`, tener z-index alto, ser legibles en fondos claros y
oscuros, no afectar el layout normal, y permanecer ocultas por defecto. Usa `prompts/speaker-notes-prompt.md`
como guía de redacción.

## Proceso de auditoría de calidad (obligatorio antes de entregar)

1. **Auditoría estructural**: todo slide tiene título/rol definido, notas no vacías, imágenes con alt text,
   etiquetas visibles dirigidas a la audiencia, sin contenedores vacíos, sin IDs duplicados, controles de
   navegación presentes.
2. **Auditoría de layout programática**: bounding boxes, overflow, recortes, superposición del logo/título/
   tarjetas/notas, elementos fuera de lienzo, colores heredados ilegibles, contenedores en blanco.
3. **Auditoría por capturas de pantalla**: renderiza cada slide en 1366×768 y 1920×1080, más slide 1 con y
   sin notas, un slide oscuro con notas, un slide naranja con notas, un slide claro con notas.
4. **Inspección visual**: revisa las capturas por texto oculto, tarjetas en blanco, texto detrás de paneles,
   obstrucción del logo, espaciado inconsistente, densidad excesiva, bajo contraste, imágenes rotas,
   desalineación, notas que no aparecen, navegación que tapa contenido.
5. **Corrección automática**: corrige cada problema detectado antes de la entrega. Nunca muestres un badge
   de auditoría, contador de advertencias, o panel de depuración en el deck final — esos datos van solo a
   `audit/layout-report.json`, `audit/layout-report.md`, `audit/screenshots/`.
6. **Validación final**: solo se entrega cuando todos los slides renderizan, no queda superposición crítica,
   no faltan notas, `S` funciona en todos los slides, la navegación funciona, pantalla completa funciona, el
   contraste es aceptable, el logo es visible, y las capturas pasaron la inspección.

## Reglas de decisión

- **¿Cuándo dividir un slide?** Si excede los límites de densidad de la tabla de arriba.
- **¿Cuándo crear un diagrama?** Cuando el contenido fuente describe un flujo, arquitectura, comparación o
  evolución — antes que un párrafo.
- **¿Cuándo crear una actividad/caso/quiz?** Cuando el plan de sesión de origen ya lo indica, o cuando el
  arco pedagógico llega a un punto de "aprendizaje aplicado"/"verificación" sin uno definido en la fuente
  (en ese caso, derívalo del contenido existente y dilo explícitamente).
- **¿Cuándo usar una tabla vs. una tarjeta/diagrama?** Tabla solo si los datos son inherentemente tabulares
  y caben en el límite de columnas; si no, conviértelo en tarjetas o diagrama.
- **¿Rechazar una imagen?** Si su resolución es demasiado baja para 1920×1080 sin pixelarse notablemente.
- **¿Cuándo preguntar al usuario?** Solo si la ambigüedad afecta materialmente el resultado (ver sección de
  preguntas); de lo contrario, asume el valor más razonable y decláralo.
- **¿Usar solo la fuente o investigar en la web?** Por defecto, usa solo el contenido fuente aprobado. Solo
  investiga en la web si el usuario lo pide explícitamente o si falta un dato objetivo no académico (p. ej.
  una cifra pública verificable) y lo señalas como tal.
- **¿Preservar terminología?** Sí — no sustituyas términos técnicos ya establecidos en el sílabo/plan por
  sinónimos que puedan generar ambigüedad.

## Reglas no negociables

- Nunca entregues sin validación por capturas de pantalla.
- Nunca entregues un slide con contenido superpuesto.
- Nunca dejes tarjetas en blanco o texto invisible.
- Nunca expongas la interfaz interna de auditoría en el deck final.
- Nunca omitas las notas de un slide.
- Nunca coloques instrucciones exclusivas del instructor en contenido visible para el estudiante.
- Nunca inventes contenido académico no respaldado por la fuente.
- Nunca uses un documento de referencia visual como fuente académica salvo autorización explícita.
- Nunca reduzcas fuentes por debajo de los umbrales mínimos de legibilidad.
- Nunca afirmes que una presentación fue validada si la generación de capturas falló.

## Contrato de salida

Por cada ejecución completa, el skill produce:
- `[nombre]-deck.html` — el deck final, autocontenido.
- `audit/layout-report.json` y `audit/layout-report.md` — hallazgos de auditoría de layout.
- `audit/screenshots/` — capturas en las resoluciones probadas.
- `final-quality-report.md` — resumen ejecutivo de validación (ver plantilla en `checklists/final-delivery-checklist.md`).

## Manejo de fallas

Si la generación de capturas de pantalla falla (p. ej. no hay navegador disponible en el entorno):
- No afirmes que la validación visual fue exitosa.
- Reporta la limitación explícitamente al usuario.
- Intenta un renderizador alternativo o un método de validación estático simplificado (p. ej. solo auditoría
  estructural/DOM sin captura).
- Entrega el resultado marcado claramente como "no validado visualmente" hasta que se pueda confirmar.

## Recursos de este skill

- `templates/` — motor del deck (HTML/CSS/JS reutilizable).
- `slide-archetypes/` — referencia de los 16 tipos de slide.
- `prompts/` — prompts de apoyo para cada etapa de redacción.
- `schemas/` — JSON Schemas del insumo, del slide, del tema y del reporte de auditoría.
- `scripts/` — construcción del deck, embebido de assets, renderizado de capturas, y auditorías (funcionales,
  no pseudocódigo).
- `checklists/` — checklists de diseño instruccional, visual, accesibilidad, notas de orador, y entrega final.
- `examples/` — insumo de ejemplo, esquema de ejemplo, tema de ejemplo, deck de ejemplo y reporte de
  auditoría de ejemplo (generados y validados como parte de la construcción de este skill).
- `tests/` — pruebas automatizadas con Playwright sobre el deck de ejemplo.
