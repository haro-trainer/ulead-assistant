# Changelog

## 1.0.0
- Initial release.
- Deck engine (templates/), 16 slide archetypes, 6 authoring prompts, 4 JSON Schemas.
- Functional scripts: build_deck.py, embed_assets.py, extract_assets.py, render_slides.py,
  audit_layout.js, audit_content.py, audit_accessibility.py, validate_notes.py, package_skill.py.
- End-to-end sample (examples/) built and validated: 14 slides, 0 layout/content issues after two
  real defects were found and fixed during construction (logo/content clearance rounding overlap;
  insufficient white-on-orange contrast on brand-gradient slides, fixed with a 38% dark overlay).
- 5 checklists, Playwright test suite (tests/).
