# Prompt de apoyo: redacción de notas de orador

Escribe las notas de orador como una narrativa continua para el profesor (no una lista de metadatos).
Cada nota debe cubrir, en prosa:

1. El propósito del slide.
2. Una frase de apertura sugerida.
3. La explicación central del concepto.
4. Un error conceptual común a anticipar.
5. Una pregunta sugerida para la audiencia.
6. La transición al siguiente slide.

Ejemplo de tono correcto:

"Empieza separando escala de valor. Explica que el volumen de datos no es lo que define el reto, sino la
dificultad de convertir datos diversos y cambiantes en decisiones confiables. Pregunta al grupo si conocen
un caso donde un dataset pequeño generó un problema de arquitectura complejo. Cierra diciendo que las
dimensiones del siguiente slide se van a usar como herramienta de diagnóstico."

Nunca escribas la nota como fragmentos tipo "Punto 1: definición. Punto 2: ejemplo." — debe sonar a cómo
hablaría el profesor.
