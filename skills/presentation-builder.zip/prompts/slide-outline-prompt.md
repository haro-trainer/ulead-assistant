# Prompt de apoyo: outline de slides

A partir del contenido extraído, construye el arco pedagógico completo (apertura, fundamento conceptual,
progresión histórica/lógica, aplicación moderna, aprendizaje aplicado, verificación de aprendizaje — ver
SKILL.md). Para cada elemento del arco:

- Asigna un arquetipo de `slide-archetypes/`.
- Redacta un título borrador (se refinará con lenguaje audience-facing después).
- Anota de qué parte del material fuente proviene (trazabilidad).
- Verifica que no haya más de 4 slides consecutivos puramente expositivos sin alternar con pregunta,
  actividad, ejemplo o reflexión.

El resultado es un JSON que sigue `schemas/slide-schema.json`.
