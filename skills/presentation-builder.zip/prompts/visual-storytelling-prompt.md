# Prompt de apoyo: storytelling visual

Para cada slide del outline, decide el tratamiento visual antes de escribir el HTML final:

- ¿Esta idea se explica mejor con una tabla, una tarjeta, un diagrama, una línea de tiempo, o una
  comparación? Prioriza siempre "mostrar" sobre "decir".
- ¿Cuál es el foco visual único de este slide? Todo lo demás es apoyo.
- ¿Hay una frase memorable que resuma la idea? Debe estar respaldada por el contenido fuente.
- Verifica los límites de densidad (palabras, bullets, tarjetas por fila, columnas de tabla) antes de
  continuar — si excede, decide ahora cómo dividir o simplificar.
