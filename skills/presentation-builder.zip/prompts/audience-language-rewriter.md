# Prompt de apoyo: reescritura a lenguaje de audiencia

Revisa cada texto visible del deck y reescribe cualquier frase que suene a instrucción interna de
producción. Ejemplos de reemplazo:

| Evitar (interno) | Usar (audiencia) |
|---|---|
| Verificación rápida | Pon a prueba tu criterio |
| Cierre memorable | Ideas para llevarte |
| Nota del profesor / explicación del profesor | (mover a notas, no debe aparecer visible) |
| Debrief | Piensa, debate y decide |
| Slide de transición | (no se etiqueta como tal en pantalla) |
| Verificación de la actividad | ¿Qué identificaste? |
| Prompt del instructor | Tu reto |

Regla: si un texto visible describe qué debe hacer el profesor en vez de dirigirse al estudiante, muévelo
a las notas de orador y reescribe el texto visible dirigido al estudiante.
