# Prompt de apoyo: extracción de contenido y marca

Usa esto internamente al inspeccionar los archivos adjuntos, antes de generar el esquema de slides.

1. Lista cada archivo adjunto y clasifícalo: sílabo / plan de sesión / documento de contenido / deck de
   referencia / guía de marca / logo / captura de pantalla / caso / rúbrica / guía de estudiante / perfil
   del profesor.
2. Marca cuáles son **fuente de verdad académica** y cuáles son **solo referencia visual/estructural**.
   Si el usuario no lo indicó explícitamente pero es evidente por el tipo de archivo (p. ej. un deck HTML
   anterior de otro tema), trátalo como referencia visual únicamente y dilo.
3. Extrae del sílabo/plan: título del curso, número de sesión, resultados de aprendizaje (con verbo Bloom),
   agenda por bloques, actividades ya definidas, evaluación.
4. Extrae de la guía de marca/logo: color primario, color secundario, color oscuro, color claro, variantes
   del logo disponibles, fondos donde el logo es legible.
5. Señala explícitamente: información faltante, contradicciones entre archivos, o contenido desactualizado.
