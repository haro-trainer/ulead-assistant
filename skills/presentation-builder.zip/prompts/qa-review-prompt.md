# Prompt de apoyo: revisión de calidad final

Antes de entregar, repasa mentalmente (o ejecuta explícitamente si el usuario pide auditoría formal):

1. ¿Cada slide tiene notas no vacías?
2. ¿Todo texto visible está dirigido a la audiencia (sin lenguaje de producción)?
3. ¿Ningún slide excede los límites de densidad?
4. ¿El logo nunca se superpone con título/subtítulo/controles?
5. ¿Todas las tarjetas tienen color de texto explícito y contraste suficiente?
6. ¿La navegación, pantalla completa y el toggle de notas (`S`) funcionan?
7. ¿Las capturas de pantalla en 1366×768 y 1920×1080 no muestran superposición ni texto oculto?
8. ¿El deck final no expone ningún panel de auditoría, badge, o contador de errores?

Si algo falla, corrígelo antes de entregar y documenta la corrección en `final-quality-report.md`.
