/* speaker-notes.js — toggles visibility of the active slide's speaker notes with "S".
   Notes are hidden by default, high z-index, readable on light/dark backgrounds, and never
   shown for more than the active slide. Exposes window.notesState for tests. */
(function () {
  let notesVisible = false;

  function applyVisibility() {
    document.querySelectorAll('.slide').forEach((slide) => {
      const note = slide.querySelector('.notes');
      if (!note) return;
      const isActive = slide.classList.contains('active');
      note.classList.toggle('visible', notesVisible && isActive);
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 's' || e.key === 'S') {
      notesVisible = !notesVisible;
      applyVisibility();
    }
  });

  document.addEventListener('slidechange', applyVisibility);
  applyVisibility();

  window.notesState = {
    isVisible: () => notesVisible,
    show: () => { notesVisible = true; applyVisibility(); },
    hide: () => { notesVisible = false; applyVisibility(); },
  };
})();
