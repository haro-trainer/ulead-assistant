/* navigation.js — keyboard + click navigation, fullscreen, progress bar, slide counter.
   Depends on: .slide elements inside #deck, .nav-btn.prev / .nav-btn.next, .progress-bar,
   .slide-counter. Exposes window.deckNav for tests. */
(function () {
  const slides = Array.from(document.querySelectorAll('.slide'));
  const total = slides.length;
  let current = 0;

  const prevBtn = document.querySelector('.nav-btn.prev');
  const nextBtn = document.querySelector('.nav-btn.next');
  const progressBar = document.querySelector('.progress-bar');
  const counter = document.querySelector('.slide-counter');

  function render() {
    slides.forEach((s, i) => s.classList.toggle('active', i === current));
    if (progressBar) progressBar.style.width = ((current + 1) / total * 100) + '%';
    if (counter) counter.textContent = (current + 1) + ' / ' + total;
    if (prevBtn) prevBtn.toggleAttribute('disabled', current === 0);
    if (nextBtn) nextBtn.toggleAttribute('disabled', current === total - 1);
    document.dispatchEvent(new CustomEvent('slidechange', { detail: { index: current } }));
  }

  function goTo(i) {
    current = Math.max(0, Math.min(total - 1, i));
    render();
  }
  function next() { goTo(current + 1); }
  function prev() { goTo(current - 1); }

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  }

  document.addEventListener('keydown', (e) => {
    switch (e.key) {
      case 'ArrowRight': case ' ': case 'PageDown': e.preventDefault(); next(); break;
      case 'ArrowLeft': case 'PageUp': e.preventDefault(); prev(); break;
      case 'Home': goTo(0); break;
      case 'End': goTo(total - 1); break;
      case 'f': case 'F': toggleFullscreen(); break;
      case 'Escape':
        document.querySelectorAll('.notes.visible').forEach(n => n.classList.remove('visible'));
        break;
      default: break;
    }
  });

  nextBtn?.addEventListener('click', next);
  prevBtn?.addEventListener('click', prev);

  render();

  // Exposed for automated tests (render_slides.py / tests/*.py use this).
  window.deckNav = { goTo, next, prev, getCurrent: () => current, getTotal: () => total };
})();
