# Usage notes

This skill was built for internal use designing academic/executive-education presentations. It has
no third-party license dependencies beyond the browser-native APIs it uses (Fullscreen API, standard
DOM/CSS). Fonts are system fonts by default (`--font-family` in theme-template.css) to avoid remote
font dependencies during offline delivery — swap in a self-hosted webfont (embedded as base64) if the
institution's brand requires one.

Do not redistribute a real institution's logo, proprietary syllabus content, or proprietary case
studies bundled inside a shared/public copy of this skill. The `assets/` and `examples/` folders in
this package intentionally contain only placeholder/generic material.
