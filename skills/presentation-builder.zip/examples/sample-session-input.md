# Sesión de ejemplo — "De almacenar datos a gobernarlos"

**Programa:** Executive Certificate in Modern Data Platforms
**Sesión:** 1 de 4 — Fundamentos de plataformas de datos modernas
**Audiencia:** profesionales de negocio y tecnología, nivel introductorio-intermedio
**Duración:** 90 minutos, modalidad virtual

## Resultados de aprendizaje
- Explicar la diferencia entre almacenar datos y gobernarlos.
- Identificar las capacidades que hacen "moderna" a una plataforma de datos.
- Analizar un caso de decisión de arquitectura con criterios de negocio.
- Aplicar un framework de 5 dimensiones para diagnosticar la madurez de datos de una organización.

## Contenido
1. Pregunta de apertura: ¿su organización almacena datos, o los gobierna?
2. Mito común: "tener un data lake ya es tener una estrategia de datos".
3. Framework de 5 dimensiones: calidad, linaje, acceso, seguridad, valor de negocio.
4. Evolución: de bases de datos relacionales → data warehouses → data lakes → lakehouses.
5. Arquitectura moderna: fuentes → ingesta → almacenamiento → procesamiento → consumo.
6. Caso aplicado: una aseguradora con datos dispersos en 6 sistemas decide si centralizar o federar.
7. Mensaje memorable: "Almacenar datos no es gobernar datos."

## Evaluación formativa sugerida
- Quiz de una pregunta: ¿cuál de estas opciones describe mejor gobernanza de datos?
- Reto grupal: clasificar 4 situaciones de negocio según qué dimensión del framework fallaría primero.

## Preparación para la siguiente sesión
Cada participante debe traer un ejemplo real (anonimizado) de una decisión de datos tomada en su
organización en los últimos 12 meses.
