# Checklist — Entrega final

- [ ] Todos los slides renderizan sin errores.
- [ ] No queda superposición crítica (logo, título, tarjetas, notas).
- [ ] No faltan notas en ningún slide.
- [ ] `S` funciona en todos los slides probados.
- [ ] La navegación (clic y teclado) funciona.
- [ ] Pantalla completa (`F`) funciona (o se documenta como no probable en el entorno de generación).
- [ ] El contraste es aceptable según `scripts/audit_accessibility.py`.
- [ ] El logo es visible y no gestiona su propia zona segura.
- [ ] Las capturas de pantalla en las resoluciones requeridas pasaron inspección visual.
- [ ] El deck final NO expone panel de auditoría, badge, o contador de issues.
- [ ] `final-quality-report.md` fue generado y refleja el estado real de la validación (sin afirmar
      éxito si algún paso no se completó).
