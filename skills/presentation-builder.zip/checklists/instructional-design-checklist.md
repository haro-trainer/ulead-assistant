# Checklist — Diseño instruccional

- [ ] Cada slide se puede trazar a un resultado de aprendizaje o a una sección del material fuente.
- [ ] El arco pedagógico sigue la secuencia: apertura → fundamento conceptual → progresión → aplicación
      moderna → aprendizaje aplicado → verificación.
- [ ] No hay más de 4 slides consecutivos puramente expositivos sin alternar con pregunta, actividad,
      ejemplo o reflexión.
- [ ] Los verbos de los resultados de aprendizaje son observables (Bloom), no "conocer"/"entender" sin más.
- [ ] Las actividades, casos y quizzes están alineados con lo que el material fuente realmente enseña.
- [ ] El balance ejecutivo-técnico está presente cuando el contenido es técnico (conexión con negocio,
      riesgos, decisiones).
