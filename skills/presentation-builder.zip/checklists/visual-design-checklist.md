# Checklist — Diseño visual

- [ ] Cada slide tiene un foco visual y conceptual único.
- [ ] Se prioriza diagrama/tabla/tarjeta/timeline sobre párrafos largos.
- [ ] Ningún slide excede los límites de densidad (35–45 palabras, 6 bullets, 5 tarjetas por fila, etc.)
- [ ] Los tamaños de fuente respetan los mínimos por elemento (nunca se reducen para que "quepa" el texto).
- [ ] El logo tiene su zona segura respetada en todos los slides donde aparece.
- [ ] Los márgenes seguros (5–7% laterales/superior, 7–9% inferior) se respetan.
- [ ] Las flechas de navegación no obstruyen contenido y se atenúan en el primer/último slide.
