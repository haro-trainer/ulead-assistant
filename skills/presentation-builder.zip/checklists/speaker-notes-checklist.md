# Checklist — Notas de orador

- [ ] El 100% de los slides tiene notas no vacías.
- [ ] Cada nota está redactada como narrativa (no fragmentos de metadatos).
- [ ] Cada nota cubre: propósito del slide, apertura sugerida, explicación central, error común a
      anticipar, pregunta para la audiencia, transición.
- [ ] Las notas permanecen ocultas por defecto y solo se muestran en el slide activo.
- [ ] `S` alterna correctamente las notas (verificado en al menos 3 tipos de fondo: oscuro, claro, marca).
- [ ] Ninguna instrucción exclusiva del instructor aparece en el contenido visible — solo en notas.
