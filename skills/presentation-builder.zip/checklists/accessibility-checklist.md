# Checklist — Accesibilidad y contraste

- [ ] Todo texto sobre tarjetas claras usa `--text-on-light`; sobre tarjetas oscuras, `--text-on-dark`.
- [ ] Ningún elemento depende de un color de texto heredado sin declarar explícitamente su color.
- [ ] Contraste ≥ 4.5:1 para texto normal y ≥ 3:1 para texto grande (ver `scripts/audit_accessibility.py`).
- [ ] Todas las imágenes tienen texto alternativo (`alt`).
- [ ] El deck es navegable por teclado en su totalidad (flechas, Espacio, Av/Re Pág, Inicio, Fin, F, S, Esc).
- [ ] El texto permanece legible al renderizar en 1366×768.
