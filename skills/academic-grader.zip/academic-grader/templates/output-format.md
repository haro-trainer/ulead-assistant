# Template de Salida — Evaluación de Entrega Estudiantil

Usa este template para estructurar cada evaluación. Reemplaza los placeholders entre corchetes.

---

## Información General

| Campo | Valor |
|---|---|
| Estudiante | [Nombre o identificador] |
| Curso | [Nombre del curso] |
| Tarea | [Nombre/número de la tarea] |
| Fecha de evaluación | [Fecha] |

---

## Resumen Ejecutivo

| Criterio | Puntaje |
|---|---|
| [Criterio 1] | [XX]/[YY] |
| [Criterio 2] | [XX]/[YY] |
| [Criterio 3] | [XX]/[YY] |
| [Criterio N] | [XX]/[YY] |
| **TOTAL** | **[XX]/[TOTAL]** |

---

## Checklist de Entregables

| Entregable esperado | Estado | Observación |
|---|---|---|
| [Entregable 1] | ✅ Verificado | [Breve nota si aplica] |
| [Entregable 2] | ⚠️ Parcial | [Qué falta o está incompleto] |
| [Entregable 3] | ❌ No encontrado | [No se encontró en la evidencia] |
| [Entregable 4] | 🔍 No verificable | [El formato no permite verificar] |

---

## Evaluación Detallada

### 1. [Nombre del Criterio 1]

**Puntaje: [XX]/[YY]**

[Justificación profesional. Debe incluir:
- Qué evidencia concreta sustenta el puntaje
- Si algo falta, qué específicamente no se encontró
- Referencia a screenshots, secciones del documento, outputs, etc.
- Si no fue verificable, indicar por qué]

---

### 2. [Nombre del Criterio 2]

**Puntaje: [XX]/[YY]**

[Justificación...]

---

### N. [Nombre del Criterio N]

**Puntaje: [XX]/[YY]**

[Justificación...]

---

## Nota Final

**[XX]/[TOTAL]**

[Si existe escala alfabética: **Nota: [Letra]**]

---

## Retroalimentación

[Párrafo de máximo 180 palabras. Adaptar tono según nivel de desempeño.
Incluir: fortalezas, aspectos a mejorar, recomendación concreta.]

---

## Elementos Detectados Automáticamente

### IA y Modelos utilizados
[Lista de modelos y servicios identificados en la entrega]

### Técnicas de Prompt Engineering
[Resumen de técnicas identificadas]

### Multimodalidad
[Modalidades detectadas]

> **Nota:** Esta sección es informativa y complementa la evaluación.
> Solo afecta el puntaje si la rúbrica lo requiere explícitamente.
