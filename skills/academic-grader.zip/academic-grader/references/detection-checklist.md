# Checklist de Detección Automática de Evidencias

Este documento lista todos los elementos que el evaluador debe buscar automáticamente en las
entregas de los estudiantes. No todos aplican a todas las tareas — usa solo los relevantes según
la rúbrica y la descripción de la tarea.

## 1. Flujo / Workflow / Pipeline

- [ ] Existe un flujo visible (diagrama, screenshots, StackAI canvas, notebook secuencial)
- [ ] El flujo está completo según los requerimientos de la tarea
- [ ] Se evidencia que el flujo es funcional (outputs, logs, capturas de ejecución)
- [ ] No hay errores visibles de ejecución
- [ ] Los pasos están conectados lógicamente
- [ ] Se manejan errores o edge cases

## 2. Prompt Engineering

### Detección de prompts
- [ ] System prompts
- [ ] User prompts / instrucciones
- [ ] Templates con variables
- [ ] Few-shot examples dentro de prompts
- [ ] Chain-of-thought explícito
- [ ] Role/persona setting
- [ ] Output format specification (JSON, tabla, lista)
- [ ] Constraints / guardrails en prompts

### Calidad de prompts
- [ ] Claridad y especificidad
- [ ] Uso de técnicas avanzadas (few-shot, CoT, self-consistency)
- [ ] Control de formato de salida
- [ ] Manejo de edge cases en prompts
- [ ] Iteración / refinamiento documentado

## 3. Modelos e IA utilizada

### Modelos
- [ ] GPT-4 / GPT-4o / GPT-3.5
- [ ] Claude (Sonnet, Opus, Haiku)
- [ ] Gemini (Pro, Flash)
- [ ] Llama (2, 3, 3.1)
- [ ] Mistral / Mixtral
- [ ] Modelos locales via Ollama
- [ ] Modelos locales via GPT4All
- [ ] Otros modelos open-source

### Servicios y APIs
- [ ] OpenAI API
- [ ] Anthropic API
- [ ] Google AI / Vertex AI
- [ ] Azure OpenAI
- [ ] ElevenLabs (TTS)
- [ ] Whisper / Deepgram (STT)
- [ ] Runway / Stable Diffusion (imagen/video)
- [ ] Hugging Face Inference API

### Plataformas
- [ ] StackAI
- [ ] Google Colab
- [ ] VS Code
- [ ] Hugging Face Spaces
- [ ] LangChain / LlamaIndex
- [ ] CrewAI / AutoGen

## 4. Multimodalidad

- [ ] Texto (entrada y salida)
- [ ] Imagen (generación, análisis, input)
- [ ] Audio (entrada o salida)
- [ ] Video (generación o análisis)
- [ ] Speech-to-Text (STT)
- [ ] Text-to-Speech (TTS)
- [ ] Traducción automática
- [ ] Resumen / síntesis
- [ ] Narración generada
- [ ] RAG (Retrieval-Augmented Generation)
- [ ] Agentes autónomos
- [ ] Tool calling / Function calling
- [ ] Salida estructurada (JSON, tabla, CSV)

## 5. Documentación

- [ ] Introducción / contexto
- [ ] Arquitectura / diagrama del sistema
- [ ] Descripción del workflow
- [ ] Diagramas (flujo, secuencia, componentes)
- [ ] Prompts documentados con justificación
- [ ] Resultados mostrados con evidencia
- [ ] Análisis comparativo (si aplica)
- [ ] Reflexión crítica
- [ ] Conclusiones
- [ ] Recomendaciones para mejora o producción
- [ ] Referencias / bibliografía

## 6. Seguridad y Robustez (si aplica)

- [ ] Pruebas de prompt injection
- [ ] Manejo de PII
- [ ] Pruebas adversariales (red team / blue team)
- [ ] Validación de salidas
- [ ] Manejo de alucinaciones
- [ ] Fallbacks o manejo de errores
- [ ] Rate limiting / control de costos

## 7. Calidad de Código (si aplica)

- [ ] Código organizado y legible
- [ ] Comentarios relevantes
- [ ] Manejo de errores (try/except)
- [ ] Variables y funciones con nombres descriptivos
- [ ] Reproducibilidad (requirements, instrucciones de ejecución)
- [ ] Versionamiento (Git, commits)
