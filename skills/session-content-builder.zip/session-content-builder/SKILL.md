---
name: session-content-builder
description: >-
  Procesa un plan de curso/sesión ya elaborado (objetivo, agenda por bloques, actividades, evaluación) y
  genera los artefactos derivados que un profesor, coordinador o diseñador instruccional necesita para
  impartir la clase: slides, agendas formateadas, guías de estudiante, notas del profesor, actividades,
  quizzes, rúbricas, bancos de preguntas y homework. Úsalo cuando el usuario tenga o pegue un plan de
  clase/sesión (Markdown, Word, etc.) y pida "conviértelo en slides", "genera el material de esta clase",
  "crea la rúbrica/quiz/agenda de esta sesión", "desarrolla el contenido", o cualquier paquete de materiales
  a partir de un plan ya existente -incluye programas ejecutivos universitarios, sílabos o expandir un
  "Plan.md" de clase-. No sustituye el criterio del profesor: entrega borradores para validación humana.
---

# Session Content Builder

Este skill convierte un **plan de curso o de sesión ya definido** (objetivo, agenda minuto a minuto, contenido por bloque, actividad práctica, materiales, evaluación) en los **artefactos concretos** que se necesitan para impartirlo: slides, agenda formateada, guías, quiz, rúbrica, banco de preguntas, notas del profesor, homework, etc.

No diseña el curso desde cero ni reemplaza el criterio del profesor — **opera sobre un plan que ya existe** y lo desarrolla, siguiendo los mismos principios pedagógicos y de calidad con los que fue concebido, para que todo el paquete de materiales sea coherente entre sí.

## Por qué importa procesar el plan y no generar "desde cero"

Cuando cada artefacto (slides, quiz, rúbrica, guía) se genera de forma independiente, es fácil que terminen desalineados: la rúbrica evalúa algo que no se enseñó, el quiz no cubre los resultados de aprendizaje, o las slides no siguen la misma secuencia que la agenda. Por eso el punto de partida **siempre** es el plan ya elaborado: todo lo que se genere debe poder trazarse de vuelta a un bloque, objetivo o actividad específica del plan.

## Flujo de trabajo

### Paso 1 — Ingerir y entender el plan

Localiza el plan de curso/sesión (archivo subido, pegado en el chat, o referenciado). Léelo completo antes de generar nada. Extrae y ten explícitamente en mente:

- **Título y objetivo** de la sesión/curso.
- **Agenda por bloques** (tiempos, temas).
- **Contenido por bloque**: conceptos clave, ejemplos de negocio, errores comunes.
- **Actividad práctica** (pasos, herramientas, roles de equipo).
- **Materiales sugeridos** ya mencionados en el plan.
- **Evaluación formativa** (preguntas/quiz existentes, si los hay).
- **Homework / tarea** ya definida.

Si el plan está incompleto en alguna sección que el artefacto solicitado necesita (p. ej. piden un quiz pero el plan no trae preguntas), no inventes contenido desconectado: deriva las preguntas de los conceptos clave y ejemplos que sí están en el plan, y dilo explícitamente ("Generé estas preguntas a partir de los conceptos del Bloque 3, ya que el plan no traía preguntas propias").

### Paso 2 — Confirmar qué artefacto(s) generar

Si el usuario ya especificó el artefacto (p. ej. "hazme las slides"), procede directo. Si la petición es ambigua ("desarrolla esta clase" o "genera el material de la sesión 2"), pregunta brevemente cuál(es) de estos necesita primero, o —si el contexto lo deja claro— asume el paquete estándar (agenda + slides + quiz + rúbrica) y dilo antes de empezar:

| Artefacto | Qué produce | Referencia |
|---|---|---|
| Agenda formateada | Documento de agenda lista para publicar (fechas/bloques, resultados, entregables) | `references/plantillas.md#agenda` |
| Plan de clase detallado | Minuto a minuto con transiciones, notas de facilitación | `references/plantillas.md#plan-de-clase` |
| Presentación (slides) | Estructura de deck: 1 slide por concepto/ejemplo/ejercicio, siguiendo el estilo observado en decks institucionales (título breve + bullets de apoyo, no párrafos) | usar skill `pptx` para construir el archivo |
| Guía para estudiantes | Documento de apoyo con conceptos, ejemplos y checklist | `references/plantillas.md#guia-estudiante` |
| Notas del profesor | Guion de facilitación: qué decir, qué preguntar, tiempos, señales de alerta | `references/plantillas.md#notas-profesor` |
| Actividad/laboratorio | Instrucciones paso a paso, roles, entregable, tiempo | `references/plantillas.md#actividad` |
| Quiz / evaluación formativa | Preguntas con respuesta y justificación, mapeadas a conceptos del plan | `references/plantillas.md#quiz` |
| Rúbrica | Criterios observables + niveles de desempeño + ponderación | `references/plantillas.md#rubrica` |
| Banco de preguntas | Preguntas variadas por nivel de Bloom, listas para reutilizar | `references/plantillas.md#banco-preguntas` |
| Homework / tarea | Instrucciones de entrega + criterios de éxito | `references/plantillas.md#homework` |

### Paso 3 — Aplicar los principios pedagógicos al generar

Antes de redactar, revisa `references/principios_pedagogicos.md` si no lo tienes fresco en contexto. En resumen, cada artefacto debe:

- **Alinearse hacia atrás (backward design)**: partir del objetivo/resultado del plan, no de una lista de temas suelta.
- **Usar verbos de Bloom observables** en objetivos y preguntas de evaluación (evita "conocer"/"entender" sin un desempeño verificable).
- **Mantener alineamiento constructivo**: todo lo que se evalúa (quiz, rúbrica) debe corresponder a algo que el plan efectivamente enseña o practica.
- **Priorizar aprendizaje activo y aplicado**: ejemplos de negocio reales, casos, ejercicios prácticos — igual que el tono del plan de origen — en vez de exposición puramente teórica.
- **Respetar el ritmo ejecutivo/microlearning**: bloques breves, lenguaje profesional, sin densidad innecesaria.

### Paso 4 — Generar el artefacto

- Para documentos de texto (agenda, guía, notas del profesor, quiz, rúbrica, homework): usa las plantillas de `references/plantillas.md` como estructura base, y consulta primero el skill `docx` si el usuario quiere un archivo Word, o `md`/artifact si basta un documento en el chat.
- Para presentaciones: consulta primero el skill `pptx` (`/mnt/skills/public/pptx/SKILL.md`) antes de crear el archivo. Usa el estilo observado en decks institucionales de referencia: portada con curso/módulo, una slide de agenda, una slide por tema/bloque con 3-5 bullets máximo, slides de ejercicio con instrucciones cortas, slide de cierre con "lo esencial para llevarse hoy".
- Para hojas de cálculo (banco de preguntas extenso, `eval_sheet.csv` de seguimiento): usa el skill `xlsx`.
- Mantén el idioma del plan de origen (normalmente español) y el mismo nivel de formalidad.

### Paso 5 — Control de calidad antes de entregar

Revisa el artefacto generado contra `references/checklist_calidad.md`: alineamiento con el plan, cobertura de los bloques, claridad de instrucciones, ausencia de duplicación, progresión de dificultad razonable. Si detectas un vacío (p. ej. un objetivo del plan que ningún artefacto cubre), menciónalo al usuario en vez de ignorarlo silenciosamente.

### Paso 6 — Entregar con trazabilidad y validación humana

Todo artefacto que produzcas es un **borrador para revisión del profesor/coordinador**, nunca contenido final publicado automáticamente. Al entregar, indica brevemente:

- de qué plan se derivó (nombre/título de la sesión);
- qué bloques o secciones del plan se usaron como fuente;
- qué se generó por inferencia porque el plan no lo especificaba (si aplica).

No hace falta un descargo largo — una línea al final basta, p. ej.: *"Generado a partir del plan de la Sesión 1; el quiz cubre los Bloques 3–6. Queda pendiente tu validación antes de usarlo en clase."*

## Notas importantes

- Este skill **no reemplaza** el criterio del profesor ni aprueba contenido por sí mismo — el modelo de gobierno es *human-in-the-loop*: propone, el humano decide.
- Si el usuario pide generar un **programa o curso completo desde cero** (perfil de salida, malla curricular, sílabo institucional), eso corresponde a un nivel anterior del proceso (diseño curricular/de sílabo) y no al alcance de este skill — puedes ayudarlo igual, pero acláralo: aquí el foco es *desarrollar* una sesión/curso ya planificado, no diseñar la arquitectura del programa.
- Si el plan de origen no sigue el formato de `Clase 1 - Plan.md` (título+objetivo, agenda por bloques, contenido por bloque, actividad, materiales, evaluación, homework), adapta la lectura: extrae las mismas piezas conceptuales aunque estén organizadas distinto.
