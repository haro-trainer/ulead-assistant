# Principios pedagógicos a aplicar

Resumen operativo — no repetir esto al usuario, solo aplicarlo al generar contenido.

## Diseño inverso (Backward Design)
1. Parte del resultado de aprendizaje / objetivo ya definido en el plan.
2. Pregúntate qué evidencia demostraría que se logró (esto define quiz/rúbrica).
3. Solo entonces genera actividades y contenidos — nunca al revés (temas sueltos sin resultado claro).

## Alineamiento constructivo
Todo lo generado (contenido, actividad, evaluación, rúbrica) debe corresponder explícitamente a un resultado de aprendizaje del plan. Si generas una pregunta de quiz o un criterio de rúbrica que no se conecta con nada del plan, es una señal de que algo está desalineado — reformúlalo o pregúntale al usuario si el plan necesita ese resultado adicional.

## Taxonomía de Bloom
Usa verbos observables y medibles: recordar, comprender, aplicar, analizar, evaluar, crear. Evita "conocer" o "entender" sin especificar el desempeño. Al escribir preguntas de quiz o criterios de rúbrica, distribúyelos en más de un nivel — no todo debe ser memorización.

## Aprendizaje de adultos (audiencia ejecutiva)
Prioriza: relevancia profesional inmediata, solución de problemas reales, aprovechamiento de experiencia previa, aplicación al contexto laboral, colaboración, aprendizaje basado en proyectos/casos. Los ejemplos deben sonar a "esto me sirve en mi trabajo mañana", no a ejercicios académicos abstractos.

## Aprendizaje activo
Nada de contenido puramente expositivo. Prioriza estudios de caso, simulaciones, laboratorios guiados, debates, análisis de decisiones, retos aplicados, revisión entre pares — consistente con el tono ya presente en los planes de origen (ej. "Prompt Clinic", "Bug Hunt", "Red Team Sprint").

## Microlearning y ritmo ejecutivo
Bloques breves y manejables: explicación corta → práctica → retroalimentación → aplicación. Evita párrafos densos en slides o guías; prioriza bullets accionables y lenguaje profesional y directo.

## Human-in-the-loop
La IA propone, el humano aprueba. Ningún artefacto generado por este skill se considera final o listo para publicar sin revisión de un profesor, coordinador o diseñador instruccional.
