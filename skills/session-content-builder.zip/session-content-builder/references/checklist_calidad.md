# Checklist de calidad antes de entregar

Revisa mentalmente (o explícitamente si el usuario pide auditoría) cada artefacto generado contra esto:

- [ ] **Alineamiento**: ¿cada actividad/pregunta/criterio se conecta con un objetivo o bloque específico del plan de origen?
- [ ] **Cobertura**: ¿todos los objetivos/bloques importantes del plan quedaron representados en el artefacto, o hay un vacío evidente?
- [ ] **Progresión**: si hay varias preguntas o actividades, ¿la dificultad avanza de forma razonable en vez de saltar aleatoriamente?
- [ ] **No duplicación**: ¿se repite la misma pregunta/criterio con otras palabras sin agregar valor?
- [ ] **Claridad de instrucciones**: ¿alguien que no estuvo en la planeación entendería qué hacer solo leyendo el artefacto?
- [ ] **Calidad de la rúbrica** (si aplica): ¿los niveles de desempeño son claramente distinguibles entre sí, no solo adjetivos vagos?
- [ ] **Tono y ritmo**: ¿el lenguaje es profesional, directo, sin relleno, consistente con el plan de origen?
- [ ] **Trazabilidad**: ¿queda claro de qué plan/sesión se derivó y qué se infirió por falta de información en el plan?

Si algo falla, corrígelo antes de entregar. Si no puedes corregirlo sin más información del usuario, dilo explícitamente en vez de entregar un artefacto con el vacío sin mencionar.
