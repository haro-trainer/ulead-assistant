# Plantillas de artefactos

Estas plantillas son puntos de partida, no camisas de fuerza. Ajusta secciones según lo que el plan de origen realmente contenga. Los nombres de sección en español coinciden con el vocabulario usado en los planes de curso de referencia.

---

## agenda

```markdown
# Agenda — [Título de la sesión]

**Fecha/semana:** [ ]
**Duración total:** [ ]
**Objetivo de la sesión:** [tomado literalmente del plan]

| Bloque | Horario | Tema | Resultado esperado | Entregable/Actividad |
|---|---|---|---|---|
| 1 | 0:00–0:15 | ... | ... | ... |

**Preparación previa (si aplica):** [ ]
**Trabajo posterior:** [ ]
```

---

## plan-de-clase

```markdown
# Plan de clase detallado — [Título]

## Objetivos específicos
- [Verbo Bloom] + [desempeño observable]

## Minuto a minuto

### [Bloque N] ([hh:mm–hh:mm]) — [Nombre del bloque]
**Qué hace el facilitador:** [ ]
**Qué hacen los participantes:** [ ]
**Transición al siguiente bloque:** [ ]
**Señales de que el grupo no está siguiendo (y qué hacer):** [ ]
```

---

## guia-estudiante

```markdown
# Guía del estudiante — [Título de la sesión]

## Antes de la clase
[Preparación previa, lecturas, instalación de herramientas]

## Conceptos clave de la sesión
[Resumen de los conceptos por bloque, en lenguaje claro]

## Ejemplos aplicados
[Los ejemplos de negocio del plan, redactados como referencia rápida]

## Checklist de la actividad práctica
- [ ] Paso 1 ...
- [ ] Paso 2 ...

## Después de la clase
[Tarea/homework y criterios de éxito]
```

---

## notas-profesor

```markdown
# Notas del profesor — [Título de la sesión]

## Antes de empezar
[Materiales a tener listos, configuración técnica, verificación de equipos]

## Guion de facilitación por bloque
### [Bloque N] — [Nombre]
- **Frase de apertura sugerida:** [ ]
- **Preguntas para activar discusión:** [ ]
- **Errores comunes a anticipar:** [tomados del plan]
- **Qué hacer si sobra/falta tiempo:** [ ]

## Cierre de la sesión
[Síntesis sugerida + transición a la siguiente sesión]
```

---

## actividad

```markdown
# Actividad — [Nombre de la actividad]

**Objetivo:** [ligado a un resultado de aprendizaje del plan]
**Duración:** [ ]
**Modalidad:** [individual / parejas / equipos de N]
**Herramientas necesarias:** [ ]

## Paso a paso
1. [ ]
2. [ ]

## Entregable
[Qué deben producir/mostrar]

## Criterio de éxito
[Cómo saben que lo lograron — enlaza con la rúbrica si existe]
```

---

## quiz

```markdown
# Evaluación formativa — [Título de la sesión]

1. **[Pregunta ligada a Bloque/concepto X]**
   a) [ ]  b) [ ]  c) [ ]  d) [ ]
   **Respuesta:** [ ]  **Por qué:** [breve justificación pedagógica, no solo la letra]
```

Reglas para escribir preguntas:
- Cada pregunta debe trazarse a un bloque o concepto específico del plan (anótalo internamente, no hace falta mostrarlo en el quiz final salvo que el usuario lo pida).
- Evita distractores absurdos; los distractores deben representar errores conceptuales reales y comunes (usa los "errores comunes" del plan como fuente).
- Varía el nivel de Bloom: no todas las preguntas deben ser de "recordar".

---

## rubrica

```markdown
# Rúbrica — [Nombre de la actividad/entregable evaluado]

| Criterio | Insuficiente (0) | En desarrollo (1) | Logrado (2) | Ponderación |
|---|---|---|---|---|
| [Criterio 1, observable] | ... | ... | ... | [%] |

**Puntaje total:** [ ]
**Condición mínima de aprobación:** [ ]
```

Cada criterio debe ser observable (algo que se pueda ver/leer en el entregable), no un rasgo de actitud vago. Los descriptores de cada nivel deben diferenciarse claramente entre sí, no solo en adjetivos ("bueno" vs "muy bueno").

---

## banco-preguntas

```markdown
# Banco de preguntas — [Tema/curso]

## Nivel: Recordar / Comprender
- [ ]

## Nivel: Aplicar / Analizar
- [ ]

## Nivel: Evaluar / Crear
- [ ]
```

Organiza siempre por nivel de Bloom para que el profesor pueda elegir según el momento del curso (diagnóstico vs. evaluación sumativa final).

---

## homework

```markdown
# Tarea — [Título de la sesión]

**Entrega:** [formato y medio]
**Tiempo estimado:** [ ]

## Instrucciones
1. [ ]

## Qué debes incluir
- [ ]

## Criterios de éxito
- [ ]

## Nota de privacidad/datos (si aplica)
[Qué anonimizar u omitir]
```
