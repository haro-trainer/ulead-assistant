# university-syllabus-designer

Skill reutilizable para Claude que transforma contenido académico preliminar en un sílabo universitario
completo, alineado a estándares institucionales.

## ¿Qué hace?

A partir de un documento fuente (PDF de un curso o programa, notas de un coordinador, un esquema de
evaluación en imagen), genera:

- Un sílabo completo (26 secciones estándar, o la estructura institucional que se le adjunte).
- Resultados de aprendizaje redactados con verbos observables (Taxonomía de Bloom).
- Una matriz de alineamiento curricular (resultados ↔ contenidos ↔ actividades ↔ evaluaciones).
- Verificación aritmética del sistema de evaluación (que sume 100%).
- Personalización basada en el perfil profesional del profesor (si se provee su LinkedIn), sin inventar
  credenciales.
- Un reporte de trazabilidad: supuestos, información faltante, cambios propuestos y elementos pendientes
  de aprobación académica.

## Instalación

1. Copia la carpeta `university-syllabus-designer/` a tu directorio de skills (`/mnt/skills/user/` en
   Claude.ai/Claude Code, o el directorio de skills de tu organización).
2. Asegúrate de que el archivo `SKILL.md` conserve su frontmatter YAML (`name`, `description`) sin editar
   el nombre, salvo que quieras renombrar el skill deliberadamente.
3. No se requieren dependencias externas: el skill usa las herramientas estándar de Claude (búsqueda web,
   lectura de archivos, generación de documentos).

## Uso típico

```
Tengo el PDF con el contenido preliminar del curso "Streaming y Arquitecturas Event-Driven"
del Máster en Big Data Analytics. Aquí está el PDF y la tabla de evaluación institucional.
Ayúdame a generar el sílabo completo. El profesor es [nombre], su LinkedIn es [url].
```

Claude:

1. Extrae del PDF lo que ya está disponible (objetivos, contenidos por semana, herramientas).
2. Pregunta solo lo que realmente falta (p. ej. modalidad, duración de sesión, si no vienen en el PDF).
3. Verifica que la evaluación adjunta sume 100%.
4. Investiga el perfil del profesor para personalizar ejemplos, sin inventar experiencia.
5. Redacta el sílabo completo siguiendo la plantilla institucional (o la genérica de este skill si no hay
   una adjunta).
6. Entrega el sílabo junto con la matriz de alineamiento y el resumen de supuestos/pendientes.

## Estructura del paquete

```text
university-syllabus-designer/
├── SKILL.md                              # instrucciones principales (léelo primero)
├── README.md                             # este archivo
├── prompts/
│   ├── system-prompt.md                  # rol y postura general del asistente
│   ├── syllabus-generation-prompt.md     # prompt de referencia para redactar el sílabo
│   └── quality-review-prompt.md          # prompt de referencia para la auto-revisión
├── templates/
│   ├── syllabus-template.md              # plantilla genérica de 26 secciones
│   ├── alignment-matrix-template.md      # formato de matriz de alineamiento
│   └── evaluation-template.md            # formato de tabla de evaluación + verificación
├── examples/
│   ├── sample-input.md                   # ejemplo de insumos (basado en un caso real)
│   └── sample-output.md                  # extracto del sílabo resultante
├── validators/
│   └── syllabus-quality-checklist.md     # checklist de control de calidad
└── references/
    └── institutional-requirements.md     # cómo priorizar una plantilla institucional real
```

## Convención para artefactos múltiples

Cuando una ejecución del skill produzca 3 o más archivos de salida (p. ej. sílabo + matriz + cronograma +
tabla de evaluación), empaquétalos así antes de entregarlos:

```text
<curso-en-slug>-silabo/
├── README.md                 # qué contiene el paquete y cómo usarlo
├── silabo.md (o .docx)
├── matriz-alineamiento.md
├── cronograma.md
└── evaluacion.md
```

y comprime esa carpeta en un `.zip` con el mismo nombre para entrega descargable.

## Límites del skill

- No sustituye el criterio del profesor, coordinador o director de programa: todo cambio respecto a la
  plantilla o evaluación institucional se presenta como propuesta, nunca como hecho consumado.
- No inventa credenciales, publicaciones ni experiencia del profesor.
- No diseña tareas, quizzes, proyectos o rúbricas detalladas a nivel de actividad — para eso existe el skill
  complementario `course-assessment-and-activity-designer`.
