# university-syllabus-designer

Skill reutilizable para Claude que transforma contenido académico preliminar en un sílabo universitario
completo, alineado a estándares institucionales.

## ¿Qué hace?

A partir de un documento fuente (PDF de un curso o programa, notas de un coordinador, un esquema de
evaluación en imagen), genera:

- Un sílabo completo (26 secciones estándar, o la estructura institucional que se le adjunte).
- Resultados de aprendizaje redactados con verbos observables (Taxonomía de Bloom).
- Una matriz de alineamiento curricular (resultados ↔ contenidos ↔ actividades ↔ evaluaciones).
- Verificación aritmética del sistema de evaluación (que sume 100%).
- Personalización basada en el perfil profesional del profesor (si se provee su LinkedIn), sin inventar
  credenciales.
- Un reporte de trazabilidad: supuestos, información faltante, cambios propuestos y elementos pendientes
  de aprobación académica.

## Instalación

1. Copia la carpeta `university-syllabus-designer/` a tu directorio de skills (`/mnt/skills/user/` en
   Claude.ai/Claude Code, o el directorio de skills de tu organización).
2. Asegúrate de que el archivo `SKILL.md` conserve su frontmatter YAML (`name`, `description`) sin editar
   el nombre, salvo que quieras renombrar el skill deliberadamente.
3. No se requieren dependencias externas: el skill usa las herramientas estándar de Claude (búsqueda web,
   lectura de archivos, generación de documentos).

## Uso típico

```
Tengo el PDF con el contenido preliminar del curso "Streaming y Arquitecturas Event-Driven"
del Máster en Big Data Analytics. Aquí está el PDF y la tabla de evaluación institucional.
Ayúdame a generar el sílabo completo. El profesor es [nombre], su LinkedIn es [url].
```

Claude:

1. Extrae del PDF lo que ya está disponible (objetivos, contenidos por semana, herramientas).
2. Pregunta solo lo que realmente falta (p. ej. modalidad, duración de sesión, si no vienen en el PDF).
3. Verifica que la evaluación adjunta sume 100%.
4. Investiga el perfil del profesor para personalizar ejemplos, sin inventar experiencia.
5. Redacta el sílabo completo siguiendo la plantilla institucional (o la genérica de este skill si no hay
   una adjunta).
6. Entrega el sílabo junto con la matriz de alineamiento y el resumen de supuestos/pendientes.

## Estructura del paquete

```text
university-syllabus-designer/
├── SKILL.md                              # instrucciones principales (léelo primero)
├── README.md                             # este archivo
├── prompts/
│   ├── system-prompt.md                  # rol y postura general del asistente
│   ├── syllabus-generation-prompt.md     # prompt de referencia para redactar el sílabo
│   └── quality-review-prompt.md          # prompt de referencia para la auto-revisión
├── templates/
│   ├── syllabus-template.md              # plantilla genérica de 26 secciones
│   ├── alignment-matrix-template.md      # formato de matriz de alineamiento
│   └── evaluation-template.md            # formato de tabla de evaluación + verificación
├── examples/
│   ├── sample-input.md                   # ejemplo de insumos (basado en un caso real)
│   └── sample-output.md                  # extracto del sílabo resultante
├── validators/
│   └── syllabus-quality-checklist.md     # checklist de control de calidad
└── references/
    └── institutional-requirements.md     # cómo priorizar una plantilla institucional real
```

## Convención para artefactos múltiples

Cuando una ejecución del skill produzca 3 o más archivos de salida (p. ej. sílabo + matriz + cronograma +
tabla de evaluación), empaquétalos así antes de entregarlos:

```text
<curso-en-slug>-silabo/
├── README.md                 # qué contiene el paquete y cómo usarlo
├── silabo.md (o .docx)
├── matriz-alineamiento.md
├── cronograma.md
└── evaluacion.md
```

y comprime esa carpeta en un `.zip` con el mismo nombre para entrega descargable.

## Historial de versiones

| Versión | Cambios |
|---|---|
| v1.2 | Se reemplaza el supuesto genérico "60% práctica / 35% conceptual" por la **agenda de sesión vigente de 6 bloques con minutos exactos** (Apertura y conexión 10 min, Desarrollo conceptual 50 min, Receso 15 min, Taller o caso práctico 60 min, Discusión y reflexión 30 min, Aplicación al contexto laboral 15 min, para una sesión de 3 horas), con reglas de escalamiento proporcional a otras duraciones. Nuevo archivo `references/agenda-sesion-tipo.md`. El bloque "Taller o caso práctico" (60 min) queda establecido como el presupuesto de tiempo exacto que `applied-case-designer` debe usar, corrigiendo el supuesto anterior de ~108 min. |
| v1.1 | Se incorpora el modelo pedagógico vigente: 60% práctica aplicada / 35% conceptual con discusión y reflexión aplicada al contexto laboral. Se agrega la cadencia de proyecto práctico rotativo (desde la Sesión 2, cada sesión abre un caso práctico que se entrega al inicio de la siguiente). Se actualiza el esquema de evaluación institucional por defecto a: Caso práctico aplicado 1 (25%), Caso práctico aplicado 2 (25%), Caso práctico aplicado 3 (30%), Asistencia (20%). Nuevo archivo `references/modelo-practica-aplicada.md`. |
| v1.0 | Versión inicial: sílabo completo a partir de contenido preliminar, con esquema de evaluación genérico de Tareas/Participación/Asistencia. |

## Límites del skill

- No sustituye el criterio del profesor, coordinador o director de programa: todo cambio respecto a la
  plantilla o evaluación institucional se presenta como propuesta, nunca como hecho consumado.
- No inventa credenciales, publicaciones ni experiencia del profesor.
- No diseña tareas, quizzes, proyectos o rúbricas detalladas a nivel de actividad — para eso existe el skill
  complementario `course-assessment-and-activity-designer`.
