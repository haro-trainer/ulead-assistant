# Prompt de referencia — Generación del sílabo

Usa este esqueleto para estructurar tu razonamiento (no es obligatorio copiarlo literalmente al usuario).

---

**Entrada disponible:**
- Documento fuente: {resumen de lo extraído: objetivos, contenidos por semana, herramientas, artefactos}
- Plantilla institucional: {adjunta / no adjunta → usar genérica}
- Curso: {nombre}
- Programa: {nombre, si aplica}
- Profesor: {nombre completo}
- Perfil profesional relevante del profesor: {hallazgos verificables de LinkedIn/búsqueda web, o "no
  disponible"}
- Nivel: {básico / intermedio / avanzado}
- Modalidad: {virtual / presencial / híbrida}
- Duración: {semanas, sesiones, horas}
- Perfil de estudiantes: {si se conoce}
- Evaluación institucional adjunta: {tabla de rubros y porcentajes, con verificación de suma = 100%}

**Instrucción de generación:**

1. Redacta la sección de información general usando exactamente los datos disponibles; donde falte un
   dato, escribe `[PENDIENTE: <qué falta>]` en vez de inventarlo.

2. Redacta la descripción y justificación del curso conectándolo con el perfil de salida del programa (si
   se conoce) y con las tendencias vigentes del campo (verificadas por búsqueda web si el contenido es
   técnico y puede quedar desactualizado).

3. Redacta resultados de aprendizaje: 4 a 6 por curso, verbos Bloom observables, progresión de complejidad
   acorde al nivel, cada uno conectado a al menos una actividad y una evaluación explícita.

4. Organiza los contenidos por semana/sesión conservando la secuencia lógica del documento fuente, pero
   mejorando la redacción y completando huecos evidentes (nunca inventando temas ajenos al alcance
   original).

5. Propón experiencias de aprendizaje activo calibradas a nivel, modalidad, duración y herramientas
   disponibles. Cuando el profesor tenga una fortaleza verificable (p. ej. experiencia en banca, en
   consultoría, en una industria específica), sugiere cómo aprovecharla en un caso o ejemplo — nombrando
   la fuente de esa fortaleza.

6. Redacta la sección de evaluación reproduciendo el esquema institucional verificado. Si propones un
   cambio, sepáralo claramente como "Propuesta de ajuste (requiere aprobación)".

7. Construye el cronograma consolidando semanas, temas, actividades y entregables en una tabla.

8. Genera la matriz de alineamiento usando `templates/alignment-matrix-template.md`.

9. Completa bibliografía, políticas de uso responsable de IA, integridad académica y requisitos de
   participación/aprobación según lo que indique la plantilla institucional o, en su ausencia,
   `templates/syllabus-template.md`.

10. Cierra con historial de versión (fecha de generación, fuente, versión) y la sección de trazabilidad
    (supuestos, información faltante, cambios propuestos, pendientes de aprobación).
