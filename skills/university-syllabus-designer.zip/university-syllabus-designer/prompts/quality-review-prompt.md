# Prompt de referencia — Auto-revisión de calidad

Antes de entregar el sílabo como definitivo, revísalo completo contra estas preguntas. Si alguna respuesta
es "no" o "no estoy seguro", corrígelo o repórtalo en la sección de trazabilidad — no lo entregues callado.

1. ¿Cada sección exigida por la plantilla institucional (o por `templates/syllabus-template.md` en su
   ausencia) está presente, en el orden correcto?
2. ¿Los porcentajes de evaluación suman exactamente 100%? Muestra la suma explícita.
3. ¿Todos los verbos de los resultados de aprendizaje son observables y medibles? Marca cualquier
   "conocer/entender/familiarizarse" que no tenga evidencia observable asociada.
4. ¿Cada resultado de aprendizaje se conecta con al menos una actividad y una evaluación en la matriz de
   alineamiento?
5. ¿La dificultad progresa de forma razonable semana a semana / unidad a unidad?
6. ¿Hay contenidos o actividades duplicadas entre semanas?
7. ¿El balance entre teoría y práctica es razonable para la modalidad y duración del curso?
8. ¿La carga de trabajo implícita (lecturas + actividades + entregables) es viable en las horas
   disponibles?
9. ¿Todo dato atribuido al profesor (experiencia, especialización) está respaldado por una fuente pública
   verificable o por lo que el usuario indicó explícitamente? Señala cualquier afirmación que no lo esté.
10. ¿Las tecnologías y referencias mencionadas siguen vigentes? (si hubo dudas, se verificaron por
    búsqueda web y se citó fuente y fecha).
11. ¿El documento es accesible y con formato profesional (encabezados claros, tablas bien formadas, sin
    jerga sin explicar)?
12. ¿Existe alguna afirmación en el documento que no venga del documento fuente, de lo indicado por el
    usuario, o de una fuente verificada? Si la hay, elimínala o márcala como supuesto.

Cierra siempre con la lista de:
- Supuestos realizados.
- Información faltante.
- Cambios propuestos frente a la plantilla o evaluación institucional.
- Elementos que requieren aprobación académica antes de publicar.
