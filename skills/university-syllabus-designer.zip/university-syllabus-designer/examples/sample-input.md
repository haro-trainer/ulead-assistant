# Ejemplo de entrada — Caso funcional

Este ejemplo usa un caso real de referencia: el curso "Streaming, Event-Driven Architecture y Analítica en
Tiempo Real" del Máster Ejecutivo en Big Data Analytics.

## Documento fuente (extracto relevante entregado por el coordinador)

- **Programa:** Máster Ejecutivo en Big Data Analytics — ruta "Arquitecturas Avanzadas de Datos e IA".
- **Curso:** Streaming, Event-Driven Architecture y Analítica en Tiempo Real (Curso 5 de 9).
- **Objetivo principal:** Diseñar soluciones de datos en tiempo real usando eventos, streaming, colas,
  topics, procesamiento continuo y patrones de reacción empresarial.
- **Objetivos específicos:** comprender diferencias batch/micro-batch/streaming/event-driven; diseñar
  flujos basados en eventos; entender Kafka (topics, producers, consumers, schemas, retención); aplicar
  ventanas, watermarks y datos tardíos; identificar casos de uso (fraude, IoT, clickstream, logística,
  recomendaciones, alertas).
- **Contenidos por semana:** (1) Pensar en eventos — event storming; (2) Kafka y plataformas de streaming;
  (3) Procesamiento con Flink / Spark Structured Streaming; (4) Caso de uso real-time AI-ready.
- **Herramientas sugeridas:** Apache Kafka, Confluent Cloud Trial, Apache Flink, Spark Structured
  Streaming, Redpanda (opcional), PostgreSQL/DuckDB, Streamlit.
- **Artefacto memorable esperado:** arquitectura event-driven completa (eventos, topics, consumidores,
  procesamiento, almacenamiento, alertas, gobierno y caso de IA).
- **Duración del programa:** 9 cursos × 4 semanas × 1 sesión semanal de 3 horas = 108 horas lectivas
  totales; cada curso, por tanto, son 4 sesiones de 3 horas (12 horas lectivas).

## Esquema de evaluación institucional adjunto (imagen/tabla)

| Rubro / Entregable | Porcentaje |
|---|---|
| i. Tarea No. 1 | 30% |
| ii. Tarea No. 2 | 30% |
| iii. Participación en clase | 20% |
| iv. Asistencia | 20% |
| **Total de puntos** | **100%** |

Verificación: 30 + 30 + 20 + 20 = 100% ✅ (se conserva tal cual, sin proponer cambios, salvo que el
usuario lo solicite).

## Otros datos entregados por el usuario en la conversación

- **Profesor:** [Nombre completo del profesor] — LinkedIn: [url del perfil].
- **Nivel del curso:** Avanzado (curso 7 de la ruta según nueva narrativa; en este ejemplo se usa el curso
  de streaming como ilustración de nivel intermedio).
- **Modalidad:** Virtual, sesiones sincrónicas.
- **Idioma:** Español, con lecturas técnicas en inglés.
- **Plantilla institucional:** no adjunta en este ejemplo → se usa `templates/syllabus-template.md`.

## Lo que el skill debe pedir si faltara (no aplica en este ejemplo porque ya está todo)

- Perfil de estudiantes (se puede inferir del programa: profesionales de datos/TI en ejecutivo, y
  presentarlo como propuesta a validar).
- Prerrequisitos explícitos (se pueden inferir de los cursos 1-4 previos del programa y presentarlo como
  propuesta a validar).
