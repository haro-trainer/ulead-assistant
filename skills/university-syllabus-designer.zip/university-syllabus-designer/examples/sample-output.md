# Ejemplo de salida — Extracto del sílabo resultante

> Extracto ilustrativo (no exhaustivo) de lo que el skill produce a partir de `sample-input.md`. En una
> ejecución real, este documento tendría las 26 secciones completas más la matriz de alineamiento como
> anexo.

---

## 1. Información general del curso

| Campo | Valor |
|---|---|
| Programa | Máster Ejecutivo en Big Data Analytics — Arquitecturas Avanzadas de Datos e IA |
| Curso | Streaming, Event-Driven Architecture y Analítica en Tiempo Real |
| Nivel | Intermedio |
| Modalidad | Virtual, sesiones sincrónicas |
| Duración | 4 semanas · 4 sesiones · 3 horas/sesión · 12 horas lectivas totales |
| Idioma | Español (lecturas técnicas en inglés) |

## 6. Descripción del curso

Este curso forma al estudiante en el diseño de soluciones de datos en tiempo real: arquitecturas orientadas
a eventos, plataformas de streaming (Kafka) y procesamiento continuo (Flink / Spark Structured Streaming).
El curso pasa de "explicar lo que ya pasó" (batch) a "reaccionar mientras está pasando" (streaming),
consolidando un caso de uso real-time AI-ready como artefacto final.

## 11. Resultados de aprendizaje

1. **Diferenciar** los patrones batch, micro-batch, streaming y event-driven, justificando cuándo cada uno
   es apropiado para un caso empresarial dado.
2. **Diseñar** un flujo de datos orientado a eventos para un dominio de negocio específico, especificando
   productores, topics y consumidores.
3. **Configurar** un pipeline de streaming con Kafka y Spark Structured Streaming o Flink que procese
   eventos con ventanas de tiempo y maneje datos tardíos.
4. **Evaluar** un caso de uso real-time (detección de fraude, IoT, clickstream, logística o
   recomendaciones) y justificar la arquitectura de reacción propuesta.

*(Verbos observables — evita "conocer Kafka" o "familiarizarse con streaming"; cada verbo se ancla a una
evidencia: un diagrama, una configuración funcional, un pipeline corriendo, un caso justificado por
escrito.)*

## 13. Contenidos por semana (extracto)

### Semana 1 — Pensar en eventos
Eventos de negocio, logs, telemetría, event storming, eventos vs. registros, arquitectura orientada a
eventos.
**Actividad:** taller de event storming sobre el caso omnicanal del programa (ver proyecto integrador).

### Semana 2 — Kafka y plataformas de streaming
Topics, particiones, offsets, producers, consumers, consumer groups, schema registry, retención, replay.
**Actividad:** laboratorio guiado con Kafka local o Confluent Cloud Trial.

*(continúa con semanas 3 y 4 según el documento fuente)*

## 17. Sistema de evaluación

| Rubro / Entregable | Porcentaje |
|---|---|
| i. Tarea No. 1 | 30% |
| ii. Tarea No. 2 | 30% |
| iii. Participación en clase | 20% |
| iv. Asistencia | 20% |
| **Total** | **100%** |

Verificación: 30 + 30 + 20 + 20 = **100%** ✅. Esquema institucional conservado sin cambios.

## Trazabilidad (cierre obligatorio de la entrega)

**Supuestos realizados:**
- Se infirió que el perfil de estudiantes corresponde a profesionales de datos/TI en formación ejecutiva,
  consistente con el resto del programa — pendiente de validación por el coordinador.
- Se infirieron prerrequisitos (cursos 1 a 4 de la ruta) a partir de la secuencia del programa.

**Información faltante:**
- No se recibió una plantilla institucional específica; este ejemplo usó la plantilla genérica de 26
  secciones del skill.
- No se recibió bibliografía institucional obligatoria; se sugiere completar con documentación oficial de
  Kafka, Flink y Spark Structured Streaming.

**Cambios propuestos:** ninguno respecto al esquema de evaluación institucional.

**Elementos que requieren aprobación académica:**
- Validar el perfil de estudiantes y prerrequisitos inferidos.
- Confirmar si se desea una plantilla institucional distinta a la genérica antes de la versión final.
