# Ejemplo de salida — Extracto del sílabo resultante (modelo de práctica aplicada)

> Extracto ilustrativo (no exhaustivo) de lo que el skill produce a partir de `sample-input.md`, ya
> alineado a la agenda de sesión vigente de 6 bloques y a la cadencia de proyecto práctico rotativo. En una ejecución real, este documento tendría las 26 secciones completas más la matriz de
> alineamiento como anexo.

---

## 1. Información general del curso

| Campo | Valor |
|---|---|
| Programa | Máster Ejecutivo en Big Data Analytics — Arquitecturas Avanzadas de Datos e IA |
| Curso | Streaming, Event-Driven Architecture y Analítica en Tiempo Real |
| Nivel | Intermedio |
| Modalidad | Virtual, sesiones sincrónicas |
| Duración | 4 semanas · 4 sesiones · 3 horas/sesión · 12 horas lectivas totales |
| Idioma | Español (lecturas técnicas en inglés) |
| Modelo pedagógico | Agenda de 6 bloques por sesión (Apertura, Desarrollo conceptual, Receso, Taller o caso práctico, Discusión y reflexión, Aplicación al contexto laboral) — ver `references/agenda-sesion-tipo.md` |

## 11. Resultados de aprendizaje

1. **Diferenciar** los patrones batch, micro-batch, streaming y event-driven, justificando cuándo cada uno
   es apropiado para un caso empresarial dado.
2. **Diseñar** un flujo de datos orientado a eventos para un dominio de negocio específico, especificando
   productores, topics y consumidores.
3. **Configurar** un pipeline de streaming con Kafka y Spark Structured Streaming o Flink que procese
   eventos con ventanas de tiempo y maneje datos tardíos.
4. **Evaluar** un caso de uso real-time (detección de fraude, IoT, clickstream, logística o
   recomendaciones) y justificar la arquitectura de reacción propuesta, conectándola con decisiones reales
   de su rol/industria.

## 13. Contenidos por sesión (agenda vigente de 6 bloques + cadencia de práctica aplicada)

### Sesión 1 — Pensar en eventos
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | Encuadre del curso y del proyecto integrador omnicanal |
| Desarrollo conceptual | 50 min | Eventos de negocio, logs, telemetría, event storming, eventos vs. registros |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | Taller introductorio de event storming (sin caso práctico entregable) |
| Discusión y reflexión | 30 min | Cómo se ven los eventos en la industria de cada estudiante |
| Aplicación al contexto laboral | 15 min | Identificar 2-3 eventos de negocio reales del rol del estudiante |

### Sesión 2 — Kafka y plataformas de streaming
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | Encuadre; no hay entregable previo (viene de Sesión 1) |
| Desarrollo conceptual | 50 min | Topics, particiones, offsets, producers, consumers, schema registry |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | **Abre Caso práctico aplicado 1** (25%): publicar un flujo de eventos de clickstream a un topic propio → **entrega al inicio de la Sesión 3** |
| Discusión y reflexión | 30 min | Dudas iniciales del caso, decisiones de diseño de topics |
| Aplicación al contexto laboral | 15 min | Qué eventos publicaría el estudiante en su propia organización |

### Sesión 3 — Procesamiento con Flink / Spark Structured Streaming
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | Revisión breve del Caso práctico aplicado 1 entregado |
| Desarrollo conceptual | 50 min | Ventanas, watermarks, datos tardíos, tolerancia a fallos |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | **Abre Caso práctico aplicado 2** (25%): pipeline con ventanas y manejo de datos tardíos → **entrega al inicio de la Sesión 4** |
| Discusión y reflexión | 30 min | Trade-offs de tamaño de ventana/watermark |
| Aplicación al contexto laboral | 15 min | Casos de datos tardíos en el contexto laboral del estudiante |

### Sesión 4 — Caso de uso real-time AI-ready
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | Revisión breve del Caso práctico aplicado 2 entregado |
| Desarrollo conceptual | 50 min | Patrones de reacción empresarial (fraude, IoT, clickstream, logística) |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | **Abre Caso práctico aplicado 3** (30%): arquitectura event-driven completa con caso de IA → **entrega según cierre del curso** |
| Discusión y reflexión | 30 min | Cierre del curso, síntesis de aprendizajes |
| Aplicación al contexto laboral | 15 min | Plan de aplicación del estudiante en su organización |

## 17. Sistema de evaluación

| Rubro / Entregable | Porcentaje |
|---|---|
| Caso práctico aplicado 1 | 25% |
| Caso práctico aplicado 2 | 25% |
| Caso práctico aplicado 3 | 30% |
| Asistencia | 20% |
| **Total** | **100%** |

Verificación: 25 + 25 + 30 + 20 = **100%** ✅. Esquema institucional vigente aplicado sin cambios.

## Trazabilidad (cierre obligatorio de la entrega)

**Supuestos realizados:**
- Se infirió que el perfil de estudiantes corresponde a profesionales de datos/TI en formación ejecutiva,
  consistente con el resto del programa — pendiente de validación por el coordinador.
- Se aplicó la agenda de sesión vigente de 6 bloques con los minutos exactos para una sesión de 3 horas
  (180 min); no se recibió una duración de sesión distinta, así que no fue necesario escalar
  proporcionalmente.
- Se asumió que "Caso práctico aplicado 3" cierra en la fecha de fin de curso, no al inicio de una quinta
  sesión inexistente (el curso solo tiene 4 sesiones) — pendiente de confirmar fecha exacta.

**Información faltante:**
- No se recibió una plantilla institucional específica; este ejemplo usó la plantilla genérica de 26
  secciones del skill.
- No se recibió bibliografía institucional obligatoria; se sugiere completar con documentación oficial de
  Kafka, Flink y Spark Structured Streaming.

**Cambios propuestos:** ninguno respecto al esquema de evaluación institucional vigente (ya coincide con el
modelo de práctica aplicada).

**Elementos que requieren aprobación académica:**
- Validar el perfil de estudiantes y prerrequisitos inferidos.
- Confirmar si el profesor desea ajustar la agenda estándar de 6 bloques para su grupo (p. ej. más tiempo
  de taller y menos de desarrollo conceptual).
- Confirmar la fecha de entrega del Caso práctico aplicado 3, al no existir una quinta sesión.
