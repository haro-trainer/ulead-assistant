---
name: university-syllabus-designer
description: Transforma contenido académico preliminar (PDF de un curso, notas de coordinador, esquema de evaluación en imagen/tabla) en un sílabo universitario completo, alineado a la plantilla institucional. Úsalo cuando un decano, director académico, coordinador, diseñador instruccional o profesor pida crear, actualizar, mejorar o "pasar en limpio" un sílabo, programa de curso, syllabus o carta descriptiva — incluso si solo dicen "tengo un PDF del curso" sin decir "sílabo". También úsalo para verificar que la evaluación sume 100%, redactar resultados de aprendizaje con Bloom, o construir una matriz de alineamiento curricular. No lo uses para diseñar tareas, quizzes o rúbricas de actividades individuales — eso es `course-assessment-and-activity-designer`, que toma el sílabo ya aprobado como insumo.
---

# Diseñador de Sílabos Universitarios

## Por qué existe este skill

Escribir un sílabo institucional bien hecho exige sostener muchas cosas a la vez: fidelidad a una plantilla,
coherencia pedagógica (Bloom, alineamiento constructivo), honestidad sobre lo que el profesor realmente
domina, y aritmética exacta en la evaluación. Es fácil que un borrador humano —o una generación de IA sin
disciplina— pierda alguno de estos hilos: infla resultados de aprendizaje con verbos vagos, cambia el
sistema de evaluación sin avisar, o inventa credenciales del profesor para sonar más impresionante.

Este skill existe para que ese trabajo se haga con rigor repetible: siempre pidiendo lo que falta en vez de
inventarlo, siempre verificando que el 100% cuadre, siempre dejando un rastro de qué se asumió y qué falta
aprobar. La idea no es reemplazar el criterio del profesor o del coordinador — es entregarles un borrador
tan sólido que su trabajo se reduzca a validar, ajustar y aprobar.

## Flujo de trabajo

Sigue estas fases en orden. No saltes a "generar el sílabo final" sin completar las fases 1 y 2 — son las que
evitan alucinaciones y evaluaciones que no cuadran.

### Fase 1 — Recolectar insumos

Insumos **obligatorios** (si falta alguno, pregúntalo antes de continuar; no lo inventes):

- Documento fuente del curso (PDF, texto, notas del coordinador).
- Plantilla o ejemplo institucional del sílabo (si el proyecto no tiene una adjunta, pregunta si existe un
  formato de la universidad; si definitivamente no existe, usa `templates/syllabus-template.md` como
  plantilla genérica y dilo explícitamente).
- Nombre del curso.
- Nombre completo del profesor.
- Perfil de LinkedIn del profesor (URL). Si no lo tiene o prefiere no compartirlo, continúa sin
  personalización basada en su trayectoria y anótalo en la lista de "información faltante" al final.

Insumos **opcionales** (complétalos si el usuario los da; si no, infiere con cautela desde el documento
fuente y marca la inferencia como "propuesta a validar", nunca como un hecho):

Nombre del programa, nivel del curso, modalidad, duración total, número y duración de sesiones, perfil de
estudiantes, prerrequisitos, herramientas/tecnologías, idioma, bibliografía institucional, políticas
académicas, restricciones adicionales.

Si el usuario ya adjuntó todo esto en la conversación (como suele pasar cuando comparten un PDF de
programa completo), no se lo vuelvas a preguntar — extráelo tú mismo y preséntaselo como resumen para
que lo confirme, en vez de hacer una batería de preguntas que él ya respondió en el archivo.

### Fase 2 — Analizar el perfil del profesor (si hay LinkedIn)

Usa `web_search`/`web_fetch` sobre el perfil público para identificar: experiencia profesional, experiencia
docente, especialización, certificaciones, publicaciones, herramientas dominadas, industrias.

Reglas estrictas:

- Usa esto solo para **adaptar ejemplos, proponer casos y personalizar experiencias de aprendizaje** — no
  para llenar espacios de la plantilla con biografía que no viene al caso.
- **Nunca inventes** experiencia, títulos o certificaciones que no estén respaldados por la fuente pública o
  por lo que el usuario mismo indicó. Si la búsqueda no encuentra nada verificable, dilo y sigue adelante sin
  ese enriquecimiento — no rellenes con generalidades que suenan plausibles.

### Fase 3 — Verificar el esquema de evaluación

Antes de escribir la sección de evaluación del sílabo:

1. Extrae los componentes de evaluación del documento/imagen institucional (rubros, porcentajes).
2. Suma los porcentajes. Si no da exactamente 100%, repórtalo de inmediato como un error a resolver con
   el usuario — no lo "arregles" silenciosamente ni sigas adelante como si no pasara nada.
3. Por defecto, **conserva el sistema de evaluación institucional tal cual**. Si tienes una razón pedagógica
   para proponer un cambio (por ejemplo, un curso con proyecto aplicado que no tiene ponderación de
   proyecto), preséntalo como una recomendación explícita — señala la diferencia, explica el motivo
   pedagógico, y pide aprobación antes de sustituir nada. Nunca reemplaces el esquema institucional sin
   que el usuario lo apruebe.

Usa `templates/evaluation-template.md` y `validators/syllabus-quality-checklist.md` como referencia de
formato y de chequeos.

### Fase 4 — Redactar resultados de aprendizaje y contenidos

- Verbos observables y medibles, alineados a la Taxonomía de Bloom, progresivos en complejidad según el
  nivel del curso (básico → recordar/comprender/aplicar; intermedio → analizar/aplicar; avanzado →
  evaluar/crear).
- Evita "conocer", "entender", "familiarizarse" salvo que vayan acompañados de una evidencia observable
  concreta (p. ej. "comprender los principios de X, evidenciado en un diagrama que justifique Y").
- Cada resultado de aprendizaje debe poder rastrearse hasta al menos una actividad y una evaluación —
  esto se documenta formalmente en la matriz de alineamiento (Fase 6).

### Fase 5 — Enriquecer con experiencias de aprendizaje activo

Usa `web_search` cuando sea necesario para actualizar tecnologías, validar tendencias vigentes, evitar
herramientas obsoletas, y encontrar bibliografía reciente o casos reales — prioriza documentación oficial,
papers académicos, universidades reconocidas y estándares internacionales. Cita fuente y fecha de consulta
cuando uses contenido externo.

Propón experiencias (estudios de caso, laboratorios, simulaciones, debates, retos, proyectos aplicados,
etc.) calibradas a: nivel de los estudiantes, duración del curso, modalidad, herramientas disponibles,
aplicabilidad profesional y carga de trabajo razonable. No sobrecargues un curso corto con expectativas de
programa largo.

### Fase 6 — Construir la matriz de alineamiento

Usa `templates/alignment-matrix-template.md`. Conecta resultados de aprendizaje ↔ contenidos ↔
actividades ↔ evidencias ↔ evaluaciones ↔ criterios de desempeño. Revisa: progresión de dificultad,
coherencia entre sesiones, ausencia de duplicaciones, balance teoría/práctica, carga académica realista,
pertinencia profesional.

### Fase 7 — Control de calidad antes de entregar

Recorre `validators/syllabus-quality-checklist.md` completo antes de dar por terminado el sílabo. No te
saltes esto aunque el resultado "se vea bien" — es la red de seguridad contra inconsistencias silenciosas
(porcentajes que no cuadran, verbos vagos, secciones de la plantilla institucional omitidas, información
inventada).

### Fase 8 — Entregar con trazabilidad

Cierra siempre con una sección breve de:

- **Supuestos realizados** (qué inferiste y de dónde).
- **Información faltante** (qué no pudiste completar y necesitas del usuario).
- **Cambios propuestos** (cualquier desviación de la plantilla o evaluación institucional).
- **Elementos que requieren aprobación académica** antes de publicar el sílabo.

Esto no es un disclaimer decorativo — es lo que permite que un coordinador confíe en el documento sin
tener que releer cada línea buscando errores escondidos.

## Estructura del sílabo generado

Usa `templates/syllabus-template.md` como estructura base (26 secciones, ver el archivo), pero **la
plantilla institucional adjunta al proyecto siempre tiene prioridad** sobre esta estructura genérica si hay
conflicto de orden, nombres de sección o formato exigido por la universidad.

## Artefactos que puedes producir

Según lo que pida el usuario, puedes generar por separado o en conjunto:

- El sílabo completo (Markdown y, si lo piden, `.docx` — consulta la skill `docx` para ese formato).
- La matriz de alineamiento curricular.
- El cronograma.
- La tabla de evaluación verificada.
- La bibliografía organizada.
- Una guía de implementación para quien vaya a dictar el curso.

Cuando el resultado incluya varios archivos, organízalos con nombres claros, y si son 3 o más archivos
entrégalos como un ZIP descargable (ver `README.md` de este skill para la convención de nombres).

## Archivos de referencia

- `templates/syllabus-template.md` — plantilla genérica de 26 secciones (usar si no hay plantilla
  institucional adjunta al proyecto).
- `templates/alignment-matrix-template.md` — formato de la matriz de alineamiento.
- `templates/evaluation-template.md` — formato de tabla de evaluación y su verificación aritmética.
- `prompts/syllabus-generation-prompt.md` — prompt de referencia para la redacción completa del sílabo.
- `prompts/quality-review-prompt.md` — prompt de referencia para la auto-revisión de calidad (Fase 7).
- `validators/syllabus-quality-checklist.md` — checklist completo de control de calidad.
- `references/institutional-requirements.md` — cómo interpretar y priorizar una plantilla institucional real
  cuando el usuario adjunta una.
- `examples/sample-input.md` y `examples/sample-output.md` — ejemplo funcional de extremo a extremo.

## Relación con `course-assessment-and-activity-designer`

Este skill se detiene en el nivel curricular: define **qué** actividades y evaluaciones tendrá el curso, sus
pesos y su propósito pedagógico, pero no desarrolla cada tarea con instrucciones completas, rúbrica
detallada y solución modelo. Cuando el usuario pida diseñar una tarea, laboratorio, quiz, proyecto o
rúbrica específica a partir de un sílabo ya aprobado, indícale que existe (o invoca, si está disponible) el
skill `course-assessment-and-activity-designer`, que toma el sílabo como entrada y produce esos artefactos
detallados. No dupliques ese trabajo dentro de este skill.
