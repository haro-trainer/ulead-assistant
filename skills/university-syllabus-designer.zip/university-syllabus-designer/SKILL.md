---
name: university-syllabus-designer
description: Transforma contenido académico preliminar (PDF de un curso, notas de coordinador, esquema de evaluación en imagen/tabla) en un sílabo universitario completo, alineado a la plantilla institucional. Úsalo cuando un decano, director académico, coordinador, diseñador instruccional o profesor pida crear, actualizar, mejorar o "pasar en limpio" un sílabo, programa de curso, syllabus o carta descriptiva — incluso si solo dicen "tengo un PDF del curso" sin decir "sílabo". También úsalo para verificar que la evaluación sume 100%, redactar resultados de aprendizaje con Bloom, o construir una matriz de alineamiento curricular. No lo uses para diseñar tareas, quizzes o rúbricas de actividades individuales — eso es `course-assessment-and-activity-designer`, que toma el sílabo ya aprobado como insumo.
---

# Diseñador de Sílabos Universitarios

## Por qué existe este skill

Escribir un sílabo institucional bien hecho exige sostener muchas cosas a la vez: fidelidad a una plantilla,
coherencia pedagógica (Bloom, alineamiento constructivo), honestidad sobre lo que el profesor realmente
domina, y aritmética exacta en la evaluación. Es fácil que un borrador humano —o una generación de IA sin
disciplina— pierda alguno de estos hilos: infla resultados de aprendizaje con verbos vagos, cambia el
sistema de evaluación sin avisar, o inventa credenciales del profesor para sonar más impresionante.

Este skill existe para que ese trabajo se haga con rigor repetible: siempre pidiendo lo que falta en vez de
inventarlo, siempre verificando que el 100% cuadre, siempre dejando un rastro de qué se asumió y qué falta
aprobar. La idea no es reemplazar el criterio del profesor o del coordinador — es entregarles un borrador
tan sólido que su trabajo se reduzca a validar, ajustar y aprobar.

## Flujo de trabajo

Sigue estas fases en orden. No saltes a "generar el sílabo final" sin completar las fases 1 y 2 — son las que
evitan alucinaciones y evaluaciones que no cuadran.

### Fase 1 — Recolectar insumos

Insumos **obligatorios** (si falta alguno, pregúntalo antes de continuar; no lo inventes):

- Documento fuente del curso (PDF, texto, notas del coordinador).
- Plantilla o ejemplo institucional del sílabo (si el proyecto no tiene una adjunta, pregunta si existe un
  formato de la universidad; si definitivamente no existe, usa `templates/syllabus-template.md` como
  plantilla genérica y dilo explícitamente).
- Nombre del curso.
- Nombre completo del profesor.
- Perfil de LinkedIn del profesor (URL). Si no lo tiene o prefiere no compartirlo, continúa sin
  personalización basada en su trayectoria y anótalo en la lista de "información faltante" al final.

Insumos **opcionales** (complétalos si el usuario los da; si no, infiere con cautela desde el documento
fuente y marca la inferencia como "propuesta a validar", nunca como un hecho):

Nombre del programa, nivel del curso, modalidad, duración total, número y duración de sesiones, perfil de
estudiantes, prerrequisitos, herramientas/tecnologías, idioma, bibliografía institucional, políticas
académicas, restricciones adicionales.

Si el usuario ya adjuntó todo esto en la conversación (como suele pasar cuando comparten un PDF de
programa completo), no se lo vuelvas a preguntar — extráelo tú mismo y preséntaselo como resumen para
que lo confirme, en vez de hacer una batería de preguntas que él ya respondió en el archivo.

### Fase 2 — Analizar el perfil del profesor (si hay LinkedIn)

Usa `web_search`/`web_fetch` sobre el perfil público para identificar: experiencia profesional, experiencia
docente, especialización, certificaciones, publicaciones, herramientas dominadas, industrias.

Reglas estrictas:

- Usa esto solo para **adaptar ejemplos, proponer casos y personalizar experiencias de aprendizaje** — no
  para llenar espacios de la plantilla con biografía que no viene al caso.
- **Nunca inventes** experiencia, títulos o certificaciones que no estén respaldados por la fuente pública o
  por lo que el usuario mismo indicó. Si la búsqueda no encuentra nada verificable, dilo y sigue adelante sin
  ese enriquecimiento — no rellenes con generalidades que suenan plausibles.

### Fase 3 — Verificar el esquema de evaluación

Antes de escribir la sección de evaluación del sílabo:

1. Extrae los componentes de evaluación del documento/imagen institucional (rubros, porcentajes).
2. Suma los porcentajes. Si no da exactamente 100%, repórtalo de inmediato como un error a resolver con
   el usuario — no lo "arregles" silenciosamente ni sigas adelante como si no pasara nada.
3. **El esquema institucional vigente por defecto es el de casos prácticos aplicados con cadencia
   rotativa** (ver `references/modelo-practica-aplicada.md`, sección 3): Caso práctico aplicado 1 (25%),
   Caso práctico aplicado 2 (25%), Caso práctico aplicado 3 (30%) y Asistencia (20%) = 100%. Aplícalo por
   defecto en cursos nuevos de 4 sesiones. Si el documento fuente trae un esquema distinto (p. ej. el
   esquema anterior de Tarea 1/Tarea 2/Participación/Asistencia), no lo sobrescribas en silencio: repórtalo
   como una diferencia frente al esquema vigente, explica el motivo pedagógico del cambio, y pide
   aprobación antes de reemplazarlo — la misma disciplina aplica en cualquier dirección: nunca reemplaces
   un esquema por otro sin que el usuario lo apruebe explícitamente.
4. Si el curso tiene una cantidad de sesiones distinta a 4, adapta el número de casos prácticos y sus pesos
   siguiendo las reglas de `references/modelo-practica-aplicada.md` (sección 3), y márcalo como propuesta a
   validar.

Usa `templates/evaluation-template.md` y `validators/syllabus-quality-checklist.md` como referencia de
formato y de chequeos.

### Fase 4 — Redactar resultados de aprendizaje y contenidos

- Verbos observables y medibles, alineados a la Taxonomía de Bloom, progresivos en complejidad según el
  nivel del curso (básico → recordar/comprender/aplicar; intermedio → analizar/aplicar; avanzado →
  evaluar/crear).
- Evita "conocer", "entender", "familiarizarse" salvo que vayan acompañados de una evidencia observable
  concreta (p. ej. "comprender los principios de X, evidenciado en un diagrama que justifique Y").
- Cada resultado de aprendizaje debe poder rastrearse hasta al menos una actividad y una evaluación —
  esto se documenta formalmente en la matriz de alineamiento (Fase 6).

### Fase 4.5 — Aplicar la agenda de sesión vigente (6 bloques) y la cadencia de proyecto rotativo

Todo curso generado por este skill sigue por defecto la agenda de sesión descrita en
`references/agenda-sesion-tipo.md` — 6 bloques con nombre y minutos exactos, no una distribución genérica
de porcentajes. En esta fase:

1. Estructura cada sesión con estos 6 bloques, en este orden, con los minutos indicados para una sesión de
   3 horas (o escalados proporcionalmente si la sesión dura distinto, ver la referencia):

   | Bloque | Tiempo (sesión de 3h) |
   |---|---|
   | Apertura y conexión | 10 min |
   | Desarrollo conceptual | 50 min |
   | Receso | 15 min |
   | Taller o caso práctico | 60 min |
   | Discusión y reflexión | 30 min |
   | Aplicación al contexto laboral | 15 min |

2. El bloque **"Taller o caso práctico"** es, exactamente, el presupuesto de tiempo que
   `applied-case-designer` debe usar para diseñar la parte en vivo del caso práctico de esa sesión — no un
   porcentaje aproximado de la sesión completa. Indícalo explícitamente al construir los contenidos de cada
   sesión (Fase 4) para que quien desarrolle el caso práctico tenga el dato exacto.
3. A partir de la **sesión 2**, el bloque de Apertura y conexión también sirve para recibir/revisar
   brevemente el caso práctico entregado al inicio de esa sesión, y el bloque de Taller o caso práctico abre
   el nuevo caso — el estudiante lo completa de forma autónoma y lo entrega **a más tardar al inicio de la
   sesión siguiente**. La sesión 1 no abre caso práctico (se dedica a fundamentos, sin entregable).
4. Refleja esta cadena explícitamente en los contenidos por sesión (Fase 4) y en el cronograma (Fase 6/7):
   cada entregable debe indicar en qué sesión se abrió (en su bloque de Taller o caso práctico) y en cuál se
   entrega (al inicio de la sesión siguiente).
5. Si el documento fuente no sigue esta agenda o esta cadencia, no las fuerces sin avisar: señala el ajuste
   como una mejora propuesta frente al modelo vigente y explica el motivo, salvo que el usuario ya haya
   indicado que use este modelo (en cuyo caso aplícalo directamente, como es el caso por defecto).

### Fase 5 — Enriquecer con experiencias de aprendizaje activo

Usa `web_search` cuando sea necesario para actualizar tecnologías, validar tendencias vigentes, evitar
herramientas obsoletas, y encontrar bibliografía reciente o casos reales — prioriza documentación oficial,
papers académicos, universidades reconocidas y estándares internacionales. Cita fuente y fecha de consulta
cuando uses contenido externo.

Propón experiencias (estudios de caso, laboratorios, simulaciones, debates, retos, proyectos aplicados,
etc.) calibradas a: nivel de los estudiantes, duración del curso, modalidad, herramientas disponibles,
aplicabilidad profesional y carga de trabajo razonable. No sobrecargues un curso corto con expectativas de
programa largo.

### Fase 6 — Construir la matriz de alineamiento

Usa `templates/alignment-matrix-template.md`. Conecta resultados de aprendizaje ↔ contenidos ↔
actividades ↔ evidencias ↔ evaluaciones ↔ criterios de desempeño. Revisa: progresión de dificultad,
coherencia entre sesiones, ausencia de duplicaciones, balance teoría/práctica, carga académica realista,
pertinencia profesional.

### Fase 7 — Control de calidad antes de entregar

Recorre `validators/syllabus-quality-checklist.md` completo antes de dar por terminado el sílabo. No te
saltes esto aunque el resultado "se vea bien" — es la red de seguridad contra inconsistencias silenciosas
(porcentajes que no cuadran, verbos vagos, secciones de la plantilla institucional omitidas, información
inventada).

### Fase 8 — Entregar con trazabilidad

Cierra siempre con una sección breve de:

- **Supuestos realizados** (qué inferiste y de dónde).
- **Información faltante** (qué no pudiste completar y necesitas del usuario).
- **Cambios propuestos** (cualquier desviación de la plantilla o evaluación institucional).
- **Elementos que requieren aprobación académica** antes de publicar el sílabo.

Esto no es un disclaimer decorativo — es lo que permite que un coordinador confíe en el documento sin
tener que releer cada línea buscando errores escondidos.

## Estructura del sílabo generado

Usa `templates/syllabus-template.md` como estructura base (26 secciones, ver el archivo), pero **la
plantilla institucional adjunta al proyecto siempre tiene prioridad** sobre esta estructura genérica si hay
conflicto de orden, nombres de sección o formato exigido por la universidad.

## Artefactos que puedes producir

Según lo que pida el usuario, puedes generar por separado o en conjunto:

- El sílabo completo (Markdown y, si lo piden, `.docx` — consulta la skill `docx` para ese formato).
- La matriz de alineamiento curricular.
- El cronograma.
- La tabla de evaluación verificada.
- La bibliografía organizada.
- Una guía de implementación para quien vaya a dictar el curso.

Cuando el resultado incluya varios archivos, organízalos con nombres claros, y si son 3 o más archivos
entrégalos como un ZIP descargable (ver `README.md` de este skill para la convención de nombres).

## Archivos de referencia

- `templates/syllabus-template.md` — plantilla genérica de 26 secciones (usar si no hay plantilla
  institucional adjunta al proyecto).
- `templates/alignment-matrix-template.md` — formato de la matriz de alineamiento.
- `templates/evaluation-template.md` — formato de tabla de evaluación y su verificación aritmética.
- `prompts/syllabus-generation-prompt.md` — prompt de referencia para la redacción completa del sílabo.
- `prompts/quality-review-prompt.md` — prompt de referencia para la auto-revisión de calidad (Fase 7).
- `validators/syllabus-quality-checklist.md` — checklist completo de control de calidad.
- `references/institutional-requirements.md` — cómo interpretar y priorizar una plantilla institucional real
  cuando el usuario adjunta una.
- `references/modelo-practica-aplicada.md` — modelo pedagógico vigente por defecto: cadencia de proyecto
  práctico rotativo desde la sesión 2, y esquema de evaluación institucional de casos prácticos aplicados.
- `references/agenda-sesion-tipo.md` — agenda de sesión vigente de 6 bloques (Apertura, Desarrollo
  conceptual, Receso, Taller o caso práctico, Discusión y reflexión, Aplicación al contexto laboral) con
  minutos exactos para sesiones de 3 horas y reglas de escalamiento a otras duraciones.
- `examples/sample-input.md` y `examples/sample-output.md` — ejemplo funcional de extremo a extremo.

## Relación con los skills complementarios

Este skill se detiene en el nivel curricular: define **qué** actividades y evaluaciones tendrá el curso,
sus pesos y su propósito pedagógico, pero no desarrolla cada actividad en detalle. Cuando el usuario pida
desarrollar una evaluación específica a partir de un sílabo ya aprobado, dirígelo al skill que corresponda:

- **`applied-case-designer`** — cuando la actividad sigue el patrón de "Caso práctico aplicado" del modelo
  de práctica aplicada: se abre en el taller de una sesión y se entrega al inicio de la siguiente (ver
  `references/modelo-practica-aplicada.md`). Este es el caso más común bajo el esquema de evaluación
  vigente.
- **`course-assessment-and-activity-designer`** — para cualquier otra evaluación que no siga ese patrón de
  dos partes (quizzes, exámenes, proyectos de cierre de módulo, rúbricas generales).

No dupliques ese trabajo dentro de este skill.
