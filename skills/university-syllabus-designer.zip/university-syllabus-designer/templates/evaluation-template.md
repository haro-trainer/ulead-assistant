# Plantilla — Sistema de evaluación y su verificación

## Esquema institucional vigente por defecto (cursos de 4 sesiones)

Ver `references/modelo-practica-aplicada.md` sección 3 para el detalle y las reglas de adaptación a cursos
con un número distinto de sesiones.

| # | Rubro / Entregable | Porcentaje | Momento | Individual/Grupal |
|---|---|---|---|---|
| 1 | Caso práctico aplicado 1 | 25% | Abre en Sesión 2, entrega al inicio de Sesión 3 | [definir] |
| 2 | Caso práctico aplicado 2 | 25% | Abre en Sesión 3, entrega al inicio de Sesión 4 | [definir] |
| 3 | Caso práctico aplicado 3 | 30% | Abre en Sesión 4, entrega según cierre del curso | [definir] |
| 4 | Asistencia | 20% | Transversal a todas las sesiones | — |
| **Total** | | **100%** | | |

Verificación: 25 + 25 + 30 + 20 = **100%** ✅.

## Tabla de evaluación (genérica, para cursos con esquema institucional distinto al vigente)

| # | Rubro / Entregable | Porcentaje | Momento (semana) | Individual/Grupal |
|---|---|---|---|---|
| i | [ej. Caso práctico aplicado 1] | [%] | | |
| ii | [ej. Caso práctico aplicado 2] | [%] | | |
| iii | [ej. Caso práctico aplicado 3] | [%] | | |
| iv | [ej. Asistencia] | [%] | | |
| **Total** | | **100%** | | |

## Verificación obligatoria

Antes de dar la tabla por válida, muestra la suma explícita:

```
[%] + [%] + [%] + [%] + ... = [total]%
```

- Si `total == 100`: la evaluación está verificada, procede a usarla en el sílabo.
- Si `total != 100`: **detente** y repórtalo al usuario con el detalle exacto de la discrepancia (p. ej.
  "los rubros suman 95%, faltan 5 puntos porcentuales sin asignar") antes de continuar con el resto del
  sílabo.

## Si el sílabo propone cambios al esquema institucional

Documenta cada cambio con esta estructura, y no lo apliques hasta tener aprobación explícita:

| Rubro original | % original | Rubro propuesto | % propuesto | Razón pedagógica | Estado |
|---|---|---|---|---|---|
| [...] | [...] | [...] | [...] | [por qué se recomienda el cambio] | Pendiente de aprobación |

Por defecto, si el usuario no pide explícitamente modificar la evaluación, **el esquema institucional se
conserva sin cambios** en el sílabo final.
