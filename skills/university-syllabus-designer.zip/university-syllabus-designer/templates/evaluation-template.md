# Plantilla — Sistema de evaluación y su verificación

## Tabla de evaluación

| # | Rubro / Entregable | Porcentaje | Momento (semana) | Individual/Grupal |
|---|---|---|---|---|
| i | [ej. Tarea No. 1] | [%] | | |
| ii | [ej. Tarea No. 2] | [%] | | |
| iii | [ej. Participación en clase] | [%] | | |
| iv | [ej. Asistencia] | [%] | | |
| **Total** | | **100%** | | |

## Verificación obligatoria

Antes de dar la tabla por válida, muestra la suma explícita:

```
[%] + [%] + [%] + [%] + ... = [total]%
```

- Si `total == 100`: la evaluación está verificada, procede a usarla en el sílabo.
- Si `total != 100`: **detente** y repórtalo al usuario con el detalle exacto de la discrepancia (p. ej.
  "los rubros suman 95%, faltan 5 puntos porcentuales sin asignar") antes de continuar con el resto del
  sílabo.

## Si el sílabo propone cambios al esquema institucional

Documenta cada cambio con esta estructura, y no lo apliques hasta tener aprobación explícita:

| Rubro original | % original | Rubro propuesto | % propuesto | Razón pedagógica | Estado |
|---|---|---|---|---|---|
| [...] | [...] | [...] | [...] | [por qué se recomienda el cambio] | Pendiente de aprobación |

Por defecto, si el usuario no pide explícitamente modificar la evaluación, **el esquema institucional se
conserva sin cambios** en el sílabo final.
