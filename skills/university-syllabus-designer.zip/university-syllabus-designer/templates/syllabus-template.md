# Plantilla genérica de sílabo (26 secciones)

Usar solo si el proyecto **no** tiene una plantilla institucional adjunta. Si la hay, esa plantilla manda
sobre esta estructura: adapta el orden, nombres de sección y formato exigidos por la universidad, y usa
esta plantilla únicamente como lista de verificación de contenido mínimo esperado.

```markdown
# [Nombre del curso]

## 1. Información general del curso
Programa | Curso | Código | Créditos | Nivel | Modalidad | Duración | Idioma

## 2. Nombre del programa
[...]

## 3. Nombre del curso
[...]

## 4. Profesor
Nombre completo | Perfil resumido (verificado) | Contacto institucional

## 5. Duración y modalidad
Semanas | Sesiones | Horas por sesión | Horas totales | Modalidad

## 6. Descripción del curso
[Párrafo: qué es, para quién, qué resuelve]

## 7. Justificación
[Por qué este curso es relevante para el perfil de salida y el mercado]

## 8. Prerrequisitos
[...]

## 9. Perfil de ingreso
[Conocimientos/habilidades esperadas al iniciar]

## 10. Competencias del curso
[Competencias generales que desarrolla]

## 11. Resultados de aprendizaje
1. [Verbo Bloom + objeto + condición/evidencia]
2. ...

## 12. Relación con el perfil de salida del programa
[Tabla o lista: qué competencia del programa fortalece este curso]

## 13. Contenidos por unidad/semana/sesión
*(Sigue la agenda de sesión vigente de 6 bloques — ver `references/agenda-sesion-tipo.md` — y la cadencia
de proyecto práctico rotativo: desde la sesión 2, el bloque "Taller o caso práctico" abre un caso que se
entrega al inicio de la sesión siguiente)*

### Sesión 1 — [Título]
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | [encuadre del curso] |
| Desarrollo conceptual | 50 min | [fundamentos] |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | [taller introductorio, sin caso práctico entregable] |
| Discusión y reflexión | 30 min | [debate sobre fundamentos] |
| Aplicación al contexto laboral | 15 min | [conexión con la industria del estudiante] |

### Sesión 2 — [Título]
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | [encuadre; no hay entregable previo] |
| Desarrollo conceptual | 50 min | [temas] |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | **Abre Caso práctico aplicado 1** → entrega al inicio de Sesión 3 |
| Discusión y reflexión | 30 min | [debate + dudas iniciales del caso] |
| Aplicación al contexto laboral | 15 min | [conexión con la industria] |

### Sesión 3 — [Título]
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | Revisión breve del Caso práctico aplicado 1 entregado |
| Desarrollo conceptual | 50 min | [temas] |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | **Abre Caso práctico aplicado 2** → entrega al inicio de Sesión 4 |
| Discusión y reflexión | 30 min | [debate + dudas iniciales del caso] |
| Aplicación al contexto laboral | 15 min | [conexión con la industria] |

### Sesión 4 — [Título]
| Bloque | Tiempo | Contenido |
|---|---|---|
| Apertura y conexión | 10 min | Revisión breve del Caso práctico aplicado 2 entregado |
| Desarrollo conceptual | 50 min | [temas] |
| Receso | 15 min | — |
| Taller o caso práctico | 60 min | **Abre Caso práctico aplicado 3** → entrega según cierre del curso |
| Discusión y reflexión | 30 min | [debate + cierre del curso] |
| Aplicación al contexto laboral | 15 min | [conexión con la industria] |
...

## 14. Metodología de enseñanza
Cada sesión sigue la agenda vigente de 6 bloques (Apertura y conexión, Desarrollo conceptual, Receso, Taller
o caso práctico, Discusión y reflexión, Aplicación al contexto laboral — ver
`references/agenda-sesion-tipo.md`), con espacio explícito para discusión, reflexión y conexión con el
contexto laboral del estudiante. [Detallar aquí cualquier particularidad del curso.]

## 15. Estrategias de aprendizaje activo
[Casos, laboratorios, simulaciones, debates, retos, proyectos...]
Cadencia de proyecto práctico rotativo: a partir de la sesión 2, el bloque "Taller o caso práctico" de cada
sesión abre un caso práctico aplicado que el estudiante empieza a construir en clase y completa de forma
autónoma, entregándolo al inicio de la sesión siguiente (ver `references/modelo-practica-aplicada.md`).

## 16. Herramientas y recursos
[Software, plataformas, datasets, cuentas free-tier, etc.]

## 17. Sistema de evaluación
| Rubro | % |
|---|---|
| ... | ... |
| **Total** | **100%** |

## 18. Actividades y entregables
[Tabla: actividad, semana, tipo, entregable]

## 19. Cronograma
| Semana | Tema | Actividad | Entregable |
|---|---|---|---|

## 20. Rúbricas o criterios generales
[Criterios de desempeño de alto nivel; el detalle fino va en el skill de actividades]

## 21. Bibliografía obligatoria y recomendada
[Formato institucional de citación]

## 22. Recursos digitales
[Enlaces, repositorios, plataformas]

## 23. Políticas de uso responsable de IA
[Qué se permite, qué se debe declarar, qué no se permite]

## 24. Integridad académica
[Política institucional o estándar]

## 25. Requisitos de participación y aprobación
[Asistencia mínima, nota mínima, condiciones de aprobación]

## 26. Evidencias de alineamiento curricular
[Referencia a la matriz de alineamiento adjunta]

## Historial de versión
| Versión | Fecha | Autor/fuente | Cambios |
|---|---|---|---|
```
