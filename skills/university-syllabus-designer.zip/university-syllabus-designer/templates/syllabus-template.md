# Plantilla genérica de sílabo (26 secciones)

Usar solo si el proyecto **no** tiene una plantilla institucional adjunta. Si la hay, esa plantilla manda
sobre esta estructura: adapta el orden, nombres de sección y formato exigidos por la universidad, y usa
esta plantilla únicamente como lista de verificación de contenido mínimo esperado.

```markdown
# [Nombre del curso]

## 1. Información general del curso
Programa | Curso | Código | Créditos | Nivel | Modalidad | Duración | Idioma

## 2. Nombre del programa
[...]

## 3. Nombre del curso
[...]

## 4. Profesor
Nombre completo | Perfil resumido (verificado) | Contacto institucional

## 5. Duración y modalidad
Semanas | Sesiones | Horas por sesión | Horas totales | Modalidad

## 6. Descripción del curso
[Párrafo: qué es, para quién, qué resuelve]

## 7. Justificación
[Por qué este curso es relevante para el perfil de salida y el mercado]

## 8. Prerrequisitos
[...]

## 9. Perfil de ingreso
[Conocimientos/habilidades esperadas al iniciar]

## 10. Competencias del curso
[Competencias generales que desarrolla]

## 11. Resultados de aprendizaje
1. [Verbo Bloom + objeto + condición/evidencia]
2. ...

## 12. Relación con el perfil de salida del programa
[Tabla o lista: qué competencia del programa fortalece este curso]

## 13. Contenidos por unidad/semana/sesión
### Semana 1 — [Título]
- Temas
- Lecturas
### Semana 2 — [Título]
...

## 14. Metodología de enseñanza
[Enfoque general: magistral, invertida, basada en proyectos, etc.]

## 15. Estrategias de aprendizaje activo
[Casos, laboratorios, simulaciones, debates, retos, proyectos...]

## 16. Herramientas y recursos
[Software, plataformas, datasets, cuentas free-tier, etc.]

## 17. Sistema de evaluación
| Rubro | % |
|---|---|
| ... | ... |
| **Total** | **100%** |

## 18. Actividades y entregables
[Tabla: actividad, semana, tipo, entregable]

## 19. Cronograma
| Semana | Tema | Actividad | Entregable |
|---|---|---|---|

## 20. Rúbricas o criterios generales
[Criterios de desempeño de alto nivel; el detalle fino va en el skill de actividades]

## 21. Bibliografía obligatoria y recomendada
[Formato institucional de citación]

## 22. Recursos digitales
[Enlaces, repositorios, plataformas]

## 23. Políticas de uso responsable de IA
[Qué se permite, qué se debe declarar, qué no se permite]

## 24. Integridad académica
[Política institucional o estándar]

## 25. Requisitos de participación y aprobación
[Asistencia mínima, nota mínima, condiciones de aprobación]

## 26. Evidencias de alineamiento curricular
[Referencia a la matriz de alineamiento adjunta]

## Historial de versión
| Versión | Fecha | Autor/fuente | Cambios |
|---|---|---|---|
```
