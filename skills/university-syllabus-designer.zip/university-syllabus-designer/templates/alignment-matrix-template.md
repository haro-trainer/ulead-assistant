# Plantilla — Matriz de alineamiento curricular

Propósito: hacer visible, en una sola tabla, que cada resultado de aprendizaje tiene contenido que lo
desarrolla, una actividad que lo practica, una evidencia que lo demuestra y una evaluación que lo mide.

| Resultado de aprendizaje | Semana/Unidad | Contenido asociado | Actividad de aprendizaje | Evidencia | Instrumento de evaluación | Criterio de desempeño (resumen) |
|---|---|---|---|---|---|---|
| RA1: [verbo Bloom + objeto] | Semana 1-2 | [tema] | [caso/laboratorio/debate] | [entregable observable] | [rúbrica/examen/proyecto, % que representa] | [qué distingue un desempeño logrado de uno no logrado] |
| RA2: ... | | | | | | |

## Nota sobre el modelo de práctica aplicada

Cuando el curso siga el modelo vigente (`references/modelo-practica-aplicada.md`), identifica en la columna
"Instrumento de evaluación" cuál caso práctico aplicado (1, 2 o 3) corresponde a cada resultado de
aprendizaje, y en qué sesión se abrió vs. en cuál se entregó — esto hace visible que la matriz respeta la
cadencia rotativa, no solo los pesos.

## Chequeos obligatorios después de llenar la tabla

- **Cobertura:** todo resultado de aprendizaje tiene al menos una fila; ningún resultado queda sin
  actividad o sin evaluación asociada.
- **Progresión:** ordenados por semana, los verbos Bloom no deberían retroceder en complejidad sin razón
  (p. ej. pasar de "analizar" en la semana 3 a "recordar" en la semana 6 es una señal de alerta, salvo que
  se trate de un repaso intencional).
- **No duplicación:** dos filas no deberían apuntar al mismo contenido y actividad exactos sin diferenciar
  el nivel de profundidad.
- **Balance:** revisa que no todas las evidencias sean del mismo tipo (p. ej. todo exámenes, o todo
  proyectos) — el balance entre teoría y práctica debe reflejarse aquí.
- **Trazabilidad a la evaluación:** la suma de los pesos de instrumentos de evaluación listados en esta
  matriz debe coincidir con la tabla de `templates/evaluation-template.md`.
