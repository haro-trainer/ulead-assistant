# Checklist de control de calidad — Sílabo universitario

Recorre este checklist completo antes de entregar el sílabo como versión final. Marca cada ítem; si algo
falla, corrígelo o inclúyelo en la sección de trazabilidad de la entrega — nunca lo omitas en silencio.

## Cumplimiento de plantilla
- [ ] Todas las secciones exigidas por la plantilla institucional (o las 26 de la plantilla genérica) están
      presentes y en el orden correcto.
- [ ] El formato (tablas, encabezados, numeración) respeta el estilo institucional si existe uno.

## Evaluación
- [ ] Los porcentajes de evaluación suman exactamente 100% (suma mostrada explícitamente).
- [ ] Cualquier diferencia respecto al esquema institucional está señalada, justificada pedagógicamente y
      marcada como pendiente de aprobación.

## Resultados de aprendizaje
- [ ] Todos usan verbos observables y medibles (Taxonomía de Bloom).
- [ ] Ningún verbo ambiguo ("conocer", "entender", "familiarizarse") aparece sin evidencia observable
      asociada.
- [ ] La complejidad progresa de forma coherente con el nivel del curso (básico/intermedio/avanzado).

## Agenda de sesión (6 bloques) y cadencia de proyecto rotativo
- [ ] Cada sesión sigue los 6 bloques de `references/agenda-sesion-tipo.md` (Apertura y conexión,
      Desarrollo conceptual, Receso, Taller o caso práctico, Discusión y reflexión, Aplicación al contexto
      laboral), con minutos exactos (o escalados proporcionalmente si la sesión no dura 3 horas) que sumen
      la duración total de la sesión.
- [ ] El tiempo del bloque "Taller o caso práctico" está indicado explícitamente, ya que es el presupuesto
      exacto que usará `applied-case-designer` para el caso práctico de esa sesión.
- [ ] A partir de la sesión 2, el bloque "Taller o caso práctico" abre un caso práctico aplicado nuevo, y el
      cronograma indica claramente que se entrega al inicio de la sesión siguiente (no en la misma sesión).
- [ ] La sesión 1 no tiene un caso práctico entregable (se dedica a fundamentos), salvo que el usuario haya
      indicado explícitamente lo contrario.
- [ ] Si el curso tiene una cantidad de sesiones distinta a 4, el número de casos prácticos y sus pesos
      fueron adaptados según `references/modelo-practica-aplicada.md` y marcados como propuesta a validar.

## Alineamiento pedagógico
- [ ] Cada resultado de aprendizaje está conectado a al menos una actividad y una evaluación en la matriz.
- [ ] No hay contenidos o actividades duplicadas entre semanas/unidades.
- [ ] Existe balance razonable entre teoría y práctica.
- [ ] La carga académica implícita es viable en el tiempo disponible.

## Veracidad e integridad de la información
- [ ] Ninguna credencial, publicación o experiencia atribuida al profesor carece de respaldo verificable
      (fuente pública o dato entregado explícitamente por el usuario).
- [ ] Ninguna cifra, herramienta o referencia fue inventada; lo que no se pudo verificar quedó marcado como
      supuesto o pregunta pendiente, no como hecho.
- [ ] Las tecnologías y tendencias mencionadas fueron verificadas como vigentes (o se indicó que no se
      verificaron).

## Calidad de fuentes y actualidad
- [ ] El contenido técnico que puede desactualizarse fue contrastado con búsqueda web cuando fue
      pertinente, citando fuente y fecha de consulta.
- [ ] Se priorizaron fuentes confiables (documentación oficial, papers, universidades, estándares) sobre
      blogs o fuentes no verificadas.

## Redacción y formato
- [ ] Terminología consistente a lo largo del documento.
- [ ] Redacción clara, sin jerga sin explicar.
- [ ] Formato profesional y accesible (tablas bien formadas, jerarquía de encabezados clara).

## Cierre de trazabilidad
- [ ] La entrega incluye: supuestos realizados, información faltante, cambios propuestos, y elementos que
      requieren aprobación académica.
