# Agenda tipo de sesión (6 bloques) — estructura sugerida vigente

Esta es la agenda de referencia que **todo curso generado por este skill debe usar por defecto** para
estructurar cada sesión, sustituyendo la distribución genérica "60% práctica / 35% conceptual" por bloques
concretos con nombre y minutos exactos. Se activa en la Fase 4.5 del flujo de trabajo (`SKILL.md`).

## Estructura sugerida para una sesión de 3 horas (180 min)

| # | Bloque | Tiempo | % de la sesión |
|---|---|---|---|
| 1 | Apertura y conexión | 10 min | 5.6% |
| 2 | Desarrollo conceptual | 50 min | 27.8% |
| 3 | Receso | 15 min | 8.3% |
| 4 | Taller o caso práctico | 60 min | 33.3% |
| 5 | Discusión y reflexión | 30 min | 16.7% |
| 6 | Aplicación al contexto laboral | 15 min | 8.3% |
| **Total** | | **180 min** | **100%** |

## Qué contiene cada bloque

1. **Apertura y conexión (10 min):** encuadre de la sesión, conexión con la anterior. A partir de la
   sesión 2, este es también el momento de **recibir/revisar brevemente** el caso práctico entregado al
   inicio de esta sesión (ver `SKILL.md`, Fase 4.5, cadencia rotativa) — la revisión detallada puede
   extenderse en el bloque de Discusión y reflexión si el entregable lo amerita.
2. **Desarrollo conceptual (50 min):** exposición de los fundamentos técnicos/teóricos de la sesión.
3. **Receso (15 min):** pausa. No es un bloque pedagógico; no se le asigna contenido.
4. **Taller o caso práctico (60 min):** este es el bloque de **construcción activa** del Caso práctico
   aplicado que se abre en esta sesión (ver `applied-case-designer`). **Es, exactamente, el presupuesto de
   tiempo de la "Parte A" que ese skill debe verificar que sea factible** — no el 60% completo de la
   sesión, sino este bloque específico de 60 minutos (en una sesión de 3 horas).
5. **Discusión y reflexión (30 min):** espacio para debatir lo aprendido, conectar con lecturas o casos
   adicionales, y —cuando aplique— profundizar en el caso práctico recién iniciado (decisiones de diseño,
   variantes, dudas) sin ser tiempo de construcción activa.
6. **Aplicación al contexto laboral (15 min):** cierre reflexivo explícito sobre cómo lo visto aplica al
   rol/industria de los estudiantes — este es el espacio que operacionaliza el "aplicación al contexto
   laboral" exigido por el modelo pedagógico.

## Cómo escalar a sesiones de duración distinta a 3 horas

Si una sesión no dura 180 minutos, escala cada bloque proporcionalmente usando los porcentajes de la tabla
(no minutos fijos), y redondea a múltiplos de 5 minutos para que sea operativamente manejable. Ejemplo para
una sesión de 120 minutos:

| Bloque | % | Minutos (120 min) |
|---|---|---|
| Apertura y conexión | 5.6% | ~5-10 min |
| Desarrollo conceptual | 27.8% | ~35 min |
| Receso | 8.3% | ~10 min |
| Taller o caso práctico | 33.3% | ~40 min |
| Discusión y reflexión | 16.7% | ~20 min |
| Aplicación al contexto laboral | 8.3% | ~10 min |

Presenta cualquier escalamiento como propuesta a validar por el profesor, no como un hecho fijo — el
profesor puede preferir una distribución distinta para su grupo.

## Relación con la cadencia de casos prácticos rotativos

El bloque **"Taller o caso práctico"** es, sesión a sesión, el espacio donde:
- En la sesión 1: se hace un taller introductorio sin entregable (fundamentos, no abre caso práctico).
- Desde la sesión 2: se **abre** el nuevo caso práctico aplicado y el estudiante **empieza su construcción
  en vivo**, con el profesor presente para resolver bloqueos — nunca se le entrega como un enunciado frío
  para iniciar solo en casa.
- El cierre del bloque de taller debe dejar claro qué le queda pendiente al estudiante para completar de
  forma autónoma antes del inicio de la sesión siguiente.

Este es el insumo de tiempo exacto que `applied-case-designer` debe usar por defecto al diseñar la "Parte A
— Guion de taller en clase" de cada caso práctico, salvo que el usuario indique un tiempo de taller distinto
para su sesión.
