# Modelo pedagógico vigente: agenda de sesión de 6 bloques + cadencia de proyecto práctico rotativo

Esta referencia documenta el lineamiento pedagógico institucional que **todo curso generado por este
skill debe aplicar por defecto**, salvo instrucción explícita en contra del usuario. Se activa
automáticamente en la Fase 4-5 del flujo de trabajo (`SKILL.md`).

## 1. Balance de tiempo/contenido por sesión

La distribución exacta de tiempo por sesión está definida en `references/agenda-sesion-tipo.md`: una
agenda de **6 bloques con nombre y minutos exactos** (Apertura y conexión, Desarrollo conceptual, Receso,
Taller o caso práctico, Discusión y reflexión, Aplicación al contexto laboral), no un simple porcentaje
"práctica vs. conceptual". Esa referencia es la autoridad operativa; aquí solo se resume el principio:

- La construcción activa del caso práctico ocurre específicamente en el bloque **"Taller o caso práctico"**
  (60 min en una sesión de 3 horas) — este es el presupuesto de tiempo que `applied-case-designer` debe
  verificar como factible, no un porcentaje aproximado de toda la sesión.
- Los bloques de **Desarrollo conceptual**, **Discusión y reflexión** y **Aplicación al contexto laboral**
  dan al contenido teórico el espacio explícito de debate y conexión con el rol/industria del estudiante que
  exige el enfoque ejecutivo-aplicado del programa.
- El **Receso** es una pausa operativa, no un bloque pedagógico.

Al construir la agenda de cada sesión (`templates/syllabus-template.md`, sección 13), usa los 6 bloques con
sus minutos (o escalados proporcionalmente según `agenda-sesion-tipo.md` si la sesión no dura 3 horas).

## 2. Cadencia de proyecto práctico rotativo (a partir de la sesión 2)

A partir de la **sesión 2** en adelante, cada sesión:

1. **Abre** asignando (o retomando) un proyecto práctico aplicado al contenido recién visto.
2. El estudiante debe **completarlo y entregarlo a más tardar al inicio de la siguiente sesión** — es
   decir, el ciclo de trabajo autónomo del estudiante ocurre *entre* sesiones, no dentro del bloque de
   clase.
3. La sesión siguiente arranca (bloque de **Apertura y conexión**, ver `agenda-sesion-tipo.md`) con una
   breve revisión/cierre de ese entregable antes de que el bloque de **Taller o caso práctico** abra el
   nuevo caso.

Esto crea una cadena: **Sesión 2 abre Caso 1 → se entrega al inicio de Sesión 3 → Sesión 3 abre Caso 2 → se
entrega al inicio de Sesión 4 → Sesión 4 abre Caso 3 (o cierre/capstone si es la última sesión)**. Ajusta el
número de casos a la cantidad real de sesiones del curso: la lógica es "un caso práctico nuevo por cada
sesión a partir de la 2, entregado al inicio de la sesión siguiente", no un número fijo de 3.

Al construir el cronograma (`templates/syllabus-template.md`, sección 19), refleja esta cadencia
explícitamente: cada fila de "Entregable" debe indicar que corresponde al caso abierto en la sesión
anterior, no en la misma sesión.

**Excepción de la sesión 1:** al no haber sesión previa, la sesión 1 se dedica a fundamentos y no abre un
caso práctico entregable — el primer caso práctico se abre en la sesión 2, como indica el punto anterior.

## 3. Esquema de evaluación institucional vigente

Este es el esquema de evaluación que corresponde a la cadencia de casos prácticos rotativos. Es el
**esquema institucional por defecto** para cursos que sigan este modelo (Fase 3 del flujo de trabajo,
`SKILL.md`) — se conserva sin cambios salvo que el usuario adjunte uno distinto o pida explícitamente
modificarlo:

| Rubro / Entregable | Porcentaje |
|---|---|
| Caso práctico aplicado 1 | 25% |
| Caso práctico aplicado 2 | 25% |
| Caso práctico aplicado 3 | 30% |
| Asistencia | 20% |
| **Total** | **100%** |

Verificación: 25 + 25 + 30 + 20 = 100% ✅.

Notas de diseño de este esquema (útiles para explicar al usuario si pregunta o para adaptarlo a cursos con
más o menos sesiones):

- El peso **crece progresivamente** entre casos (25% → 25% → 30%), reflejando que el último caso suele
  integrar más contenido acumulado del curso — coherente con la progresión de complejidad Bloom exigida en
  la Fase 4.
- **No hay rubro de "Participación en clase" separado** en este esquema: la participación y la reflexión
  aplicada al contexto laboral se evalúan como parte de la calidad de cada caso práctico entregado (ver
  criterios de la rúbrica en `course-assessment-and-activity-designer`), no como un rubro aparte.
- Si el curso tiene un número de sesiones distinto a 4 (y por tanto un número distinto de casos prácticos
  rotativos), redistribuye el 80% no asignado a asistencia entre los casos prácticos que correspondan,
  manteniendo la progresión creciente y verificando que la suma total siga dando 100%. Preséntalo como
  propuesta a validar cuando el número de casos no sea exactamente 3.

## 4. Qué hacer si el sílabo fuente trae el esquema anterior (Tareas + Participación + Asistencia)

Si el documento fuente o una plantilla institucional adjunta trae el esquema anterior (p. ej. Tarea No. 1 /
Tarea No. 2 / Participación / Asistencia), no lo sobrescribas en silencio: repórtalo como una diferencia
frente al esquema vigente descrito arriba, explica la razón pedagógica del cambio (transición hacia
evaluación 100% basada en casos prácticos aplicados con cadencia entre sesiones), y pide aprobación antes
de reemplazarlo — siguiendo la misma disciplina de la Fase 3 del flujo de trabajo.
