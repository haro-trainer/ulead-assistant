# Cómo priorizar una plantilla institucional real

Cuando el proyecto o la conversación incluya una plantilla, ejemplo o manual de sílabos de la universidad,
esa plantilla siempre tiene prioridad sobre `templates/syllabus-template.md`. Esta referencia explica cómo
usarla correctamente.

## Qué extraer de la plantilla institucional

1. **Orden y nombres exactos de las secciones.** No renombres "Resultados de aprendizaje" a "Objetivos de
   aprendizaje" si la universidad usa el segundo término, y viceversa.
2. **Campos obligatorios de encabezado** (código de curso, créditos, facultad, departamento, etc.) — a
   veces la plantilla genérica de este skill no los contempla porque son específicos de cada institución.
3. **Formato de citación bibliográfica exigido** (APA, Chicago, IEEE, u otro propio).
4. **Textos fijos institucionales** que no deben reescribirse (p. ej. cláusulas de integridad académica,
   política de discapacidad, texto legal de derechos de autor) — estos se copian tal cual, no se
   "mejoran" ni se parafrasean.
5. **Convenciones de formato** (tipografía, uso de tablas vs. listas, membrete, pie de página).

## Qué hacer cuando la plantilla institucional y este skill entran en conflicto

- Si la plantilla institucional pide menos secciones que las 26 de la plantilla genérica: usa las de la
  plantilla institucional como mínimo exigido, pero puedes sugerir (no imponer) añadir una sección que
  consideres valiosa (p. ej. una matriz de alineamiento, si la universidad no la pide como sección visible
  del sílabo pero sí como evidencia interna de calidad).
- Si la plantilla institucional pide más secciones: complétalas todas, incluso si no aparecen en la
  plantilla genérica de este skill.
- Si hay ambigüedad sobre qué texto es "fijo" (no debe tocarse) y cuál es de contenido (debe completarse):
  pregúntalo antes de asumir.

## Textos legales o de política institucional

Nunca reescribas ni resumas cláusulas de integridad académica, políticas de accesibilidad, o textos legales
que vengan literalmente de la plantilla institucional — cópialos exactamente como están, salvo que el
usuario pida explícitamente actualizarlos (en cuyo caso, señala el cambio como algo que requiere revisión
del área legal o académica correspondiente, no solo tuya).
