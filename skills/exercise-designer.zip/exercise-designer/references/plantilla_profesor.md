# Plantilla — Set del profesor (guía de facilitación)

```markdown
# [Título del tema] — Guía del profesor

## Visión general de la sesión de ejercicios
- **Objetivo general:** [qué debe poder hacer el estudiante al terminar, verbo Bloom]
- **Audiencia y nivel esperado:** [ ]
- **Duración total estimada:** [suma de los tiempos por ejercicio]
- **Entorno/herramientas:** [ ]

---

## Ejercicio 1: [mismo título que en el set del estudiante]

**Objetivo de aprendizaje (Bloom):** [verbo observable + desempeño]

**Explicación profunda del concepto (para el facilitador, no para leer literal al grupo):**
[Lo que hay detrás del ejercicio — el mecanismo técnico o conceptual completo, incluyendo matices que el estudiante todavía no necesita ver]

**Respuesta modelo a cada pregunta de reflexión:**
- *Pregunta:* "[la misma pregunta del set del estudiante]"
  *Respuesta modelo:* [qué distingue una respuesta superficial de una que muestra comprensión real]

**Errores comunes esperados y cómo corregirlos:**
- [Error típico — de código, de concepto, o de interpretación] → [cómo guiar sin dar la respuesta directa]

**Tiempo estimado:** [ ] — **Si el grupo va rápido:** [ ] — **Si el grupo va lento:** [ ]

**Reto de extensión (opcional):** [para quien termine antes]

---

## Ejercicio 2: ...
(mismo patrón)

---

## Troubleshooting técnico (si el ejercicio usa código/herramientas)
- [Error de entorno/librería más probable] → [solución rápida]

---

## Cierre de la sesión de ejercicios
[Cómo conectar el proyecto integrador con el resto del curso; qué reforzar antes de pasar al siguiente tema]
```

## Reglas al llenar esta plantilla

- Cada ejercicio aquí debe corresponder **exactamente** (mismo número y título) a uno del set del estudiante — nunca agregues ejercicios que no existan en el otro documento.
- La "respuesta modelo" no es solo la respuesta correcta — explica qué la hace buena, para que el facilitador pueda reconocer y valorar variaciones razonables de los estudiantes.
- El tono aquí es directo, técnico y práctico — a diferencia del tono cálido/motivador del set del estudiante. Es un documento de trabajo para quien facilita, no material de lectura para el grupo.
