# Principios para diseñar ejercicios memorables

Resumen operativo — aplicar al diseñar, no repetir literalmente al usuario.

## Scaffolding (andamiaje progresivo)
Cada ejercicio debe apoyarse en la habilidad/concepto que el ejercicio anterior ya construyó. Evita saltos de dificultad: si el ejercicio 1 es "ejecuta y observa", el ejercicio 2 no debería exigir ya diseño abierto — ese salto viene más adelante, cuando ya hay base.

## Carga cognitiva
Un ejercicio bien diseñado introduce **una** idea nueva a la vez, apoyada en algo ya conocido. Si un ejercicio mezcla 3 conceptos nuevos sin distinguir cuál es el foco, se vuelve confuso en vez de memorable. El código o la tarea debe ser lo más corto posible mientras siga mostrando el concepto con claridad.

## Preguntas de reflexión que sí enseñan
Una buena pregunta de reflexión no se puede responder solo con "sí" o "no", ni copiando la definición. Apunta a que el estudiante conecte lo que acaba de observar con el concepto de fondo ("¿por qué crees que...?", "¿qué notas cuando...?", "¿cómo cambiaría si...?"). Evita preguntas retóricas que ya insinúan la respuesta.

## Aplicación real, no solo ejecución
El ejercicio final de la serie (el "proyecto integrador") debe sentirse como algo que el estudiante podría reconocer como útil fuera del salón de clase — un mini-asistente, un mini-análisis, una mini-herramienta — no un ejercicio artificial más.

## Tono memorable
- Abre con una bienvenida genuina, no una lista de instrucciones fría.
- Usa ganchos narrativos en los títulos de sección en vez de etiquetas técnicas secas.
- Cierra con reconocimiento del esfuerzo y una invitación a seguir explorando — el cierre es lo que la gente recuerda.
- Evita el exceso de formalismo académico; el lenguaje debe sentirse como el de alguien que quiere que el estudiante lo logre, no como un manual.

## Separación profesor/estudiante como principio de diseño, no solo de contenido
El set del estudiante protege el descubrimiento guiado (no regala respuestas). El set del profesor existe para que quien facilita pueda sostener la conversación cuando el grupo se desvía del guion, reconozca errores conceptuales reales, y sepa cuándo profundizar o cuándo avanzar. Generar ambos sin esta separación clara reduce el valor pedagógico de los dos documentos.
