# Plantilla — Set del estudiante

```markdown
# [Título atractivo del tema] — Ejercicios prácticos

## Bienvenida
¡Bienvenidos y bienvenidas!
[2-3 frases: qué van a lograr, por qué importa, tono cercano y motivador]

Recuerda: puedes y debes experimentar, modificar los ejemplos y reflexionar sobre lo que ocurre en cada paso.

---

## Configuración inicial (si aplica)
[Instalación/setup mínimo necesario, en bloque de código ejecutable]

---

## 1. [Nombre del concepto 1: gancho breve]

[1-2 frases de concepto en lenguaje simple, sin jerga innecesaria]

### Ejercicio 1: [acción concreta que va a hacer]

```[lenguaje]
[código o tarea real y ejecutable]
```

**Reflexiona:**
- [Pregunta abierta que apunta al "por qué", no al detalle trivial]
- [Segunda pregunta si aplica]

---

## 2. [Nombre del concepto 2]
... (mismo patrón, aumentando un poco la complejidad respecto al ejercicio anterior)

---

## N. Proyecto integrador: [nombre inspirador]
[Ejercicio final que conecta todos los conceptos anteriores en un mini-flujo completo]

**Reflexiona:**
- [Pregunta que invite a mirar el proceso completo, no un paso aislado]

---

## Recursos recomendados
- [Recurso 1 — con breve nota de para qué sirve]
- [Recurso 2]
- [Recurso 3, variar profundidad/idioma]

---

## Sugerencias para tu aprendizaje
- No tengas miedo de modificar los ejemplos, prueba con nuevas variantes.
- Escribe tus observaciones y dudas, compártelas con tus compañeros.
- Completa las reflexiones al final de cada ejercicio — ahí está el aprendizaje real.

---

## Evaluación sugerida (autoevaluación)
- ¿Ejecutaste/completaste correctamente cada ejercicio?
- ¿Puedes explicar con tus palabras qué hace cada paso?
- ¿Reflexionaste y compartiste tus ideas sobre los resultados?

---

¡Felicidades!
[1-2 frases de cierre celebratorio, reconociendo el logro y apuntando a qué sigue]
```

## Reglas al llenar esta plantilla

- El gancho de cada sección debe evitar sonar a índice de libro de texto — busca una frase que genere curiosidad ("así interpreta el contexto el modelo", no "Tema 3: Atención").
- Las preguntas de reflexión son la parte más importante del documento: si son triviales o de sí/no, el ejercicio pierde su valor pedagógico. Deben requerir que el estudiante piense y no solo copie/ejecute.
- Nunca incluyas aquí las respuestas de las reflexiones ni el detalle de facilitación — eso vive exclusivamente en el set del profesor.
