# Checklist de calidad antes de entregar

- [ ] **Correspondencia 1 a 1**: ¿cada ejercicio del set del estudiante tiene su contraparte exacta (mismo número/título) en el set del profesor?
- [ ] **Preguntas idénticas**: ¿las preguntas de reflexión que el profesor responde son literalmente las mismas que aparecen en el set del estudiante?
- [ ] **Progresión**: ¿la dificultad avanza de forma razonable de un ejercicio al siguiente, sin saltos ni repeticiones?
- [ ] **Una idea nueva por ejercicio**: ¿cada ejercicio introduce un concepto principal claro, apoyado en lo ya visto?
- [ ] **Preguntas que sí enseñan**: ¿ninguna pregunta de reflexión se puede responder con "sí/no" o copiando una definición?
- [ ] **Separación de tono**: ¿el set del estudiante suena cálido y motivador, y el del profesor suena técnico y directo (no idénticos entre sí)?
- [ ] **Sin respuestas filtradas**: ¿el set del estudiante no contiene ninguna respuesta modelo ni nota de facilitación que debería estar solo en el set del profesor?
- [ ] **Corrección técnica**: si hay código, ¿es ejecutable y coherente con el entorno mencionado?
- [ ] **Cierre memorable**: ¿el set del estudiante cierra con reconocimiento del logro y no solo con la última tarea técnica?
- [ ] **Trazabilidad**: ¿queda claro de qué tema/plan salieron los ejercicios y que son un borrador para validación del profesor?

Si algo falla, corrígelo antes de entregar. Si el vacío depende de información que no tienes (p. ej. no sabes el nivel real del grupo), dilo explícitamente en vez de asumir.
