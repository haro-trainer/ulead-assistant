---
name: exercise-designer
description: >-
  Idea y genera sets de ejercicios prácticos muy pedagógicos a partir del tema o plan de clase que esté en
  el contexto de la conversación (no requiere archivos externos). Produce SIEMPRE dos paquetes alineados:
  (1) el set del profesor, con instrucciones detalladas, explicación profunda de cada concepto, respuestas
  modelo a las preguntas de reflexión, errores comunes y retos de extensión; y (2) el set del estudiante,
  con ejercicios guiados paso a paso, código o tareas, preguntas de reflexión sin respuesta, recursos y
  cierre motivador. Úsalo cuando pidan "crea ejercicios", "diseña un laboratorio/práctica", "genera una
  guía para estudiantes y otra para el profesor", "hazme una actividad práctica tipo notebook", o quieran
  convertir un tema/sesión en una experiencia hands-on atractiva y memorable.
---

# Exercise Designer

Este skill diseña **experiencias de ejercicios prácticos** (tipo notebook/laboratorio guiado) a partir de un tema, concepto técnico o plan de clase que ya está en el contexto de la conversación. Su output siempre son **dos paquetes gemelos**: uno para quien facilita la clase y otro para quien la toma. Nunca genera solo uno de los dos sin avisar — son un par que debe mantenerse alineado ejercicio por ejercicio.

Los archivos de referencia que pudo haber subido el usuario (guías de ejercicios previas) se usan **únicamente como inspiración de formato y tono** — bienvenida cercana, progresión de conceptos, bloques de código con reflexión, recursos y cierre celebratorio. El **contenido real siempre sale del tema que el usuario está trabajando en la conversación actual**, nunca se reciclan literalmente los ejemplos de un archivo de referencia para un tema distinto.

## Por qué el par profesor/estudiante y no un solo documento

Un buen ejercicio hands-on solo funciona bien en clase si quien lo facilita entiende el "por qué" detrás de cada paso, sabe qué responder cuando alguien pregunta algo inesperado, y reconoce los errores típicos antes de que ocurran. Si el estudiante y el profesor comparten un único documento, o el profesor no tiene más contexto que el estudiante, la sesión se vuelve frágil ante preguntas fuera de guion. Por eso el set del profesor siempre contiene una capa de profundidad que el del estudiante no muestra (para no arruinar el descubrimiento guiado), pero ambos deben corresponder ejercicio por ejercicio.

## Flujo de trabajo

### Paso 1 — Identificar el tema y el nivel

Antes de generar nada, ten claro:

- **Tema o concepto central** (viene del contexto de la conversación: un plan de sesión, un curso, o lo que el usuario acaba de pedir).
- **Audiencia y nivel previo** (principiantes en el tema vs. audiencia con base técnica).
- **Herramientas/entorno** en que se ejecutarán los ejercicios (notebook Python, no-code, hoja de cálculo, discusión sin código, etc.) — no asumas Python/Colab por defecto solo porque los archivos de referencia lo usaban; pregunta o infiérelo del contexto real.
- **Cuántos ejercicios** tiene sentido (usualmente 3-6: de exploración simple a proyecto integrador — evita más de 6 si el objetivo es que se sientan logrables en una sesión).

Si el tema no está claro en el contexto (el usuario solo dijo "genera ejercicios" sin más), pregunta brevemente por el tema/concepto y el entorno técnico antes de diseñar — no reutilices el tema de un archivo de referencia adjunto solo porque está ahí.

### Paso 2 — Diseñar el arco pedagógico (antes de redactar)

Aplica scaffolding: cada ejercicio debe apoyarse en el anterior y aumentar un poco la complejidad. Un arco que funciona bien (ajústalo al tema real):

1. **Exploración concreta** de la pieza más básica del concepto (algo que se ejecuta/observa en segundos).
2. **Profundización** en el "por qué" o el mecanismo interno.
3. **Visualización o comparación** que haga tangible algo abstracto.
4. **Aplicación generativa/creativa** con el concepto.
5. **Proyecto integrador** que conecta todos los pasos anteriores en un mini-flujo completo.

No copies este arco literalmente si el tema no calza — la lógica de fondo es "de lo concreto y simple a lo integrador y aplicado", no una plantilla rígida de 5 pasos fijos.

Consulta `references/principios_diseno_ejercicios.md` para las reglas de fondo (scaffolding, carga cognitiva, preguntas de reflexión que sí enseñan, tono memorable).

### Paso 3 — Generar el set del estudiante

Usa `references/plantilla_estudiante.md`. Reglas clave:

- Abre con una **bienvenida breve y cercana** que explique qué va a lograr el estudiante y por qué importa (no solo "aquí están los ejercicios").
- Cada ejercicio: título con gancho, 1-2 frases de concepto en lenguaje simple, el código/tarea a ejecutar o completar, y **preguntas de reflexión abiertas** (sin la respuesta) que apunten a lo que de verdad hay que entender, no a detalles triviales.
- Incluye una sección de **recursos recomendados** (2-4, variados en profundidad/idioma si aplica) y **sugerencias para aprender mejor** (experimentar, compartir dudas, no tener miedo de romper el código).
- Cierra con una nota breve de **evaluación sugerida** (checklist de autoevaluación) y un **cierre celebratorio** que reconozca el esfuerzo y dé una siguiente puerta a explorar.
- Nunca incluyas las respuestas a las preguntas de reflexión ni las notas de facilitación del profesor en este set — eso rompe el descubrimiento guiado.

### Paso 4 — Generar el set del profesor

Usa `references/plantilla_profesor.md`. Para cada ejercicio del set del estudiante, produce el espejo con:

- **Objetivo de aprendizaje** redactado con verbo de Bloom observable.
- **Explicación profunda del concepto** — más allá de lo que ve el estudiante, incluyendo el "por qué" técnico.
- **Respuesta modelo a cada pregunta de reflexión** (no solo la respuesta correcta, sino qué distingue una respuesta superficial de una que muestra comprensión real).
- **Errores comunes esperados** (de código, de concepto, o de interpretación) y cómo corregirlos en el momento sin dar la respuesta directa.
- **Tiempo estimado** y qué hacer si el grupo va más rápido o más lento.
- **Reto de extensión opcional** para quien termine antes.

Cierra con una guía breve de **troubleshooting técnico** (errores de entorno/librerías más probables) si el ejercicio involucra código o herramientas técnicas.

### Paso 5 — Verificar alineación entre ambos sets

Antes de entregar, confirma:

- Cada ejercicio del set del estudiante tiene su contraparte exacta en el set del profesor (mismo número/título).
- Las preguntas de reflexión del estudiante son las mismas que el profesor está respondiendo (no inventes preguntas nuevas de un lado).
- La dificultad progresa de forma coherente en ambos documentos.
- El tono del set del estudiante es cálido, motivador y accesible; el del profesor es directo, técnico y práctico — no deben sonar igual.

Usa `references/checklist_calidad.md` como última pasada.

### Paso 6 — Producir los archivos

- Genera **dos artefactos separados** (no un solo documento con ambas secciones mezcladas) — normalmente como Markdown/docx: `[Tema] - Ejercicios Estudiante.md` y `[Tema] - Guía del Profesor.md`. Consulta el skill `docx` primero si el usuario pide archivos Word.
- Si el entorno de los ejercicios es un notebook ejecutable (Python/Colab), el set del estudiante puede incluir bloques de código reales y ejecutables, igual que en los ejemplos de referencia — no pseudo-código vago.
- Mantén el idioma del contexto de la conversación (normalmente español) y cuida que el material se sienta profesional y cuidado, no genérico: usa analogías, un hilo narrativo entre ejercicios, y un cierre que se sienta a un logro real.

### Paso 7 — Entregar con trazabilidad y validación humana

Indica brevemente de qué tema/plan se derivaron los ejercicios y recuerda que son un borrador para que el profesor los revise, ajuste el nivel de dificultad si conoce mejor a su grupo, y los apruebe antes de usarlos en clase — el modelo de gobierno sigue siendo *human-in-the-loop*.

## Notas importantes

- Si el usuario solo quiere **un** set (por ejemplo, "solo dame los ejercicios para estudiantes"), respeta eso, pero menciona que puedes generar también la guía del profesor si la necesita después.
- Si el tema requiere código real (Python, SQL, etc.), verifica que el código sea ejecutable y razonable — no sacrifiques corrección técnica por estética.
- Este skill no diseña la sesión completa (agenda, slides, rúbrica de curso) — para eso existe un skill complementario de desarrollo de sesión; aquí el foco es específicamente el par de ejercicios prácticos profesor/estudiante.
