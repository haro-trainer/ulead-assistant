# course-assessment-and-activity-designer

Skill complementario a `university-syllabus-designer`. Toma un sílabo aprobado y desarrolla cada actividad
de evaluación en detalle: instrucciones, recursos, solución modelo, rúbrica y variantes de dificultad.

## Instalación

Copia la carpeta `course-assessment-and-activity-designer/` a tu directorio de skills, igual que
`university-syllabus-designer/`. Ambos skills son independientes entre sí — puedes usar uno sin el otro —
pero están diseñados para trabajar en secuencia dentro del mismo programa académico.

## Uso típico

```
Aquí está el sílabo aprobado de "Streaming y Arquitecturas Event-Driven". Necesito que desarrolles
la Tarea No. 2 (30% de la nota): instrucciones completas para el estudiante, un dataset de ejemplo,
solución modelo y la rúbrica de calificación.
```

## Estructura del paquete

```text
course-assessment-and-activity-designer/
├── SKILL.md
├── README.md
├── templates/
│   ├── task-template.md
│   └── rubric-template.md
├── validators/
│   └── activity-quality-checklist.md
└── examples/
    └── sample-activity.md
```

## Cuándo usar este skill vs. `university-syllabus-designer`

- Pide el **sílabo completo de un curso** → `university-syllabus-designer`.
- Pide **una tarea, laboratorio, quiz, proyecto o rúbrica específica** de un curso que ya tiene sílabo →
  este skill.
- Pide ambas cosas → primero se genera y aprueba el sílabo, y luego este skill toma esa evaluación
  aprobada como entrada.
