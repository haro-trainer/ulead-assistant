# Ejemplo funcional — Tarea No. 2

*(Basado en el sílabo de ejemplo del curso "Streaming, Event-Driven Architecture y Analítica en Tiempo
Real", ver `university-syllabus-designer/examples/sample-output.md`)*

## Instrucciones para el estudiante

**Tarea No. 2 — Diseño de un pipeline de streaming con ventanas de tiempo**
**Peso:** 30% de la nota final | **RA evaluado:** RA3 (configurar un pipeline de streaming que procese
eventos con ventanas de tiempo y maneje datos tardíos) | **Semana:** 3 | **Modalidad:** Individual, entrega
en repositorio Git.

**Contexto:** El proyecto integrador del programa usa el caso de una empresa omnicanal con eventos de
clickstream en su ecommerce. Esta tarea aplica ese caso a un pipeline de streaming real.

**Objetivo:** Configurar un pipeline con Kafka + Spark Structured Streaming (o Flink) que agregue eventos
de clickstream en ventanas de 5 minutos y maneje correctamente datos que llegan tarde.

**Instrucciones:**
1. Usa el dataset simulado de clickstream provisto (`clickstream_sample.csv`, o genera eventos con el
   script de referencia).
2. Publica los eventos a un topic de Kafka local (Docker) o Confluent Cloud Trial.
3. Configura un job de Spark Structured Streaming que agrupe eventos por `session_id` en ventanas de 5
   minutos con un watermark de 2 minutos.
4. Documenta cómo tu pipeline maneja un evento que llega después de que su ventana ya cerró.

**Qué debes entregar:** repositorio Git con el código del pipeline, un README con instrucciones de
ejecución, y un documento de 1 página explicando las decisiones de ventana/watermark tomadas.

## Solución modelo (referencia para quien califica)

*(Nota: esta actividad admite variantes razonables en la elección de tamaño de ventana o motor de
streaming — Spark vs. Flink son ambas soluciones aceptables si están bien justificadas.)*

Un pipeline de referencia: producer que publica eventos con timestamp de evento; consumer en Spark
Structured Streaming con `withWatermark("event_time", "2 minutes")` y `groupBy(window("event_time", "5
minutes"), "session_id")`; los eventos tardíos dentro del watermark se incorporan a la ventana
correspondiente, y los que llegan después del watermark se descartan o se enrutan a un "dead-letter topic"
documentado explícitamente.

## Rúbrica

| Criterio | Peso | Logrado (100%) | Satisfactorio (75%) | En desarrollo (50%) | Insuficiente (≤25%) |
|---|---|---|---|---|---|
| Pipeline funcional (Kafka → procesamiento) | 40% | Corre sin errores y produce agregaciones correctas | Corre con ajustes menores necesarios | Corre parcialmente o con errores no críticos | No corre o no procesa eventos |
| Manejo de ventanas y watermark | 30% | Configuración correcta y justificada por escrito | Configuración correcta, justificación incompleta | Configuración con errores conceptuales menores | Sin manejo de ventanas/watermark |
| Manejo de datos tardíos | 20% | Explica y demuestra el comportamiento con datos tardíos | Explica sin demostrar | Menciona el concepto sin aplicarlo | No lo aborda |
| Documentación (README + decisiones) | 10% | Clara, completa, reproducible | Completa con detalles menores faltantes | Incompleta | Ausente o no reproducible |

## Trazabilidad
- Supuesto: se asumió acceso a Docker o Confluent Cloud Trial según lo indicado en las herramientas del
  sílabo.
- Pendiente de aprobación del profesor: el tamaño de ventana (5 minutos) es una sugerencia pedagógica;
  puede ajustarse según el énfasis que el profesor quiera dar al caso.
