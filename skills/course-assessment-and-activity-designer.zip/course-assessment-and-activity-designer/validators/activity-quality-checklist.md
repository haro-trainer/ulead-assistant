# Checklist de calidad — Actividad de evaluación

- [ ] La actividad está anclada a un peso y resultado(s) de aprendizaje explícitos del sílabo aprobado.
- [ ] Las instrucciones son completas: un estudiante podría empezar a trabajar sin necesitar aclaraciones
      básicas.
- [ ] Los recursos provistos son suficientes para completar la actividad tal como está descrita.
- [ ] La solución modelo es coherente con las instrucciones dadas (no evalúa algo que no se pidió).
- [ ] Si la actividad admite múltiples soluciones válidas, la solución modelo lo indica explícitamente.
- [ ] Los pesos de los criterios de la rúbrica suman exactamente 100% de la nota de esta actividad.
- [ ] Cada criterio de la rúbrica es observable y distinguible entre niveles de desempeño.
- [ ] Ningún dato, cifra o caso presentado como real fue inventado sin decirlo; si es ilustrativo, se
      indica.
- [ ] Se documentaron los supuestos hechos y lo que falta aprobar por el profesor.
