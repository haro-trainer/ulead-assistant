---
name: course-assessment-and-activity-designer
description: "Desarrolla, a partir de un sílabo universitario ya aprobado, cada actividad de evaluación con todos sus componentes (instrucciones para el estudiante, recursos, entregables, solución modelo, rúbrica con niveles de desempeño y variantes de dificultad). Úsalo cuando un profesor, coordinador o diseñador instruccional pida crear, redactar o detallar una tarea, laboratorio, quiz, examen, caso, proyecto, ejercicio, práctica o rúbrica específica de un curso — incluso si solo dicen 'necesito la tarea 2 de este curso' sin decir 'actividad'. No lo uses para crear el sílabo completo o decidir pesos de evaluación a nivel curricular — eso es `university-syllabus-designer`. No lo uses tampoco para un 'Caso práctico aplicado' que arranca en el taller de una sesión y se entrega al inicio de la siguiente — eso es `applied-case-designer`, que investiga en la web y verifica el tiempo de taller disponible."
---

# Diseñador de Tareas y Evaluaciones de Curso

## Relación con `university-syllabus-designer` y `applied-case-designer`

Los skills dividen el trabajo de diseño instruccional en niveles distintos, para evitar que uno haga el
trabajo del otro a medias:

| | `university-syllabus-designer` | Este skill | `applied-case-designer` |
|---|---|---|---|
| Nivel | Curricular (el curso completo) | Actividad general (quiz, examen, proyecto de cierre) | Actividad con patrón específico: taller en clase + entrega en la sesión siguiente |
| Produce | Sílabo, matriz de alineamiento, cronograma | Instrucciones, recursos, solución modelo, rúbrica detallada | Lo mismo, más narrativa investigada, guion de taller con tiempo verificado y guía de facilitación |

Si el usuario te pide un sílabo completo, dirígelo a `university-syllabus-designer`. Si la actividad que
piden es específicamente un **"Caso práctico aplicado"** que arranca en el bloque de taller de una sesión y
se entrega al inicio de la siguiente (el patrón por defecto del esquema de evaluación vigente), dirígelo a
`applied-case-designer` en su lugar — ese skill investiga en la web para idear el proyecto y verifica que
quepa en el tiempo de taller disponible, algo que este skill no hace. Usa este skill para todo lo demás:
quizzes, exámenes, proyectos de cierre de módulo, o cualquier evaluación que no cruce la frontera de dos
sesiones con un arranque en vivo.

Si te piden una actividad de las que sí corresponden a este skill y ya existe (o te comparten) el sílabo o
al menos la descripción de esa evaluación, trabaja aquí directamente. Si te piden ambas cosas (sílabo +
actividad) en la misma conversación, primero completa el sílabo y luego usa ese sílabo aprobado como
entrada — no inventes actividades que no estén respaldadas por el sílabo.

## Insumos necesarios

Obligatorios:
- El sílabo aprobado (o al menos la sección relevante: nombre de la actividad, peso, resultado de
  aprendizaje que evalúa, semana).
- Qué actividad(es) desarrollar (nombre o número, p. ej. "Tarea No. 2").

Opcionales (pide o infiere con cautela, marcando la inferencia):
- Nivel de dificultad deseado y si se necesitan variantes.
- Formato de entrega (individual/grupal, escrito/oral/código/presentación).
- Herramientas o tecnologías específicas a usar.
- Extensión o duración esperada.
- Si se requiere solución modelo detallada o solo criterios de corrección.

## Flujo de trabajo

1. **Ubica la actividad en el sílabo.** Confirma su peso, el/los resultado(s) de aprendizaje que evalúa, y
   la semana en que ocurre. Si algo no está claro en el sílabo, pregúntalo — no asumas un peso o propósito
   que no esté documentado.

2. **Redacta instrucciones completas para el estudiante** usando `templates/task-template.md`: contexto,
   objetivo, qué debe entregar, formato, extensión, herramientas permitidas, criterios de éxito, fecha o
   momento de entrega.

3. **Prepara los recursos de apoyo** que la actividad necesite (dataset de ejemplo, plantilla de código,
   lecturas específicas, enunciado de caso). Si la actividad requiere datos o un caso realista, puedes
   usar `web_search` para fundamentar el caso en información real y vigente (citando fuente), pero no
   inventes cifras que aparenten ser reales sin dejarlo claro cuando son ilustrativas.

4. **Redacta la solución modelo o respuesta esperada.** Debe ser lo bastante completa para que quien
   califique tenga un punto de referencia claro, pero sin ser la única solución válida si la actividad
   admite variantes razonables — en ese caso, dilo explícitamente.

5. **Construye la rúbrica** usando `templates/rubric-template.md`: criterios derivados directamente del
   resultado de aprendizaje que la actividad evalúa, con niveles de desempeño descritos (no solo
   "excelente/bueno/regular" sin contenido), y una ponderación interna que sea consistente con el peso
   total de la actividad en el sílabo.

6. **Genera variantes por nivel de dificultad** si el usuario las pide: mismo resultado de aprendizaje,
   distinto nivel de andamiaje o complejidad (p. ej. una variante con datos ya limpios vs. una con datos
   crudos que requieren más trabajo previo).

7. **Revisa contra `validators/activity-quality-checklist.md`** antes de entregar.

8. **Cierra con trazabilidad:** supuestos hechos, información que faltó del sílabo, y cualquier elemento
   que requiera aprobación del profesor antes de usarse con estudiantes.

## Archivos de referencia

- `templates/task-template.md` — estructura de instrucciones para el estudiante.
- `templates/rubric-template.md` — estructura de rúbrica con niveles de desempeño.
- `validators/activity-quality-checklist.md` — checklist de calidad antes de entregar.
- `examples/sample-activity.md` — ejemplo funcional completo (tarea + rúbrica + solución modelo).

## Límites del skill

- No decide los pesos de evaluación del curso ni reestructura el sílabo — eso es responsabilidad de
  `university-syllabus-designer`.
- No sustituye el criterio del profesor sobre lo que constituye una respuesta aceptable; la solución modelo
  es una referencia, no la única respuesta correcta salvo que la naturaleza de la actividad lo exija (p.
  ej. un ejercicio con resultado numérico único).
