# Plantilla — Instrucciones de actividad

```markdown
# [Nombre de la actividad] — [Curso]

**Peso en la nota final:** [%] | **Resultado(s) de aprendizaje evaluado(s):** [RA #] | **Semana:** [#]
**Modalidad de entrega:** [individual/grupal] · [formato]

## Contexto
[Por qué esta actividad importa; cómo conecta con lo visto en clase y con un problema real]

## Objetivo
[Qué debe lograr el estudiante al completarla, en una frase]

## Instrucciones
1. [Paso o requisito]
2. [Paso o requisito]
3. ...

## Recursos provistos
- [Dataset, plantilla de código, lecturas, enunciado de caso]

## Qué debes entregar
- [Formato exacto: archivo, extensión esperada, estructura]

## Criterios de éxito (resumen)
[2-4 líneas que anticipen lo que evalúa la rúbrica, sin sustituirla]

## Fecha/momento de entrega
[Según el cronograma del sílabo]
```
