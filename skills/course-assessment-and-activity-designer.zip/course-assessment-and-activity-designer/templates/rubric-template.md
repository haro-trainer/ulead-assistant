# Plantilla — Rúbrica de calificación

Los criterios deben derivarse directamente del/los resultado(s) de aprendizaje que la actividad evalúa
(ver `SKILL.md`, paso 5). El peso interno de los criterios debe sumar 100% de la nota de *esta actividad*
(no del curso completo).

| Criterio | Peso | Nivel logrado (100%) | Nivel satisfactorio (75%) | Nivel en desarrollo (50%) | Nivel insuficiente (25% o menos) |
|---|---|---|---|---|---|
| [Criterio 1, ligado a RA#] | [%] | [descripción concreta y observable] | [...] | [...] | [...] |
| [Criterio 2] | [%] | | | | |
| [Criterio 3] | [%] | | | | |
| **Total** | **100%** | | | | |

## Verificación obligatoria antes de entregar

- La suma de los pesos de los criterios es exactamente 100%.
- Cada nivel de desempeño describe algo observable (evitar "muy bien" sin explicar qué distingue un nivel
  del otro).
- Cada criterio puede rastrearse a un resultado de aprendizaje del sílabo.
